

const CACHE_NAME = 'Dongtube-v5';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/otp.html',
  '/track.html',
  '/pay.html',
  '/upload.html',
  '/ulasan.html',
  '/chat.html',
  '/produk.html',
  '/produk',
];

self.addEventListener('install', function(e) {
  e.waitUntil(
    caches.open(CACHE_NAME).then(function(cache) {
      return cache.addAll(STATIC_ASSETS).catch(function(){});
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', function(e) {
  e.waitUntil(
    caches.keys().then(function(keys) {
      return Promise.all(keys.filter(function(k){ return k !== CACHE_NAME; }).map(function(k){ return caches.delete(k); }));
    })
  );

});

self.addEventListener('fetch', function(e) {

  if (e.request.method !== 'GET') return;
  var url = new URL(e.request.url);
  if (url.pathname.startsWith('/api/')) return;

  e.respondWith(
    fetch(e.request)
      .then(function(res) {

        if (res.ok && ['document','script','style'].includes(e.request.destination)) {
          var clone = res.clone();
          caches.open(CACHE_NAME).then(function(c){ c.put(e.request, clone); });
        }
        return res;
      })
      .catch(function() {
        return caches.match(e.request).then(function(cached) {
          return cached || caches.match('/index.html');
        });
      })
  );
});
