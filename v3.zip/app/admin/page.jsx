'use client';
import { useState, useEffect, useCallback, useRef } from 'react';

/* ─── Helpers ─────────────────────────────────────────────────────────────── */

function fmt(bytes) {
  if (!bytes) return '0 B';
  const k = 1024, u = ['B','KB','MB','GB','TB'];
  const i = Math.floor(Math.log(Math.max(bytes,1))/Math.log(k));
  return `${(bytes/Math.pow(k,i)).toFixed(1)} ${u[i]}`;
}

// BUG FIX: was "${d}d lalu" (hari) untuk detik — seharusnya "${d}s lalu"
function ago(iso) {
  if (!iso) return '—';
  const d = Math.floor((Date.now()-new Date(iso))/1000);
  if (d < 60)    return `${d}s lalu`;
  if (d < 3600)  return `${Math.floor(d/60)}m lalu`;
  if (d < 86400) return `${Math.floor(d/3600)}j lalu`;
  return `${Math.floor(d/86400)}hr lalu`;
}

function fmtRp(n) {
  return new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(n||0);
}

async function api(path, opts={}) {
  const res = await fetch(path,{
    headers:{'Content-Type':'application/json',...(opts.headers||{})},
    credentials:'include',...opts,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  return res.json();
}

/* ─── Icons ───────────────────────────────────────────────────────────────── */
function Icon({d,size=16,className=''}) {
  // CATATAN KEAMANAN: dangerouslySetInnerHTML di sini AMAN karena nilai `d` SELALU
  // berasal dari konstanta ICONS yang hardcoded di bawah — bukan dari input user.
  // Kita tidak bisa pakai <path d={d}/> biasa karena ICONS mengandung elemen SVG
  // campuran (rect, circle, polyline, line, ellipse) yang tidak bisa dirender dengan
  // satu <path>. JANGAN ganti `d` dengan nilai dari luar ICONS tanpa sanitasi.
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} strokeLinecap="round" strokeLinejoin="round" className={className} dangerouslySetInnerHTML={{__html:d}}/>
  );
}
const ICONS={
  overview:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>',
  users:'<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  key:'<path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>',
  credit:'<rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/>',
  package:'<path d="M12 2l9 4.9V17L12 22 3 17V6.9L12 2z"/><polyline points="12 22 12 12"/><polyline points="21.73 6.73 12 12 2.27 6.73"/>',
  settings:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
  files:'<path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><polyline points="13 2 13 9 20 9"/>',
  kv:'<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/>',
  db:'<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M9 3v18"/>',
  fs:'<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
  backup:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
  apidocs:'<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
  user:'<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  folder:'<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
  fileDoc:'<path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><polyline points="13 2 13 9 20 9"/>',
  server:'<rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/>',
  power:'<path d="M18.36 6.64a9 9 0 1 1-12.73 0"/><line x1="12" y1="2" x2="12" y2="12"/>',
  terminal:'<polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/>',
  lock:'<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  refresh:'<polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>',
  copy:'<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  warn:'<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
  note:'<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>',
  auth:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
  upload:'<polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/>',
  sub:'<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z"/>',
};

/* ─── UI Primitives ───────────────────────────────────────────────────────── */

function Toast({msg,type,onDone}) {
  useEffect(()=>{ const t=setTimeout(onDone,3500); return ()=>clearTimeout(t); },[]);
  const c=type==='error'
    ?'bg-red-900/90 border-red-700 text-red-100'
    :'bg-emerald-900/90 border-emerald-600 text-emerald-100';
  return <div className={`fixed bottom-6 left-1/2 -translate-x-1/2 z-[999] px-5 py-3 rounded-xl border text-sm font-medium shadow-2xl max-w-sm text-center ${c}`}>{msg}</div>;
}

// BUG FIX: tambah 'purple' & 'teal' yang dipakai tapi tidak ada
function Badge({children,color='zinc'}) {
  const m={
    green:'bg-emerald-900/60 text-emerald-300 border-emerald-700',
    red:'bg-red-900/60 text-red-300 border-red-700',
    blue:'bg-blue-900/60 text-blue-300 border-blue-700',
    amber:'bg-amber-900/60 text-amber-300 border-amber-700',
    zinc:'bg-zinc-800 text-zinc-300 border-zinc-700',
    purple:'bg-purple-900/60 text-purple-300 border-purple-700',
    teal:'bg-teal-900/60 text-teal-300 border-teal-700',
  };
  return <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-semibold border ${m[color]||m.zinc}`}>{children}</span>;
}

function Spinner({size='sm'}) {
  const s=size==='lg'?'w-8 h-8':'w-4 h-4';
  return <div className={`${s} border-2 border-zinc-600 border-t-blue-400 rounded-full animate-spin`}/>;
}

function Modal({title,children,onClose,wide=false,xl=false}) {
  useEffect(()=>{
    const h=e=>e.key==='Escape'&&onClose();
    window.addEventListener('keydown',h);
    return ()=>window.removeEventListener('keydown',h);
  },[]);
  const w=xl?'max-w-5xl':wide?'max-w-3xl':'max-w-lg';
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className={`bg-zinc-900 border border-zinc-700 rounded-2xl shadow-2xl w-full ${w} max-h-[92vh] flex flex-col`}>
        <div className="flex items-center justify-between p-5 border-b border-zinc-800 flex-shrink-0">
          <h3 className="font-bold text-white text-lg">{title}</h3>
          <button onClick={onClose} className="text-zinc-500 hover:text-white text-2xl leading-none">×</button>
        </div>
        <div className="overflow-y-auto p-5 flex-1">{children}</div>
      </div>
    </div>
  );
}

// BUG FIX: Confirm sekarang punya prop 'danger' — sebelumnya selalu merah
// Subscription confirmOrder butuh warna hijau, bukan merah
function Confirm({msg,onConfirm,onCancel,danger=true}) {
  return (
    <Modal title="Konfirmasi" onClose={onCancel}>
      <p className="text-zinc-300 mb-6">{msg}</p>
      <div className="flex gap-3 justify-end">
        <button onClick={onCancel} className="px-4 py-2 rounded-lg bg-zinc-800 text-zinc-300 hover:bg-zinc-700 text-sm">Batal</button>
        <button onClick={onConfirm} className={`px-4 py-2 rounded-lg text-white text-sm font-semibold ${danger?'bg-red-600 hover:bg-red-500':'bg-emerald-600 hover:bg-emerald-500'}`}>
          {danger?'Hapus':'Konfirmasi'}
        </button>
      </div>
    </Modal>
  );
}

function Card({children,className=''}) {
  return <div className={`bg-zinc-900 border border-zinc-800 rounded-2xl ${className}`}>{children}</div>;
}

function Input({label,value,onChange,type='text',className='',help='',...rest}) {
  return (
    <label className={`block ${className}`}>
      {label&&<span className="block text-xs text-zinc-400 mb-1 font-medium">{label}</span>}
      <input type={type} value={value} onChange={e=>onChange(e.target.value)}
        className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-blue-500 transition"
        {...rest}/>
      {help&&<span className="block text-xs text-zinc-500 mt-1">{help}</span>}
    </label>
  );
}

function Sel({label,value,onChange,children,className=''}) {
  return (
    <label className={`block ${className}`}>
      {label&&<span className="block text-xs text-zinc-400 mb-1 font-medium">{label}</span>}
      <select value={value} onChange={e=>onChange(e.target.value)}
        className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500">
        {children}
      </select>
    </label>
  );
}

function Btn({children,onClick,variant='default',small=false,disabled=false,className=''}) {
  const v={
    default:'bg-zinc-800 text-zinc-200 hover:bg-zinc-700 border-zinc-700',
    primary:'bg-blue-600 text-white hover:bg-blue-500 border-blue-600',
    danger:'bg-red-700 text-white hover:bg-red-600 border-red-700',
    success:'bg-emerald-700 text-white hover:bg-emerald-600 border-emerald-700',
    amber:'bg-amber-700 text-white hover:bg-amber-600 border-amber-700',
  };
  const sz=small?'px-2.5 py-1 text-xs':'px-4 py-2 text-sm';
  return (
    <button onClick={onClick} disabled={disabled}
      className={`inline-flex items-center gap-1.5 rounded-lg border font-medium transition ${v[variant]||v.default} ${sz} disabled:opacity-40 disabled:cursor-not-allowed ${className}`}>
      {children}
    </button>
  );
}

function Row({label,val}) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-zinc-500">{label}</span>
      <span className="text-zinc-200 font-mono">{val}</span>
    </div>
  );
}

/* ─── Login ───────────────────────────────────────────────────────────────── */

function LoginScreen({onLogin}) {
  const [secret,setSecret]=useState('');
  const [loading,setLoading]=useState(false);
  const [err,setErr]=useState('');
  async function submit() {
    if(!secret||loading) return;
    setLoading(true); setErr('');
    const res=await api('/api/admin/login',{method:'POST',body:{secret}});
    setLoading(false);
    if(res.success) onLogin();
    else setErr(res.error||'Secret salah.');
  }
  return (
    <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center mx-auto mb-4 text-blue-400"><Icon d={ICONS.lock} size={22}/></div>
          <h1 className="text-2xl font-bold text-white">Admin Panel</h1>
          <p className="text-zinc-500 text-sm mt-1">DongtubeDB Control Center</p>
        </div>
        <Card className="p-6">
          <Input label="Admin Secret" type="password" value={secret} onChange={setSecret}
            placeholder="Masukkan admin secret..." onKeyDown={e=>e.key==='Enter'&&submit()} className="mb-4"/>
          {err&&<div className="bg-red-900/30 border border-red-700/50 rounded-lg px-3 py-2 mb-3"><p className="text-red-400 text-sm">{err}</p></div>}
          <Btn variant="primary" onClick={submit} disabled={loading||!secret} className="w-full justify-center">
            {loading?<><Spinner/> Memeriksa...</>:'Masuk'}
          </Btn>
        </Card>
      </div>
    </div>
  );
}

/* ─── Overview ────────────────────────────────────────────────────────────── */

function OverviewTab({toast}) {
  const [data,setData]=useState(null);
  const [loading,setL]=useState(true);
  const load=useCallback(async()=>{
    setL(true);
    const res=await api('/api/admin/overview');
    setL(false);
    if(res.success) setData(res.data);
    else toast('Gagal load overview','error');
  },[]);
  useEffect(()=>{load();},[]);
  if(loading) return <div className="flex justify-center py-20"><Spinner size="lg"/></div>;
  if(!data) return null;
  const stats=[
    {label:'Total Users',val:data.users.total,icon:ICONS.user,c:'text-blue-400',bg:'bg-blue-900/30 border-blue-800'},
    {label:'API Keys Aktif',val:data.keys.active,icon:ICONS.key,c:'text-emerald-400',bg:'bg-emerald-900/30 border-emerald-800'},
    {label:'Total Files',val:data.files.totalFiles,icon:ICONS.files,c:'text-amber-400',bg:'bg-amber-900/30 border-amber-800'},
    {label:'KV Entries',val:data.kv.total,icon:ICONS.kv,c:'text-purple-400',bg:'bg-purple-900/30 border-purple-800'},
  ];
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map(s=>(
          <Card key={s.label} className="p-5">
            <div className={`w-9 h-9 rounded-lg border flex items-center justify-center mb-3 ${s.bg} ${s.c}`}><Icon d={s.icon} size={16}/></div>
            <div className={`text-3xl font-bold ${s.c} mb-0.5`}>{s.val}</div>
            <div className="text-xs text-zinc-500">{s.label}</div>
          </Card>
        ))}
      </div>
      <div className="grid md:grid-cols-2 gap-4">
        <Card className="p-5">
          <h3 className="font-semibold text-white mb-4 flex items-center gap-2"><Icon d={ICONS.server} size={14} className="text-zinc-400"/>Server</h3>
          <div className="space-y-2">
            <Row label="Uptime" val={`${Math.floor(data.server.uptime/3600)}j ${Math.floor((data.server.uptime%3600)/60)}m`}/>
            <Row label="Heap Used" val={fmt(data.server.memory.heapUsed)}/>
            <Row label="Heap Total" val={fmt(data.server.memory.heapTotal)}/>
            <Row label="RSS" val={fmt(data.server.memory.rss)}/>
            <div className="pt-2 border-t border-zinc-800">
              <div className="flex justify-between text-xs mb-1">
                <span className="text-zinc-500">Memory</span>
                <span className="text-zinc-300">{((data.server.memory.heapUsed/data.server.memory.heapTotal)*100).toFixed(1)}%</span>
              </div>
              <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                <div className="h-full bg-blue-500 rounded-full" style={{width:`${Math.min((data.server.memory.heapUsed/data.server.memory.heapTotal)*100,100)}%`}}/>
              </div>
            </div>
          </div>
        </Card>
        <Card className="p-5">
          <h3 className="font-semibold text-white mb-4 flex items-center gap-2"><Icon d={ICONS.fs} size={14} className="text-zinc-400"/>Storage</h3>
          <div className="space-y-2">
            <Row label="Total Files" val={data.storage.totalFiles}/>
            <Row label="Total Size" val={fmt(data.storage.totalSize)}/>
            {Object.entries(data.storage.categories||{}).map(([cat,info])=>
              info.files>0?<Row key={cat} label={cat} val={`${info.files} file (${fmt(info.size)})`}/>:null
            )}
          </div>
        </Card>
        <Card className="p-5">
          <h3 className="font-semibold text-white mb-4 flex items-center gap-2"><Icon d={ICONS.files} size={14} className="text-zinc-400"/>File per Kategori</h3>
          <div className="space-y-2">
            {Object.entries(data.files.byCategory||{}).map(([cat,count])=>(
              <div key={cat} className="flex items-center justify-between">
                <span className="text-zinc-400 text-sm">{cat}</span>
                <div className="flex items-center gap-2">
                  <div className="w-20 h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500 rounded-full" style={{width:`${Math.min((count/(data.files.totalFiles||1))*100,100)}%`}}/>
                  </div>
                  <span className="text-zinc-200 font-mono text-xs w-6 text-right">{count}</span>
                </div>
              </div>
            ))}
            {Object.keys(data.files.byCategory||{}).length===0&&<p className="text-zinc-500 text-sm">Belum ada file</p>}
          </div>
        </Card>
        <Card className="p-5">
          <h3 className="font-semibold text-white mb-4 flex items-center gap-2"><Icon d={ICONS.users} size={14} className="text-zinc-400"/>User Terbaru</h3>
          <div className="space-y-2">
            {data.users.list.map(u=>(
              <div key={u.id} className="flex items-center gap-2">
                {u.picture
                  ?<img src={u.picture} className="w-7 h-7 rounded-full" alt=""/>
                  :<div className="w-7 h-7 rounded-full bg-zinc-700 flex items-center justify-center text-xs font-bold">{(u.name||u.email||'?')[0].toUpperCase()}</div>}
                <span className="text-zinc-300 truncate flex-1 text-xs">{u.email}</span>
                <Badge color={u.plan==='max'?'amber':u.plan==='premium'?'blue':'zinc'}>{u.plan?.toUpperCase()||'FREE'}</Badge>
              </div>
            ))}
          </div>
        </Card>
      </div>
      <div className="flex justify-end"><Btn onClick={load}><Icon d={ICONS.refresh} size={13}/>Refresh</Btn></div>
    </div>
  );
}

/* ─── Users ───────────────────────────────────────────────────────────────── */

function UsersTab({toast}) {
  const [users,setUsers]=useState([]);
  const [loading,setL]=useState(true);
  const [editUser,setEdit]=useState(null);
  const [confirm,setConf]=useState(null);
  const [search,setSearch]=useState('');
  const [plans,setPlans]=useState([]);

  const load=useCallback(async()=>{
    setL(true);
    const [ur,pr]=await Promise.all([api('/api/admin/users'),api('/api/admin/plans')]);
    setL(false);
    if(ur.success) setUsers(ur.data); else toast('Gagal load users','error');
    if(pr.success) setPlans(pr.plans||[]);
  },[]);
  useEffect(()=>{load();},[]);

  async function doDelete(id) {
    const res=await api(`/api/admin/users/${id}`,{method:'DELETE'});
    setConf(null);
    if(res.success){toast('User dihapus');load();}
    else toast(res.error||'Gagal hapus','error');
  }

  const filtered=users.filter(u=>!search||u.email?.toLowerCase().includes(search.toLowerCase())||u.name?.toLowerCase().includes(search.toLowerCase()));
  const planColor=p=>plans.find(x=>x.id===p)?.color||'zinc';

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Input placeholder="Cari email / nama..." value={search} onChange={setSearch} className="flex-1"/>
        <Btn onClick={load}>Refresh</Btn>
      </div>
      <p className="text-zinc-500 text-xs">{filtered.length} dari {users.length} user</p>
      {loading?<div className="flex justify-center py-16"><Spinner size="lg"/></div>:(
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-zinc-800 text-left">
                  {['User','Plan','Key ID','Login Terakhir','Dibuat','Aksi'].map(h=>(
                    <th key={h} className="px-4 py-3 text-xs text-zinc-500 font-semibold uppercase tracking-wider">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/50">
                {filtered.map(u=>(
                  <tr key={u.id} className="hover:bg-zinc-800/30 transition">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        {u.picture?<img src={u.picture} className="w-7 h-7 rounded-full" alt=""/>
                          :<div className="w-7 h-7 rounded-full bg-zinc-700 flex items-center justify-center text-xs font-bold">{(u.name||u.email||'?')[0].toUpperCase()}</div>}
                        <div>
                          <div className="text-white font-medium">{u.name||'—'}</div>
                          <div className="text-zinc-500 text-xs">{u.email}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3"><Badge color={planColor(u.plan)}>{u.plan?.toUpperCase()||'FREE'}</Badge></td>
                    <td className="px-4 py-3 font-mono text-xs text-zinc-400">{u.keyId||'—'}</td>
                    <td className="px-4 py-3 text-zinc-400 text-xs">{ago(u.lastLogin)}</td>
                    <td className="px-4 py-3 text-zinc-400 text-xs">{ago(u.createdAt)}</td>
                    <td className="px-4 py-3">
                      <div className="flex gap-1.5">
                        <Btn small onClick={()=>setEdit(u)}>Edit</Btn>
                        <Btn small variant="danger" onClick={()=>setConf(u)}>Hapus</Btn>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filtered.length===0&&<p className="text-center text-zinc-500 py-8">Tidak ada user</p>}
          </div>
        </Card>
      )}
      {editUser&&<EditUserModal user={editUser} plans={plans} onClose={()=>setEdit(null)} onSave={()=>{setEdit(null);load();toast('User diupdate');}} toast={toast}/>}
      {confirm&&<Confirm msg={`Hapus user "${confirm.email}"? Data & file akan ikut terhapus secara permanen.`} onConfirm={()=>doDelete(confirm.id)} onCancel={()=>setConf(null)}/>}
    </div>
  );
}

// BUG FIX: EditUserModal sebelumnya plan hardcoded "free/premium/max"
// Sekarang: load dinamis dari API + support planExpiry, rateLimit, role, enabled
function EditUserModal({user,plans,onClose,onSave,toast}) {
  const [form,setForm]=useState({
    name:user.name||'',email:user.email||'',plan:user.plan||'free',
    planExpiry:user.planExpiry||'',
    rateLimit:user.keyInfo?.rateLimit||'',
    role:user.keyInfo?.role||'user',
    enabled:user.keyInfo?.enabled!==false,
  });
  const [loading,setL]=useState(false);
  const F=k=>v=>setForm(f=>({...f,[k]:v}));

  async function save() {
    setL(true);
    const body={name:form.name,email:form.email,plan:form.plan};
    if(form.planExpiry) body.planExpiry=form.planExpiry;
    if(user.keyId){
      if(form.rateLimit) body.rateLimit=parseInt(form.rateLimit);
      body.role=form.role; body.enabled=form.enabled;
    }
    const res=await api(`/api/admin/users/${user.id}`,{method:'PUT',body});
    setL(false);
    if(res.success) onSave(); else toast(res.error||'Gagal simpan','error');
  }

  return (
    <Modal title={`Edit User — ${user.email}`} onClose={onClose} wide>
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <Input label="Nama" value={form.name} onChange={F('name')}/>
          <Input label="Email" value={form.email} onChange={F('email')}/>
        </div>
        <div className="border-t border-zinc-800 pt-3">
          <p className="text-xs text-zinc-500 uppercase font-semibold mb-2">Plan & Expiry</p>
          <div className="grid grid-cols-2 gap-3">
            <Sel label="Plan" value={form.plan} onChange={F('plan')}>
              {(plans.length>0?plans:[{id:'free',name:'Free',price:0},{id:'premium',name:'Premium',price:10000},{id:'max',name:'Max',price:15000}])
                .map(p=><option key={p.id} value={p.id}>{p.name.toUpperCase()} — {p.price===0?'Gratis':fmtRp(p.price)+'/bln'}</option>)}
            </Sel>
            <Input label="Plan Expiry (kosong = tidak expires)" type="datetime-local" value={form.planExpiry} onChange={F('planExpiry')}/>
          </div>
        </div>
        {user.keyId&&(
          <div className="border-t border-zinc-800 pt-3">
            <p className="text-xs text-zinc-500 uppercase font-semibold mb-2">API Key Settings</p>
            <div className="grid grid-cols-3 gap-3">
              <Input label="Rate Limit (req/mnt)" type="number" value={form.rateLimit} onChange={F('rateLimit')} placeholder="Default plan"/>
              <Sel label="Role" value={form.role} onChange={F('role')}>
                <option value="user">user</option>
                <option value="admin">admin</option>
              </Sel>
              <div>
                <span className="block text-xs text-zinc-400 mb-1 font-medium">Status Key</span>
                <button onClick={()=>setForm(f=>({...f,enabled:!f.enabled}))}
                  className={`w-full py-2 px-3 rounded-lg text-sm font-medium border transition ${form.enabled?'bg-emerald-900/50 border-emerald-700 text-emerald-300':'bg-red-900/50 border-red-700 text-red-300'}`}>
                  {form.enabled?'✓ Aktif':'✗ Nonaktif'}
                </button>
              </div>
            </div>
          </div>
        )}
        <div className="flex gap-3 pt-2">
          <Btn onClick={onClose} className="flex-1 justify-center">Batal</Btn>
          <Btn variant="primary" onClick={save} disabled={loading} className="flex-1 justify-center">{loading?<Spinner/>:'Simpan'}</Btn>
        </div>
      </div>
    </Modal>
  );
}

/* ─── Keys ────────────────────────────────────────────────────────────────── */

function KeysTab({toast}) {
  const [keys,setKeys]=useState([]);
  const [loading,setL]=useState(true);
  const [showNew,setNew]=useState(false);
  const [confirm,setConf]=useState(null);
  const [newRaw,setNewRaw]=useState(null);
  const [editKey,setEditKey]=useState(null);

  const load=useCallback(async()=>{
    setL(true);
    const res=await api('/api/admin/keys');
    setL(false);
    if(res.success) setKeys(res.data); else toast('Gagal load keys','error');
  },[]);
  useEffect(()=>{load();},[]);

  async function toggleKey(id,enabled) {
    const res=await api(`/api/admin/keys/${id}`,{method:'PUT',body:{action:enabled?'disable':'enable'}});
    if(res.success){toast(enabled?'Key dinonaktifkan':'Key diaktifkan');load();}
    else toast(res.error||'Gagal','error');
  }
  async function rotateKey(id) {
    const res=await api(`/api/admin/keys/${id}`,{method:'PUT',body:{action:'rotate'}});
    if(res.success){setNewRaw(res.rawKey);load();toast('Key di-rotate — simpan sekarang!');}
    else toast(res.error||'Gagal rotate','error');
  }
  async function doDelete(id) {
    const res=await api(`/api/admin/keys/${id}`,{method:'DELETE'});
    setConf(null);
    if(res.success){toast('Key dihapus');load();}
    else toast(res.error||'Gagal hapus','error');
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-white font-semibold">{keys.length} API Keys</h2>
        <div className="flex gap-2">
          <Btn onClick={load}>Refresh</Btn>
          <Btn variant="primary" onClick={()=>setNew(true)}>+ Buat Key</Btn>
        </div>
      </div>
      {newRaw&&(
        <Card className="p-4 border-amber-700 bg-amber-900/10">
          <div className="flex items-center gap-2 text-amber-400 text-sm font-semibold mb-2"><Icon d={ICONS.warn} size={15}/>Simpan key ini sekarang — tidak akan ditampilkan lagi!</div>
          <code className="block bg-zinc-950 text-green-400 text-xs p-3 rounded-lg font-mono break-all select-all">{newRaw}</code>
          <div className="flex gap-2 mt-3">
            <Btn small onClick={()=>{navigator.clipboard?.writeText(newRaw);toast('Disalin!');}}>
                <Icon d={ICONS.copy} size={12}/>Salin</Btn>
            <Btn small onClick={()=>setNewRaw(null)}>Tutup</Btn>
          </div>
        </Card>
      )}
      {loading?<div className="flex justify-center py-16"><Spinner size="lg"/></div>:(
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-zinc-800 text-left">
                  {['Label','Role','Status','Storage','Rate Limit','Last Used','Aksi'].map(h=>(
                    <th key={h} className="px-4 py-3 text-xs text-zinc-500 font-semibold uppercase">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/50">
                {keys.map(k=>(
                  <tr key={k.id} className="hover:bg-zinc-800/30 transition">
                    <td className="px-4 py-3">
                      <div className="text-white font-medium">{k.label}</div>
                      <div className="text-zinc-500 font-mono text-xs">{k.id}</div>
                    </td>
                    <td className="px-4 py-3"><Badge color={k.role==='admin'?'red':'blue'}>{k.role}</Badge></td>
                    <td className="px-4 py-3"><Badge color={k.enabled?'green':'red'}>{k.enabled?'aktif':'nonaktif'}</Badge></td>
                    <td className="px-4 py-3 text-zinc-400 text-xs">{k.maxStorage?fmt(k.maxStorage):'∞'}</td>
                    <td className="px-4 py-3 text-zinc-400 text-xs">{k.rateLimit?.toLocaleString('id-ID')??'—'}/m</td>
                    <td className="px-4 py-3 text-zinc-400 text-xs">{ago(k.lastUsed)}</td>
                    <td className="px-4 py-3">
                      <div className="flex gap-1 flex-wrap">
                        <Btn small onClick={()=>setEditKey(k)}>Edit</Btn>
                        <Btn small onClick={()=>toggleKey(k.id,k.enabled)}>{k.enabled?'Nonaktif':'Aktif'}</Btn>
                        <Btn small variant="amber" onClick={()=>rotateKey(k.id)}>Rotate</Btn>
                        <Btn small variant="danger" onClick={()=>setConf(k)}>Hapus</Btn>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {keys.length===0&&<p className="text-center text-zinc-500 py-8">Belum ada API key</p>}
          </div>
        </Card>
      )}
      {showNew&&<NewKeyModal onClose={()=>setNew(false)} onCreated={raw=>{setNew(false);setNewRaw(raw);load();toast('Key dibuat!');}} toast={toast}/>}
      {editKey&&<EditKeyModal k={editKey} onClose={()=>setEditKey(null)} onSave={()=>{setEditKey(null);load();toast('Key diupdate');}} toast={toast}/>}
      {confirm&&<Confirm msg={`Hapus key "${confirm.label}"?`} onConfirm={()=>doDelete(confirm.id)} onCancel={()=>setConf(null)}/>}
    </div>
  );
}

function NewKeyModal({onClose,onCreated,toast}) {
  const [form,setForm]=useState({label:'',role:'user',maxStorage:5368709120,rateLimit:60});
  const [loading,setL]=useState(false);
  const F=k=>v=>setForm(f=>({...f,[k]:v}));
  async function save() {
    if(!form.label){toast('Label wajib diisi','error');return;}
    setL(true);
    const res=await api('/api/admin/keys',{method:'POST',body:form});
    setL(false);
    if(res.success) onCreated(res.rawKey); else toast(res.error||'Gagal buat key','error');
  }
  return (
    <Modal title="Buat API Key Baru" onClose={onClose}>
      <div className="space-y-3">
        <Input label="Label" value={form.label} onChange={F('label')} placeholder="misal: produksi-app"/>
        <Sel label="Role" value={form.role} onChange={F('role')}>
          <option value="user">user</option>
          <option value="admin">admin</option>
        </Sel>
        <Input label="Max Storage (bytes, 0=unlimited)" type="number" value={form.maxStorage} onChange={v=>setForm(f=>({...f,maxStorage:+v}))}/>
        <Input label="Rate Limit (req/menit)" type="number" value={form.rateLimit} onChange={v=>setForm(f=>({...f,rateLimit:+v}))}/>
        <div className="flex gap-3 pt-2">
          <Btn onClick={onClose} className="flex-1 justify-center">Batal</Btn>
          <Btn variant="primary" onClick={save} disabled={loading} className="flex-1 justify-center">{loading?<Spinner/>:'Buat Key'}</Btn>
        </div>
      </div>
    </Modal>
  );
}

function EditKeyModal({k,onClose,onSave,toast}) {
  const [form,setForm]=useState({label:k.label,role:k.role,maxStorage:k.maxStorage||0,rateLimit:k.rateLimit||60,enabled:k.enabled});
  const [loading,setL]=useState(false);
  const F=key=>v=>setForm(f=>({...f,[key]:v}));
  async function save() {
    setL(true);
    const res=await api(`/api/admin/keys/${k.id}`,{method:'PUT',body:{action:'update',...form}});
    setL(false);
    if(res.success) onSave(); else toast(res.error||'Gagal update','error');
  }
  return (
    <Modal title={`Edit Key — ${k.label}`} onClose={onClose}>
      <div className="space-y-3">
        <Input label="Label" value={form.label} onChange={F('label')}/>
        <Sel label="Role" value={form.role} onChange={F('role')}>
          <option value="user">user</option>
          <option value="admin">admin</option>
        </Sel>
        <Input label="Max Storage (bytes, 0=unlimited)" type="number" value={form.maxStorage} onChange={v=>setForm(f=>({...f,maxStorage:+v}))}/>
        <Input label="Rate Limit (req/menit)" type="number" value={form.rateLimit} onChange={v=>setForm(f=>({...f,rateLimit:+v}))}/>
        <div>
          <span className="block text-xs text-zinc-400 mb-1 font-medium">Status</span>
          <button onClick={()=>setForm(f=>({...f,enabled:!f.enabled}))}
            className={`px-4 py-2 rounded-lg text-sm font-medium border transition ${form.enabled?'bg-emerald-900/40 border-emerald-700 text-emerald-300':'bg-red-900/40 border-red-700 text-red-300'}`}>
            {form.enabled?'✓ Aktif':'✗ Nonaktif'} — klik untuk toggle
          </button>
        </div>
        <div className="flex gap-3 pt-2">
          <Btn onClick={onClose} className="flex-1 justify-center">Batal</Btn>
          <Btn variant="primary" onClick={save} disabled={loading} className="flex-1 justify-center">{loading?<Spinner/>:'Simpan'}</Btn>
        </div>
      </div>
    </Modal>
  );
}

/* ─── Plans ───────────────────────────────────────────────────────────────── */

const PLAN_COLORS=['zinc','blue','green','amber','red','purple','teal'];

function PlansTab({toast}) {
  const [data,setData]=useState(null);
  const [loading,setL]=useState(true);
  const [editPlan,setEdit]=useState(null);
  const [newPlan,setNew]=useState(false);
  const [confirm,setConf]=useState(null);

  const load=useCallback(async()=>{
    setL(true);
    const res=await api('/api/admin/plans');
    setL(false);
    if(res.success) setData(res); else toast('Gagal load plans','error');
  },[]);
  useEffect(()=>{load();},[]);

  async function doDelete(id) {
    const res=await api(`/api/admin/plans?id=${id}`,{method:'DELETE'});
    setConf(null);
    if(res.success){toast(res.message||'Plan dihapus');load();}
    else toast(res.error||'Gagal hapus','error');
  }

  if(loading) return <div className="flex justify-center py-20"><Spinner size="lg"/></div>;
  if(!data) return null;
  const {plans=[],revenue}=data;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          {label:'Total Revenue',val:fmtRp(revenue?.total),c:'text-emerald-400'},
          {label:'Paid Orders',val:revenue?.paid,c:'text-blue-400'},
          {label:'Pending',val:revenue?.pending,c:'text-amber-400'},
          {label:'Expired',val:revenue?.expired,c:'text-zinc-400'},
        ].map(s=>(
          <Card key={s.label} className="p-4">
            <div className={`text-2xl font-bold ${s.c}`}>{s.val}</div>
            <div className="text-xs text-zinc-500 mt-0.5">{s.label}</div>
          </Card>
        ))}
      </div>
      <div className="flex items-center justify-between">
        <h2 className="text-white font-semibold text-lg">Plan Tersedia ({plans.length})</h2>
        <div className="flex gap-2">
          <Btn onClick={load}>Refresh</Btn>
          <Btn variant="primary" onClick={()=>setNew(true)}>+ Tambah Plan</Btn>
        </div>
      </div>
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
        {plans.map(plan=>(
          <Card key={plan.id} className="p-5 flex flex-col gap-3">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Badge color={plan.color}>{plan.id.toUpperCase()}</Badge>
                  {!plan.active&&<Badge color="red">NONAKTIF</Badge>}
                </div>
                <h3 className="text-white font-bold text-lg">{plan.name}</h3>
                <p className="text-zinc-500 text-xs mt-0.5">{plan.description}</p>
              </div>
              <div className="text-right">
                <div className="text-emerald-400 font-bold text-lg">{plan.price===0?'Gratis':fmtRp(plan.price)}</div>
                {plan.price>0&&<div className="text-zinc-500 text-xs">/bulan</div>}
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center">
              {[
                {val:plan.storageMB>=1024?`${(plan.storageMB/1024).toFixed(0)} GB`:`${plan.storageMB} MB`,lbl:'Storage'},
                {val:plan.rateLimit>=1000?`${(plan.rateLimit/1000).toFixed(0)}k`:plan.rateLimit,lbl:'Req/mnt'},
                {val:`${plan.maxFileSizeMB} MB`,lbl:'Max File'},
              ].map(x=>(
                <div key={x.lbl} className="bg-zinc-800/50 rounded-lg p-2">
                  <div className="text-white font-semibold text-sm">{x.val}</div>
                  <div className="text-zinc-500 text-xs">{x.lbl}</div>
                </div>
              ))}
            </div>
            {plan.features?.length>0&&(
              <ul className="space-y-1">
                {plan.features.map((f,i)=>(
                  <li key={i} className="text-zinc-400 text-xs flex items-center gap-1.5">
                    <span className="text-emerald-500">✓</span>{f}
                  </li>
                ))}
              </ul>
            )}
            <div className="flex items-center justify-between mt-auto pt-2 border-t border-zinc-800">
              <span className="text-zinc-500 text-xs">{plan.userCount} user · {fmtRp(plan.revenue)}</span>
              <div className="flex gap-1.5">
                <Btn small onClick={()=>setEdit(plan)}>Edit</Btn>
                {plan.id!=='free'&&<Btn small variant="danger" onClick={()=>setConf(plan)}>Hapus</Btn>}
              </div>
            </div>
          </Card>
        ))}
      </div>
      {newPlan&&(
        <PlanFormModal title="Tambah Plan Baru" onClose={()=>setNew(false)}
          onSave={async body=>{
            const res=await api('/api/admin/plans',{method:'POST',body});
            if(res.success){setNew(false);load();toast(`Plan '${res.plan.name}' dibuat!`);}
            else toast(res.error||'Gagal buat plan','error');
          }} toast={toast}/>
      )}
      {editPlan&&(
        <PlanFormModal title={`Edit Plan — ${editPlan.name}`} initial={editPlan} onClose={()=>setEdit(null)}
          onSave={async body=>{
            const res=await api('/api/admin/plans',{method:'PUT',body:{id:editPlan.id,...body}});
            if(res.success){setEdit(null);load();toast('Plan diupdate!');}
            else toast(res.error||'Gagal update','error');
          }} toast={toast}/>
      )}
      {confirm&&<Confirm msg={`Hapus plan "${confirm.name}"? Plan yang masih dipakai user tidak bisa dihapus.`} onConfirm={()=>doDelete(confirm.id)} onCancel={()=>setConf(null)}/>}
    </div>
  );
}

function PlanFormModal({title,initial,onClose,onSave,toast}) {
  const [form,setForm]=useState({
    id:initial?.id||'',name:initial?.name||'',price:initial?.price??0,
    storageMB:initial?.storageMB??10,rateLimit:initial?.rateLimit??60,
    maxFileSizeMB:initial?.maxFileSizeMB??10,color:initial?.color||'zinc',
    description:initial?.description||'',
    features:(initial?.features||[]).join('\n'),
    active:initial?.active!==false,
  });
  const [loading,setL]=useState(false);
  const F=k=>v=>setForm(f=>({...f,[k]:v}));
  const isEdit=!!initial;

  async function save() {
    if(!form.name){toast('Nama wajib diisi','error');return;}
    if(!isEdit&&!form.id){toast('ID wajib diisi','error');return;}
    setL(true);
    await onSave({
      ...form,
      price:parseInt(form.price)||0,
      storageMB:parseFloat(form.storageMB)||10,
      rateLimit:parseInt(form.rateLimit)||60,
      maxFileSizeMB:parseInt(form.maxFileSizeMB)||10,
      features:form.features.split('\n').map(x=>x.trim()).filter(Boolean),
    });
    setL(false);
  }

  return (
    <Modal title={title} onClose={onClose} wide>
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          {!isEdit&&<Input label="ID (tidak bisa diubah)" value={form.id} onChange={F('id')} placeholder="pro" help="Huruf kecil, angka, -, _"/>}
          <Input label="Nama Plan" value={form.name} onChange={F('name')} placeholder="Pro" className={isEdit?'col-span-2':''}/>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Input label="Harga (IDR/bulan, 0=gratis)" type="number" value={form.price} onChange={F('price')}/>
          <div>
            <span className="block text-xs text-zinc-400 mb-1 font-medium">Warna Badge</span>
            <div className="flex gap-1.5 flex-wrap">
              {PLAN_COLORS.map(c=>(
                <button key={c} onClick={()=>setForm(f=>({...f,color:c}))}
                  className={`rounded-md transition ${form.color===c?'ring-2 ring-white ring-offset-1 ring-offset-zinc-900':''}`}>
                  <Badge color={c}>{c}</Badge>
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-3">
          <Input label="Storage Limit (MB)" type="number" value={form.storageMB} onChange={F('storageMB')}
            help={form.storageMB>=1024?`= ${(form.storageMB/1024).toFixed(2)} GB`:`= ${form.storageMB} MB`}/>
          <Input label="Rate Limit (req/mnt)" type="number" value={form.rateLimit} onChange={F('rateLimit')}/>
          <Input label="Max File Size (MB)" type="number" value={form.maxFileSizeMB} onChange={F('maxFileSizeMB')}/>
        </div>
        <Input label="Deskripsi" value={form.description} onChange={F('description')} placeholder="Untuk pengguna yang..."/>
        <div>
          <span className="block text-xs text-zinc-400 mb-1 font-medium">Fitur (satu per baris)</span>
          <textarea value={form.features} onChange={e=>setForm(f=>({...f,features:e.target.value}))}
            rows={4} placeholder={"500 MB Storage\nAkses penuh\n50.000 req/mnt"}
            className="w-full bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500 resize-y"/>
        </div>
        <button onClick={()=>setForm(f=>({...f,active:!f.active}))}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition ${form.active?'bg-emerald-900/50 border-emerald-700 text-emerald-300':'bg-zinc-800 border-zinc-700 text-zinc-400'}`}>
          {form.active?'✓ Plan Aktif':'✗ Plan Nonaktif'}
        </button>
        <div className="flex gap-3 pt-2">
          <Btn onClick={onClose} className="flex-1 justify-center">Batal</Btn>
          <Btn variant="primary" onClick={save} disabled={loading} className="flex-1 justify-center">{loading?<Spinner/>:isEdit?'Simpan Perubahan':'Buat Plan'}</Btn>
        </div>
      </div>
    </Modal>
  );
}

/* ─── Settings ────────────────────────────────────────────────────────────── */

function SettingsTab({toast}) {
  const [settings,setSettings]=useState(null);
  const [loading,setL]=useState(true);
  const [saving,setSaving]=useState(false);
  const [form,setForm]=useState({});
  const F=k=>v=>setForm(f=>({...f,[k]:v}));

  const load=useCallback(async()=>{
    setL(true);
    const res=await api('/api/admin/settings');
    setL(false);
    if(res.success){
      setSettings(res.settings);
      const s=res.settings;
      setForm({
        domain:s.domain||'',debug:s.debug||false,
        maxFileSizeMB:s.maxFileSizeMB||500,
        freeStorageBytes:s.freeStorageBytes||10485760,
        premiumStorageBytes:s.premiumStorageBytes||524288000,
        maxStorageBytes:s.maxStorageBytes||1073741824,
        freeRateLimit:s.freeRateLimit||10000,
        premiumRateLimit:s.premiumRateLimit||50000,
        maxRateLimit:s.maxRateLimit||1000000,
        pakasirSlug:s.pakasirSlug||'',
        pakasirApiKey:s.pakasirApiKey||'',
        orderTtlMin:s.orderTtlMin||15,
        googleClientId:s.googleClientId||'',
        googleClientSecret:s.googleClientSecret||'',
      });
    } else toast('Gagal load settings','error');
  },[]);
  useEffect(()=>{load();},[]);

  async function save(data) {
    setSaving(true);
    const res=await api('/api/admin/settings',{method:'PUT',body:data});
    setSaving(false);
    if(res.success){setSettings(res.settings);toast(res.message||'Tersimpan!');}
    else toast(res.error||'Gagal simpan','error');
  }

  const b2h=b=>{if(b>=1073741824)return `${(b/1073741824).toFixed(2)} GB`;return `${(b/1048576).toFixed(0)} MB`;};

  if(loading) return <div className="flex justify-center py-20"><Spinner size="lg"/></div>;

  const Section=({title,desc,onSave,children})=>(
    <Card className="p-5">
      <div className="flex items-center justify-between mb-4">
        <div><h3 className="font-bold text-white">{title}</h3>{desc&&<p className="text-zinc-500 text-xs mt-0.5">{desc}</p>}</div>
        <Btn variant="primary" disabled={saving} onClick={onSave}>{saving?<Spinner/>:'Simpan'}</Btn>
      </div>
      {children}
    </Card>
  );

  return (
    <div className="space-y-6">
      {settings?.updatedAt&&(
        <div className="bg-zinc-800/50 border border-zinc-700 rounded-xl px-4 py-2 text-xs text-zinc-400">
          Terakhir disimpan: {new Date(settings.updatedAt).toLocaleString('id-ID')}
        </div>
      )}

      <Section title="Server" desc="Konfigurasi dasar server"
        onSave={()=>save({domain:form.domain,debug:form.debug})}>
        <div className="grid md:grid-cols-2 gap-4">
          <Input label="Domain" value={form.domain} onChange={F('domain')} placeholder="https://dongtube.my.id" help="URL publik tanpa trailing slash"/>
          <div>
            <span className="block text-xs text-zinc-400 mb-1 font-medium">Node Environment</span>
            <div className="bg-zinc-800 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-zinc-400">{settings?.nodeEnv||'production'} <span className="text-xs text-zinc-600">(read-only)</span></div>
          </div>
          <div>
            <span className="block text-xs text-zinc-400 mb-1 font-medium">Debug Mode</span>
            <button onClick={()=>setForm(f=>({...f,debug:!f.debug}))}
              className={`px-4 py-2 rounded-lg text-sm font-medium border transition ${form.debug?'bg-amber-900/40 border-amber-700 text-amber-300':'bg-zinc-800 border-zinc-700 text-zinc-400'}`}>
              {form.debug?'Debug ON (aktif)':'Debug OFF'}
            </button>
          </div>
          <div>
            <span className="block text-xs text-zinc-400 mb-1 font-medium">Direktori (read-only via env)</span>
            <div className="space-y-1 text-xs font-mono text-zinc-500">
              <div>Data: <span className="text-zinc-300">{settings?.dataDir}</span></div>
              <div>Storage: <span className="text-zinc-300">{settings?.storageDir}</span></div>
              <div>Log: <span className="text-zinc-300">{settings?.logDir}</span></div>
            </div>
          </div>
        </div>
      </Section>

      <Section title="File &amp; Storage" desc="Batas ukuran file dan storage per plan"
        onSave={()=>save({maxFileSizeMB:+form.maxFileSizeMB,freeStorageBytes:+form.freeStorageBytes,premiumStorageBytes:+form.premiumStorageBytes,maxStorageBytes:+form.maxStorageBytes})}>
        <div className="grid md:grid-cols-2 gap-4">
          <Input label="Max File Size Global (MB)" type="number" value={form.maxFileSizeMB} onChange={F('maxFileSizeMB')} help="Batas per file upload"/>
          <div/>
          <Input label="Free Plan Storage (bytes)" type="number" value={form.freeStorageBytes} onChange={F('freeStorageBytes')} help={`= ${b2h(+form.freeStorageBytes||0)}`}/>
          <Input label="Premium Plan Storage (bytes)" type="number" value={form.premiumStorageBytes} onChange={F('premiumStorageBytes')} help={`= ${b2h(+form.premiumStorageBytes||0)}`}/>
          <Input label="Max Plan Storage (bytes)" type="number" value={form.maxStorageBytes} onChange={F('maxStorageBytes')} help={`= ${b2h(+form.maxStorageBytes||0)}`}/>
        </div>
        <p className="text-xs text-amber-400 mt-3 flex items-center gap-1"><Icon d={ICONS.warn} size={12}/>Perubahan storage memerlukan restart server</p>
      </Section>

      <Section title="Rate Limits" desc="Batas request per menit per plan"
        onSave={()=>save({freeRateLimit:+form.freeRateLimit,premiumRateLimit:+form.premiumRateLimit,maxRateLimit:+form.maxRateLimit})}>
        <div className="grid md:grid-cols-3 gap-4">
          <Input label="Free (req/mnt)" type="number" value={form.freeRateLimit} onChange={F('freeRateLimit')}/>
          <Input label="Premium (req/mnt)" type="number" value={form.premiumRateLimit} onChange={F('premiumRateLimit')}/>
          <Input label="Max (req/mnt)" type="number" value={form.maxRateLimit} onChange={F('maxRateLimit')}/>
        </div>
      </Section>

      <Section title="Payment — Pakasir QRIS" desc="Konfigurasi payment gateway"
        onSave={()=>save({pakasirSlug:form.pakasirSlug,pakasirApiKey:form.pakasirApiKey,orderTtlMin:+form.orderTtlMin})}>
        <div className="grid md:grid-cols-2 gap-4">
          <Input label="Pakasir Slug" value={form.pakasirSlug} onChange={F('pakasirSlug')} placeholder="nama-slug"/>
          <Input label="Pakasir API Key" value={form.pakasirApiKey} onChange={F('pakasirApiKey')} type="password" placeholder="••••••••"/>
          <Input label="Order TTL (menit)" type="number" value={form.orderTtlMin} onChange={F('orderTtlMin')} help="Berapa menit sebelum order expired"/>
        </div>
      </Section>

      <Section title="Google OAuth" desc="Kredensial login Google"
        onSave={()=>save({googleClientId:form.googleClientId,googleClientSecret:form.googleClientSecret})}>
        <div className="grid md:grid-cols-2 gap-4">
          <Input label="Google Client ID" value={form.googleClientId} onChange={F('googleClientId')}
            placeholder={settings?.googleClientIdSet?'(sudah diset)':'xxxxxxx.apps.googleusercontent.com'}/>
          <Input label="Google Client Secret" type="password" value={form.googleClientSecret} onChange={F('googleClientSecret')}
            placeholder={settings?.googleClientSecretSet?'(sudah diset)':'GOCSPX-...'}/>
        </div>
        <p className="text-xs text-amber-400 mt-3 flex items-center gap-1"><Icon d={ICONS.warn} size={12}/>Perlu restart server + pastikan redirect URI sudah terdaftar di Google Console</p>
      </Section>
    </div>
  );
}

/* ─── Files ───────────────────────────────────────────────────────────────── */

function FilesTab({toast}) {
  const [data,setData]=useState({items:[],total:0,pages:0});
  const [loading,setL]=useState(true);
  const [page,setPage]=useState(1);
  const [search,setSrch]=useState('');
  const [confirm,setConf]=useState(null);

  const load=useCallback(async(p=1,s='')=>{
    setL(true);
    const res=await api(`/api/admin/files?page=${p}&limit=50&search=${encodeURIComponent(s)}`);
    setL(false);
    if(res.success) setData(res.data); else toast('Gagal load files','error');
  },[]);
  useEffect(()=>{load();},[]);

  async function doDelete(id) {
    const res=await api(`/api/admin/files/${id}`,{method:'DELETE'});
    setConf(null);
    if(res.success){toast('File dihapus');load(page,search);}
    else toast(res.error||'Gagal hapus','error');
  }
  function go(p){setPage(p);load(p,search);}

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Input placeholder="Cari nama file..." value={search} onChange={setSrch}
          onKeyDown={e=>e.key==='Enter'&&(setPage(1),load(1,search))} className="flex-1"/>
        <Btn onClick={()=>{setPage(1);load(1,search);}}>Cari</Btn>
        <Btn onClick={()=>load(page,search)}>Refresh</Btn>
      </div>
      <p className="text-zinc-500 text-sm">{data.total} file total</p>
      {loading?<div className="flex justify-center py-16"><Spinner size="lg"/></div>:(
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-zinc-800 text-left">
                  {['Nama File','Kategori','Ukuran','Unduhan','Public','Diupload','Aksi'].map(h=>(
                    <th key={h} className="px-4 py-3 text-xs text-zinc-500 font-semibold uppercase">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/50">
                {data.items.map(f=>(
                  <tr key={f.id} className="hover:bg-zinc-800/30 transition">
                    <td className="px-4 py-3">
                      <div className="text-white font-medium truncate max-w-[200px]">{f.originalName}</div>
                      <div className="text-zinc-500 text-xs font-mono">{f.id}</div>
                    </td>
                    <td className="px-4 py-3"><Badge>{f.category}</Badge></td>
                    <td className="px-4 py-3 text-zinc-400 text-xs">{fmt(f.size)}</td>
                    <td className="px-4 py-3 text-zinc-400 text-xs">{f.downloads}</td>
                    <td className="px-4 py-3"><Badge color={f.public?'green':'zinc'}>{f.public?'ya':'tidak'}</Badge></td>
                    <td className="px-4 py-3 text-zinc-400 text-xs">{ago(f.uploadedAt)}</td>
                    <td className="px-4 py-3"><Btn small variant="danger" onClick={()=>setConf(f)}>Hapus</Btn></td>
                  </tr>
                ))}
              </tbody>
            </table>
            {data.items.length===0&&<p className="text-center text-zinc-500 py-8">Belum ada file</p>}
          </div>
          {data.pages>1&&(
            <div className="flex gap-2 justify-center p-4 flex-wrap">
              {Array.from({length:data.pages},(_,i)=>i+1).map(p=>(
                <button key={p} onClick={()=>go(p)}
                  className={`w-8 h-8 rounded-lg text-sm font-medium transition ${p===page?'bg-blue-600 text-white':'bg-zinc-800 text-zinc-400 hover:bg-zinc-700'}`}>{p}</button>
              ))}
            </div>
          )}
        </Card>
      )}
      {confirm&&<Confirm msg={`Hapus file "${confirm.originalName}"?`} onConfirm={()=>doDelete(confirm.id)} onCancel={()=>setConf(null)}/>}
    </div>
  );
}

/* ─── KV Store ────────────────────────────────────────────────────────────── */

function KVTab({toast}) {
  const [entries,setEntries]=useState([]);
  const [loading,setL]=useState(true);
  const [prefix,setPrefix]=useState('');
  const [viewKey,setViewKey]=useState(null);
  const [editEntry,setEdit]=useState(null);
  const [confirm,setConf]=useState(null);
  const [newEntry,setNewE]=useState(false);

  const load=useCallback(async(p=prefix)=>{
    setL(true);
    const res=await api(`/api/admin/kv?prefix=${encodeURIComponent(p)}`);
    setL(false);
    if(res.success) setEntries(res.data); else toast('Gagal load KV','error');
  },[prefix]);
  useEffect(()=>{load('');},[]);

  async function doDelete(key) {
    const res=await api(`/api/admin/kv?key=${encodeURIComponent(key)}`,{method:'DELETE'});
    setConf(null);
    if(res.success){toast('Entry dihapus');load(prefix);}
    else toast(res.error||'Gagal','error');
  }
  async function openView(key) {
    const res=await api(`/api/admin/kv?key=${encodeURIComponent(key)}`);
    if(res.success) setViewKey({key,data:res.data,sha:res.sha});
    else toast(res.error||'Gagal baca','error');
  }

  return (
    <div className="space-y-4">
      <div className="flex gap-3 items-center">
        <Input placeholder="Filter prefix..." value={prefix} onChange={setPrefix}
          onKeyDown={e=>e.key==='Enter'&&load(prefix)} className="flex-1"/>
        <Btn onClick={()=>load(prefix)}>Filter</Btn>
        <Btn onClick={()=>load(prefix)}>Refresh</Btn>
        <Btn variant="primary" onClick={()=>setNewE(true)}>+ Tulis</Btn>
      </div>
      <p className="text-zinc-500 text-sm">{entries.length} entries</p>
      {loading?<div className="flex justify-center py-16"><Spinner size="lg"/></div>:(
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-zinc-800 text-left">
                  {['Key','SHA','Updated','Aksi'].map(h=>(
                    <th key={h} className="px-4 py-3 text-xs text-zinc-500 font-semibold uppercase">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/50">
                {entries.map(e=>(
                  <tr key={e.key} className="hover:bg-zinc-800/30 transition">
                    <td className="px-4 py-3 font-mono text-blue-400 text-xs max-w-[300px] truncate">{e.key}</td>
                    <td className="px-4 py-3 font-mono text-xs text-zinc-500">{e.sha?.slice(0,12)}...</td>
                    <td className="px-4 py-3 text-zinc-400 text-xs">{ago(e.updatedAt)}</td>
                    <td className="px-4 py-3">
                      <div className="flex gap-1">
                        <Btn small onClick={()=>openView(e.key)}>Lihat</Btn>
                        <Btn small variant="amber" onClick={()=>setEdit(e.key)}>Edit</Btn>
                        <Btn small variant="danger" onClick={()=>setConf(e.key)}>Hapus</Btn>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {entries.length===0&&<p className="text-center text-zinc-500 py-8">Belum ada data</p>}
          </div>
        </Card>
      )}
      {viewKey&&(
        <Modal title={`KV: ${viewKey.key}`} onClose={()=>setViewKey(null)} wide>
          <pre className="bg-zinc-950 text-green-300 text-xs p-4 rounded-xl overflow-auto max-h-96 font-mono">{JSON.stringify(viewKey.data,null,2)}</pre>
          <p className="text-zinc-500 text-xs mt-2">SHA: {viewKey.sha}</p>
        </Modal>
      )}
      {(editEntry!==null||newEntry)&&(
        <KVWriteModal kvKey={typeof editEntry==='string'?editEntry:null}
          onClose={()=>{setEdit(null);setNewE(false);}}
          onSave={()=>{setEdit(null);setNewE(false);load(prefix);toast('Tersimpan');}}
          toast={toast}/>
      )}
      {confirm&&<Confirm msg={`Hapus key "${confirm}"?`} onConfirm={()=>doDelete(confirm)} onCancel={()=>setConf(null)}/>}
    </div>
  );
}

function KVWriteModal({kvKey,onClose,onSave,toast}) {
  const [key,setKey]=useState(kvKey||'');
  const [val,setVal]=useState('');
  const [loading,setL]=useState(false);
  const [loaded,setLoaded]=useState(!kvKey);
  useEffect(()=>{
    if(!kvKey) return;
    api(`/api/admin/kv?key=${encodeURIComponent(kvKey)}`).then(res=>{
      if(res.success) setVal(JSON.stringify(res.data,null,2));
      setLoaded(true);
    });
  },[kvKey]);
  async function save() {
    if(!key){toast('Key diperlukan','error');return;}
    let parsed;
    try{parsed=JSON.parse(val);}catch{toast('Value harus JSON valid','error');return;}
    setL(true);
    const res=await api('/api/admin/kv',{method:'PUT',body:{key,value:parsed}});
    setL(false);
    if(res.success) onSave(); else toast(res.error||'Gagal tulis','error');
  }
  return (
    <Modal title={kvKey?`Edit KV: ${kvKey}`:'Tulis KV Baru'} onClose={onClose} wide>
      {!loaded?<div className="flex justify-center py-8"><Spinner size="lg"/></div>:(
        <div className="space-y-3">
          <Input label="Key" value={key} onChange={setKey} disabled={!!kvKey} placeholder="my-key"/>
          <label className="block">
            <span className="block text-xs text-zinc-400 mb-1 font-medium">Value (JSON)</span>
            <textarea value={val} onChange={e=>setVal(e.target.value)} rows={12}
              className="w-full bg-zinc-950 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-green-300 font-mono focus:outline-none focus:border-blue-500 resize-y"/>
          </label>
          <div className="flex gap-3 pt-1">
            <Btn onClick={onClose} className="flex-1 justify-center">Batal</Btn>
            <Btn variant="primary" onClick={save} disabled={loading} className="flex-1 justify-center">{loading?<Spinner/>:'Simpan'}</Btn>
          </div>
        </div>
      )}
    </Modal>
  );
}

/* ─── DB Editor ───────────────────────────────────────────────────────────── */

function DBTab({toast}) {
  const [tables,setTables]=useState([]);
  const [active,setActive]=useState(null);
  const [rows,setRows]=useState([]);
  const [rawJson,setRawJson]=useState('');
  const [editing,setEditing]=useState(false);
  const [loading,setL]=useState(true);

  const loadTables=useCallback(async()=>{
    setL(true);
    const res=await api('/api/admin/db');
    setL(false);
    if(res.success) setTables(res.data); else toast('Gagal load tabel','error');
  },[]);
  useEffect(()=>{loadTables();},[]);

  async function openTable(name) {
    setActive(name);setEditing(false);
    const res=await api(`/api/admin/db?table=${name}`);
    if(res.success){setRows(res.data);setRawJson(JSON.stringify(res.data,null,2));}
    else toast(res.error||'Gagal load tabel','error');
  }
  async function saveTable() {
    let parsed;
    try{parsed=JSON.parse(rawJson);}catch{toast('JSON tidak valid','error');return;}
    if(!Array.isArray(parsed)){toast('Harus berupa array','error');return;}
    const res=await api('/api/admin/db',{method:'PUT',body:{table:active,data:parsed}});
    if(res.success){toast('Tabel disimpan');setEditing(false);openTable(active);}
    else toast(res.error||'Gagal simpan','error');
  }

  return (
    <div className="space-y-4">
      <div className="flex gap-3 items-center">
        <Btn onClick={loadTables}>Refresh</Btn>
        {active&&<span className="text-zinc-500 text-sm">Tabel: <span className="text-white font-medium">{active}</span> — {rows.length} baris</span>}
      </div>
      {loading&&!tables.length?<div className="flex justify-center py-16"><Spinner size="lg"/></div>:(
        <div className="grid md:grid-cols-4 gap-4">
          <Card className="p-3 md:col-span-1 h-fit">
            <p className="text-xs text-zinc-500 font-semibold uppercase mb-2">Tabel</p>
            <div className="space-y-1">
              {tables.map(t=>(
                <button key={t.name} onClick={()=>openTable(t.name)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm transition ${active===t.name?'bg-blue-600 text-white':'text-zinc-300 hover:bg-zinc-800'}`}>
                  <div className="font-medium">{t.name}</div>
                  <div className="text-xs opacity-60">{t.location} · {fmt(t.size)}</div>
                </button>
              ))}
            </div>
          </Card>
          <div className="md:col-span-3 space-y-3">
            {active?(
              <>
                <div className="flex items-center justify-between">
                  <div><h3 className="text-white font-semibold">{active}</h3><p className="text-zinc-500 text-xs">{rows.length} baris</p></div>
                  <div className="flex gap-2">
                    {editing?(
                      <><Btn onClick={()=>{setEditing(false);setRawJson(JSON.stringify(rows,null,2));}}>Batal</Btn><Btn variant="success" onClick={saveTable}>Simpan</Btn></>
                    ):(
                      <Btn variant="amber" onClick={()=>setEditing(true)}>Edit JSON</Btn>
                    )}
                  </div>
                </div>
                <Card className="overflow-hidden">
                  <textarea value={rawJson} onChange={e=>setRawJson(e.target.value)} readOnly={!editing} rows={24}
                    className={`w-full bg-zinc-950 text-xs font-mono p-4 focus:outline-none resize-none transition ${editing?'text-amber-300 border border-amber-700 rounded-2xl':'text-green-300'}`}/>
                </Card>
              </>
            ):(
              <Card className="p-8 text-center text-zinc-500">Pilih tabel di sebelah kiri</Card>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── Backup ──────────────────────────────────────────────────────────────── */

function BackupTab({toast}) {
  const [loading,setLoading]=useState(false);
  const [importing,setImporting]=useState(false);
  const [importFile,setFile]=useState(null);
  const [importMode,setMode]=useState('replace');
  const [importScope,setIScope]=useState('all');
  const [preview,setPreview]=useState(null);
  const fileRef=useRef();

  async function doExport(scope) {
    setLoading(true);
    try {
      const res=await fetch(`/api/admin/db/export?scope=${scope}&pretty=1`,{credentials:'include'});
      if(!res.ok){const e=await res.json().catch(()=>({}));toast(e.error||'Gagal export','error');return;}
      const cd=res.headers.get('content-disposition')||'';
      const match=cd.match(/filename="([^"]+)"/);
      const filename=match?match[1]:`dongtube-backup-${scope}.json`;
      const blob=await res.blob();
      const url=URL.createObjectURL(blob);
      const a=document.createElement('a');
      a.href=url;a.download=filename;
      document.body.appendChild(a);a.click();document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast(`Export selesai (${scope})`);
    } catch(e){toast(e.message||'Gagal export','error');}
    finally{setLoading(false);}
  }

  function handleFileChange(e) {
    const f=e.target.files?.[0];
    if(!f) return;
    setFile(f);setPreview(null);
    const reader=new FileReader();
    reader.onload=ev=>{
      try {
        const parsed=JSON.parse(ev.target.result);
        const stats={};
        if(parsed.db){stats.db={};for(const [k,v] of Object.entries(parsed.db)) stats.db[k]=Array.isArray(v)?v.length:0;}
        if(parsed.users){stats.users={};for(const [k,v] of Object.entries(parsed.users)) stats.users[k]=Array.isArray(v)?v.length:0;}
        setPreview({meta:parsed.meta||{},stats,size:f.size,valid:true});
      } catch(err){setPreview({valid:false,error:err.message});}
    };
    reader.readAsText(f);
  }

  async function doImport() {
    if(!importFile||!preview?.valid){toast('Pilih file yang valid','error');return;}
    setImporting(true);
    try {
      const parsed=JSON.parse(await importFile.text());
      const res=await api('/api/admin/db/import',{method:'POST',body:{data:parsed,mode:importMode,scope:importScope}});
      if(res.success){
        toast(`Import selesai — ${res.summary.totalImported} tabel`);
        setFile(null);setPreview(null);
        if(fileRef.current) fileRef.current.value='';
      } else toast(res.error||'Gagal import','error');
    } catch(e){toast(e.message||'Gagal import','error');}
    finally{setImporting(false);}
  }

  return (
    <div className="space-y-6">
      <Card className="p-5">
        <h2 className="text-white font-bold mb-1">Export / Backup Database</h2>
        <p className="text-zinc-400 text-sm mb-5">Download seluruh isi database sebagai file JSON.</p>
        <div className="grid sm:grid-cols-3 gap-3">
          {[
            {scope:'all',label:'Export Semua',desc:'DB + Users',c:'bg-blue-600 hover:bg-blue-500'},
            {scope:'db',label:'Export DB saja',desc:'Tanpa tabel users',c:'bg-emerald-700 hover:bg-emerald-600'},
            {scope:'users',label:'Export Users',desc:'Tabel users saja',c:'bg-amber-700 hover:bg-amber-600'},
          ].map(({scope,label,desc,c})=>(
            <button key={scope} onClick={()=>doExport(scope)} disabled={loading}
              className={`${c} disabled:opacity-50 text-white rounded-xl p-4 text-left transition active:scale-95`}>
              <div className="font-semibold text-sm">{label}</div>
              <div className="text-xs opacity-70 mt-0.5">{desc}</div>
            </button>
          ))}
        </div>
        {loading&&<div className="flex items-center gap-2 mt-4 text-zinc-400 text-sm"><Spinner/> Mempersiapkan...</div>}
      </Card>

      <Card className="p-5">
        <h2 className="text-white font-bold mb-1">Import / Restore Database</h2>
        <p className="text-zinc-400 text-sm mb-5">Restore dari file backup JSON. <strong className="text-white">Replace</strong> = ganti penuh. <strong className="text-white">Merge</strong> = tambah saja.</p>
        <div className="space-y-4">
          <div>
            <label className="block text-xs text-zinc-400 mb-2 font-medium">File Backup (.json)</label>
            <input ref={fileRef} type="file" accept=".json" onChange={handleFileChange}
              className="block w-full text-sm text-zinc-300 file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-zinc-700 file:text-zinc-200 hover:file:bg-zinc-600 file:cursor-pointer"/>
          </div>
          {preview&&(
            <div className={`rounded-xl p-4 border text-sm ${preview.valid?'bg-zinc-800/60 border-zinc-700':'bg-red-900/30 border-red-700'}`}>
              {preview.valid?(
                <>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-emerald-400 font-semibold">✓ File valid</span>
                    <span className="text-zinc-400 text-xs">{fmt(preview.size)}</span>
                  </div>
                  {preview.meta.exportedAt&&<div className="text-zinc-400 text-xs mb-3">Dibuat: {new Date(preview.meta.exportedAt).toLocaleString('id-ID')}</div>}
                  <div className="grid sm:grid-cols-2 gap-3">
                    {preview.stats.db&&<div><p className="text-xs text-zinc-500 font-semibold uppercase mb-1">DB Tables</p>{Object.entries(preview.stats.db).map(([t,n])=><div key={t} className="flex justify-between text-xs"><span className="text-zinc-300">{t}</span><Badge>{n} rows</Badge></div>)}</div>}
                    {preview.stats.users&&<div><p className="text-xs text-zinc-500 font-semibold uppercase mb-1">User Tables</p>{Object.entries(preview.stats.users).map(([t,n])=><div key={t} className="flex justify-between text-xs"><span className="text-zinc-300">{t}</span><Badge>{n} rows</Badge></div>)}</div>}
                  </div>
                </>
              ):<div className="text-red-300">File tidak valid: {preview.error}</div>}
            </div>
          )}
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-zinc-400 mb-2 font-medium">Mode Import</label>
              <div className="flex gap-2">
                {[['replace','Replace'],['merge','Merge']].map(([v,l])=>(
                  <button key={v} onClick={()=>setMode(v)}
                    className={`flex-1 py-2 px-3 rounded-lg text-sm font-medium border transition ${importMode===v?'bg-blue-600 border-blue-500 text-white':'bg-zinc-800 border-zinc-700 text-zinc-400'}`}>{l}</button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-xs text-zinc-400 mb-2 font-medium">Scope</label>
              <select value={importScope} onChange={e=>setIScope(e.target.value)}
                className="w-full bg-zinc-800 border border-zinc-700 text-zinc-200 rounded-lg px-3 py-2 text-sm focus:outline-none">
                <option value="all">Semua (DB + Users)</option>
                <option value="db">DB saja</option>
                <option value="users">Users saja</option>
              </select>
            </div>
          </div>
          <div className="flex items-center gap-3 pt-1">
            <Btn variant="success" onClick={doImport} disabled={!importFile||!preview?.valid||importing}>
              {importing?<><Spinner/> Mengimport...</>:'Mulai Import'}
            </Btn>
            {importFile&&<button onClick={()=>{setFile(null);setPreview(null);if(fileRef.current)fileRef.current.value='';}} className="text-sm text-zinc-500 hover:text-zinc-300">Batal</button>}
          </div>
          {importMode==='replace'&&importFile&&preview?.valid&&(
            <div className="bg-amber-900/30 border border-amber-700/50 rounded-xl p-3 text-amber-300 text-xs flex items-start gap-2"><Icon d={ICONS.warn} size={13} className="flex-shrink-0 mt-0.5"/>Mode Replace: data yang ada akan DIHAPUS dan diganti dengan isi backup.</div>
          )}
        </div>
      </Card>

      <Card className="p-5">
        <h2 className="text-white font-bold mb-1">User Self-Service Backup API</h2>
        <p className="text-zinc-400 text-sm mb-4">User bisa backup & restore data sendiri via API.</p>
        <div className="space-y-2">
          {[['GET','/api/user/backup','Download backup data'],['GET','/api/user/backup?info=1','Info/stats backup'],['POST','/api/user/backup','Restore { data, mode }']].map(([m,p,d])=>(
            <div key={p} className="flex items-start gap-3 text-sm bg-zinc-800/50 rounded-lg px-3 py-2">
              <Badge color={m==='GET'?'blue':'amber'}>{m}</Badge>
              <code className="text-emerald-300 font-mono text-xs flex-1">{p}</code>
              <span className="text-zinc-400 text-xs hidden sm:block">{d}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

/* ─── File System ─────────────────────────────────────────────────────────── */

function FSTab({toast}) {
  const [root,setRoot]=useState('data');
  const [path,setPath]=useState('');
  const [entries,setEntries]=useState([]);
  const [loading,setL]=useState(true);
  const [fileContent,setFC]=useState(null);
  const [showNew,setNew]=useState(null);
  const [newName,setNewName]=useState('');
  const [newContent,setNewC]=useState('');
  const [confirm,setConf]=useState(null);

  const load=useCallback(async(r=root,p=path)=>{
    setL(true);
    const res=await api(`/api/admin/fs?root=${r}&path=${encodeURIComponent(p)}`);
    setL(false);
    if(res.success) setEntries(res.entries||[]); else toast(res.error||'Gagal load','error');
  },[root,path]);
  useEffect(()=>{load();},[]);

  function navigate(p){setPath(p);setFC(null);load(root,p);}
  function goUp(){const parts=path.split('/').filter(Boolean);parts.pop();navigate(parts.join('/'));}

  async function openFile(p) {
    const res=await api(`/api/admin/fs?root=${root}&path=${encodeURIComponent(p)}&action=read`);
    if(res.success) setFC({path:p,content:res.content,editing:false});
    else toast(res.error||'Gagal baca file','error');
  }
  async function saveFile() {
    const res=await api('/api/admin/fs',{method:'PUT',body:{root,path:fileContent.path,content:fileContent.content}});
    if(res.success){toast('File disimpan');setFC(fc=>({...fc,editing:false}));}
    else toast(res.error||'Gagal simpan','error');
  }
  async function createNew() {
    const fullPath=[path,newName].filter(Boolean).join('/');
    const res=await api('/api/admin/fs',{method:'POST',body:{root,path:fullPath,type:showNew,content:showNew==='file'?newContent:undefined}});
    if(res.success){toast(res.message);setNew(null);setNewName('');setNewC('');load();}
    else toast(res.error||'Gagal buat','error');
  }
  async function doDelete(p) {
    const res=await api(`/api/admin/fs?root=${root}&path=${encodeURIComponent(p)}`,{method:'DELETE'});
    setConf(null);
    if(res.success){toast(res.message);if(fileContent?.path===p)setFC(null);load();}
    else toast(res.error||'Gagal hapus','error');
  }

  const breadcrumbs=['root',...path.split('/').filter(Boolean)];

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3 flex-wrap">
        {['data','storage'].map(r=>(
          <button key={r} onClick={()=>{setRoot(r);setPath('');setFC(null);load(r,'');}}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium border transition flex items-center gap-1.5 ${root===r?'bg-blue-600 border-blue-600 text-white':'bg-zinc-800 border-zinc-700 text-zinc-300 hover:bg-zinc-700'}`}>
            <Icon d={ICONS.folder} size={13}/>{r}/
          </button>
        ))}
        <div className="flex-1"/>
        <Btn small onClick={()=>setNew('dir')}>+ Folder</Btn>
        <Btn small variant="primary" onClick={()=>setNew('file')}>+ File</Btn>
        <Btn small onClick={()=>load()}>Refresh</Btn>
      </div>
      <div className="flex items-center gap-1 text-sm flex-wrap">
        {breadcrumbs.map((p,i)=>(
          <span key={i} className="flex items-center gap-1">
            {i>0&&<span className="text-zinc-600">/</span>}
            <button className={`px-1 rounded hover:text-blue-400 transition ${i===breadcrumbs.length-1?'text-white font-semibold':'text-zinc-400'}`}
              onClick={()=>{const np=breadcrumbs.slice(1,i+1).join('/');navigate(i===0?'':np);}}>
              {p}
            </button>
          </span>
        ))}
      </div>
      <div className="grid md:grid-cols-2 gap-4">
        <Card className="overflow-hidden">
          {loading?<div className="flex justify-center py-16"><Spinner size="lg"/></div>:(
            <div>
              {path&&<button onClick={goUp} className="flex items-center gap-2 w-full px-4 py-2.5 text-sm text-zinc-400 hover:bg-zinc-800 border-b border-zinc-800">↑ .. (naik)</button>}
              {entries.length===0&&<p className="text-center text-zinc-500 py-8 text-sm">Folder kosong</p>}
              {entries.map(e=>(
                <div key={e.name} className="flex items-center gap-2 px-4 py-2.5 hover:bg-zinc-800/50 transition border-b border-zinc-800/30 group">
                  <span className={`flex-shrink-0 ${e.isDir?'text-amber-400':'text-zinc-500'}`}><Icon d={e.isDir?ICONS.folder:ICONS.fileDoc} size={14}/></span>
                  <button className="flex-1 text-left" onClick={()=>e.isDir?navigate(e.path):openFile(e.path)}>
                    <div className="text-sm text-white font-medium">{e.name}</div>
                    <div className="text-xs text-zinc-500">{e.isDir?'folder':e.formattedSize} · {ago(e.modifiedAt)}</div>
                  </button>
                  <button onClick={()=>setConf({path:e.path,isDir:e.isDir,name:e.name})}
                    className="opacity-0 group-hover:opacity-100 text-red-400 hover:text-red-300 text-xs px-1.5 py-0.5 rounded transition">Hapus</button>
                </div>
              ))}
            </div>
          )}
        </Card>
        <div>
          {fileContent?(
            <Card className="overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-800">
                <span className="text-sm font-mono text-zinc-300 truncate">{fileContent.path}</span>
                <div className="flex gap-2">
                  {fileContent.editing?(
                    <><Btn small onClick={()=>setFC(fc=>({...fc,editing:false}))}>Batal</Btn><Btn small variant="success" onClick={saveFile}>Simpan</Btn></>
                  ):(
                    <Btn small variant="amber" onClick={()=>setFC(fc=>({...fc,editing:true}))}>Edit</Btn>
                  )}
                </div>
              </div>
              <textarea value={fileContent.content} onChange={e=>setFC(fc=>({...fc,content:e.target.value}))}
                readOnly={!fileContent.editing} rows={22}
                className={`w-full bg-zinc-950 text-xs font-mono p-4 focus:outline-none resize-none transition ${fileContent.editing?'text-amber-300':'text-green-300'}`}/>
            </Card>
          ):(
            <Card className="p-8 text-center text-zinc-500">Klik file untuk membuka</Card>
          )}
        </div>
      </div>
      {showNew&&(
        <Modal title={showNew==='dir'?'Buat Folder Baru':'Buat File Baru'} onClose={()=>setNew(null)}>
          <div className="space-y-3">
            <Input label={showNew==='dir'?'Nama Folder':'Nama File'} value={newName} onChange={setNewName} placeholder={showNew==='dir'?'nama-folder':'file.json'}/>
            {showNew==='file'&&(
              <label className="block">
                <span className="block text-xs text-zinc-400 mb-1 font-medium">Konten (opsional)</span>
                <textarea value={newContent} onChange={e=>setNewC(e.target.value)} rows={8}
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-green-300 font-mono focus:outline-none resize-y"/>
              </label>
            )}
            <div className="flex gap-3 pt-1">
              <Btn onClick={()=>setNew(null)} className="flex-1 justify-center">Batal</Btn>
              <Btn variant="primary" onClick={createNew} className="flex-1 justify-center">Buat</Btn>
            </div>
          </div>
        </Modal>
      )}
      {confirm&&(
        <Confirm msg={`Hapus ${confirm.isDir?'folder':'file'} "${confirm.name}"?${confirm.isDir?' Semua isi akan ikut terhapus.':''}`}
          onConfirm={()=>doDelete(confirm.path)} onCancel={()=>setConf(null)}/>
      )}
    </div>
  );
}

/* ─── Server ──────────────────────────────────────────────────────────────── */

function ServerTab({toast}) {
  const [health,   setHealth]   = useState(null);
  const [loading,  setLoading]  = useState(true);
  const [actLoading, setActL]   = useState('');
  const [confirmAction, setCA]  = useState(null); // 'restart'|'flush'|'gc'|null
  const [logs,     setLogs]     = useState([]);

  function addLog(msg, type='info') {
    const ts = new Date().toLocaleTimeString('id-ID');
    setLogs(prev => [{ts, msg, type}, ...prev].slice(0, 100));
  }

  const load = useCallback(async() => {
    setLoading(true);
    const res = await api('/api/admin/server');
    setLoading(false);
    if (res.success) setHealth(res.health);
    else toast('Gagal load server health', 'error');
  }, []);

  useEffect(() => { load(); }, []);

  // Auto-refresh tiap 10 detik
  useEffect(() => {
    const t = setInterval(() => {
      api('/api/admin/server').then(res => {
        if (res.success) setHealth(res.health);
      });
    }, 10_000);
    return () => clearInterval(t);
  }, []);

  async function doAction(action) {
    setActL(action);
    addLog(`Menjalankan action: ${action}...`, 'info');
    try {
      const res = await api('/api/admin/server', { method: 'POST', body: { action } });
      if (res.success) {
        toast(res.message, 'success');
        addLog(res.message, 'success');
        if (action !== 'restart') {
          setTimeout(load, 800);
        } else {
          addLog('Server sedang restart. Halaman akan reload dalam 5 detik...', 'warn');
          setTimeout(() => window.location.reload(), 5000);
        }
      } else {
        toast(res.error, 'error');
        addLog(`Error: ${res.error}`, 'error');
      }
    } catch(e) {
      toast(e.message, 'error');
      addLog(`Error: ${e.message}`, 'error');
    } finally {
      setActL('');
      setCA(null);
    }
  }

  function fmtUptime(s) {
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sc = s % 60;
    return `${h}j ${m}m ${sc}s`;
  }

  function fmt(b) {
    if (!b) return '0 B';
    const k=1024, u=['B','KB','MB','GB'];
    const i=Math.floor(Math.log(Math.max(b,1))/Math.log(k));
    return `${(b/Math.pow(k,i)).toFixed(1)} ${u[i]}`;
  }

  if (loading && !health) return <div className="flex justify-center py-20"><Spinner size="lg"/></div>;

  const h = health;
  const memPct  = h?.memory.heapPercent  || 0;
  const osPct   = h?.os.memPercent       || 0;
  const memColor  = memPct  > 85 ? '#ef4444' : memPct  > 60 ? '#f59e0b' : '#22c55e';
  const osColor   = osPct   > 85 ? '#ef4444' : osPct   > 60 ? '#f59e0b' : '#22c55e';

  return (
    <div className="space-y-6">
      {/* Header metrics */}
      {h && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="p-5">
            <div className="w-9 h-9 rounded-lg border bg-blue-900/30 border-blue-800 text-blue-400 flex items-center justify-center mb-3">
              <Icon d={ICONS.refresh} size={16}/>
            </div>
            <div className="text-2xl font-bold text-blue-400 mb-0.5">{fmtUptime(h.uptime)}</div>
            <div className="text-xs text-zinc-500">Uptime</div>
          </Card>
          <Card className="p-5">
            <div className="w-9 h-9 rounded-lg border bg-emerald-900/30 border-emerald-800 text-emerald-400 flex items-center justify-center mb-3">
              <Icon d={ICONS.server} size={16}/>
            </div>
            <div className="text-2xl font-bold text-emerald-400 mb-0.5">{h.nodeVersion}</div>
            <div className="text-xs text-zinc-500">Node.js — PID {h.pid}</div>
          </Card>
          <Card className="p-5">
            <div className="w-9 h-9 rounded-lg border mb-3 flex items-center justify-center" style={{background:`${memColor}20`,borderColor:`${memColor}40`,color:memColor}}>
              <Icon d={ICONS.db} size={16}/>
            </div>
            <div className="text-2xl font-bold mb-0.5" style={{color:memColor}}>{memPct}%</div>
            <div className="text-xs text-zinc-500">Heap ({fmt(h.memory.heapUsed)} / {fmt(h.memory.heapTotal)})</div>
          </Card>
          <Card className="p-5">
            <div className="w-9 h-9 rounded-lg border mb-3 flex items-center justify-center" style={{background:`${osColor}20`,borderColor:`${osColor}40`,color:osColor}}>
              <Icon d={ICONS.fs} size={16}/>
            </div>
            <div className="text-2xl font-bold mb-0.5" style={{color:osColor}}>{osPct}%</div>
            <div className="text-xs text-zinc-500">RAM OS ({fmt(h.os.usedMem)} / {fmt(h.os.totalMem)})</div>
          </Card>
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-4">
        {/* Info server */}
        {h && (
          <Card className="p-5">
            <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
              <Icon d={ICONS.server} size={14} className="text-zinc-400"/>Info Server
            </h3>
            <div className="space-y-2.5">
              <Row label="Platform"     val={`${h.platform} / ${h.arch}`}/>
              <Row label="OS"           val={h.os.type}/>
              <Row label="Hostname"     val={h.os.hostname}/>
              <Row label="CPU"          val={`${h.os.cpuCount}x ${h.os.cpuModel.split(' ').slice(0,3).join(' ')}`}/>
              <Row label="Environment"  val={h.env}/>
              <Row label="Started At"   val={new Date(h.startedAt).toLocaleString('id-ID')}/>
              <Row label="Checked At"   val={new Date(h.checkedAt).toLocaleTimeString('id-ID')}/>
              <div className="pt-2 border-t border-zinc-800 space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="text-zinc-500">Load Avg (1m / 5m / 15m)</span>
                  <span className="text-zinc-300 font-mono">
                    {h.os.loadAvg1.toFixed(2)} / {h.os.loadAvg5.toFixed(2)} / {h.os.loadAvg15.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Memory detail */}
        {h && (
          <Card className="p-5">
            <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
              <Icon d={ICONS.db} size={14} className="text-zinc-400"/>Memory Detail
            </h3>
            <div className="space-y-3">
              {[
                { label:'Heap Used',   val: h.memory.heapUsed,  total: h.memory.heapTotal, color:'#3b82f6' },
                { label:'Heap Total',  val: h.memory.heapTotal, total: h.memory.heapTotal, color:'#6366f1' },
                { label:'RSS',         val: h.memory.rss,       total: h.os.totalMem,      color:'#8b5cf6' },
                { label:'External',    val: h.memory.external,  total: h.os.totalMem,      color:'#06b6d4' },
                { label:'OS Used',     val: h.os.usedMem,       total: h.os.totalMem,      color: osColor  },
              ].map(m => (
                <div key={m.label}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-zinc-400">{m.label}</span>
                    <span className="text-zinc-200 font-mono">{fmt(m.val)}</span>
                  </div>
                  <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all"
                      style={{width:`${Math.min((m.val/m.total)*100,100)}%`, background:m.color}}/>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}
      </div>

      {/* Server Actions */}
      <Card className="p-5">
        <h3 className="font-semibold text-white mb-1 flex items-center gap-2">
          <Icon d={ICONS.power} size={14} className="text-zinc-400"/>Server Control
        </h3>
        <p className="text-xs text-zinc-500 mb-4">Semua data akan di-flush ke disk sebelum operasi dijalankan.</p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-4 bg-zinc-800/60 rounded-xl border border-zinc-700">
            <div className="flex items-center gap-2 mb-2">
              <Icon d={ICONS.backup} size={14} className="text-blue-400"/>
              <span className="text-sm font-semibold text-white">Flush Database</span>
            </div>
            <p className="text-xs text-zinc-500 mb-3">Paksa simpan semua tabel ke disk sekarang tanpa restart.</p>
            <Btn variant="primary" small onClick={()=>setCA('flush')} disabled={actLoading==='flush'} className="w-full justify-center">
              {actLoading==='flush' ? <Spinner/> : <Icon d={ICONS.backup} size={12}/>}
              Flush Sekarang
            </Btn>
          </div>

          <div className="p-4 bg-zinc-800/60 rounded-xl border border-zinc-700">
            <div className="flex items-center gap-2 mb-2">
              <Icon d={ICONS.terminal} size={14} className="text-teal-400"/>
              <span className="text-sm font-semibold text-white">Garbage Collection</span>
            </div>
            <p className="text-xs text-zinc-500 mb-3">Paksa GC Node.js. Butuh flag --expose-gc saat menjalankan server.</p>
            <Btn variant="default" small onClick={()=>setCA('gc')} disabled={actLoading==='gc'} className="w-full justify-center">
              {actLoading==='gc' ? <Spinner/> : <Icon d={ICONS.terminal} size={12}/>}
              Run GC
            </Btn>
          </div>

          <div className="p-4 bg-red-900/20 rounded-xl border border-red-800/50">
            <div className="flex items-center gap-2 mb-2">
              <Icon d={ICONS.power} size={14} className="text-red-400"/>
              <span className="text-sm font-semibold text-white">Restart Server</span>
            </div>
            <p className="text-xs text-zinc-500 mb-3">Flush + exit proses. PM2/nodemon akan restart otomatis.</p>
            <Btn variant="danger" small onClick={()=>setCA('restart')} disabled={!!actLoading} className="w-full justify-center">
              {actLoading==='restart' ? <Spinner/> : <Icon d={ICONS.power} size={12}/>}
              Restart
            </Btn>
          </div>
        </div>
      </Card>

      {/* Activity Log */}
      <Card className="p-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold text-white flex items-center gap-2">
            <Icon d={ICONS.terminal} size={14} className="text-zinc-400"/>Activity Log
          </h3>
          <div className="flex gap-2">
            <Btn small onClick={load}><Icon d={ICONS.refresh} size={12}/>Refresh</Btn>
            <Btn small onClick={()=>setLogs([])}>Hapus Log</Btn>
          </div>
        </div>
        {logs.length === 0 ? (
          <p className="text-zinc-500 text-sm">Belum ada aktivitas dalam sesi ini.</p>
        ) : (
          <div className="space-y-1 max-h-64 overflow-y-auto font-mono text-xs">
            {logs.map((l,i) => (
              <div key={i} className={`flex gap-2 ${l.type==='error'?'text-red-400':l.type==='warn'?'text-amber-400':l.type==='success'?'text-emerald-400':'text-zinc-400'}`}>
                <span className="text-zinc-600 shrink-0">{l.ts}</span>
                <span>{l.msg}</span>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Confirm modals */}
      {confirmAction === 'flush' && (
        <Confirm
          msg="Paksa simpan semua tabel ke disk sekarang?"
          danger={false}
          onConfirm={() => doAction('flush')}
          onCancel={() => setCA(null)}
        />
      )}
      {confirmAction === 'gc' && (
        <Confirm
          msg="Jalankan garbage collection Node.js sekarang?"
          danger={false}
          onConfirm={() => doAction('gc')}
          onCancel={() => setCA(null)}
        />
      )}
      {confirmAction === 'restart' && (
        <Confirm
          msg="Restart server sekarang? Semua data akan di-flush terlebih dahulu. Server akan offline beberapa saat sampai PM2/nodemon me-restart proses."
          danger={true}
          onConfirm={() => doAction('restart')}
          onCancel={() => setCA(null)}
        />
      )}
    </div>
  );
}

/* ─── Subscriptions ───────────────────────────────────────────────────────── */

// BUG FIX: Sebelumnya pakai window.confirm() (blokir UI + tidak konsisten)
// Sekarang: gunakan state-based <Confirm> modal yang proper
function SubscriptionsTab({toast}) {
  const [rows,setRows]=useState([]);
  const [filter,setFilter]=useState('all');
  const [loading,setLoading]=useState(true);
  const [confirmModal,setConfirmModal]=useState(null);

  const load=useCallback(async(f=filter)=>{
    setLoading(true);
    const res=await api(`/api/admin/subscriptions?status=${f}`);
    setLoading(false);
    if(res.success) setRows(res.subscriptions||[]); else toast('Gagal load subscriptions','error');
  },[filter]);
  useEffect(()=>{load();},[]);

  async function doConfirm(orderId) {
    setConfirmModal(null);
    const res=await api(`/api/admin/subscriptions/${orderId}`,{method:'POST'});
    if(res.success){toast(`Order ${orderId} dikonfirmasi!`);load(filter);}
    else toast(res.error||'Gagal konfirmasi','error');
  }

  const STATUS_COLOR={
    paid:'bg-emerald-900/60 text-emerald-300 border-emerald-700',
    pending:'bg-amber-900/60 text-amber-300 border-amber-700',
    expired:'bg-zinc-800 text-zinc-400 border-zinc-700',
    failed:'bg-red-900/60 text-red-300 border-red-700',
  };
  const fmtDt=iso=>iso?new Date(iso).toLocaleString('id-ID',{day:'2-digit',month:'short',year:'2-digit',hour:'2-digit',minute:'2-digit'}):'—';

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h2 className="text-white font-semibold text-lg">Subscriptions</h2>
        <div className="flex items-center gap-2">
          <div className="flex gap-1 p-1 bg-zinc-800 rounded-lg">
            {['all','pending','paid','expired'].map(f=>(
              <button key={f} onClick={()=>{setFilter(f);load(f);}}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold capitalize transition ${filter===f?'bg-zinc-600 text-white':'text-zinc-400 hover:text-zinc-200'}`}>{f}</button>
            ))}
          </div>
          <Btn onClick={()=>load(filter)}>Refresh</Btn>
        </div>
      </div>
      <div className="grid grid-cols-4 gap-3">
        {[
          {label:'Total',val:rows.length,c:'text-white'},
          {label:'Pending',val:rows.filter(r=>r.status==='pending').length,c:'text-amber-400'},
          {label:'Paid',val:rows.filter(r=>r.status==='paid').length,c:'text-emerald-400'},
          {label:'Expired',val:rows.filter(r=>r.status==='expired').length,c:'text-zinc-400'},
        ].map(s=>(
          <Card key={s.label} className="p-4 text-center">
            <div className={`text-2xl font-bold ${s.c}`}>{s.val}</div>
            <div className="text-xs text-zinc-500 mt-0.5">{s.label}</div>
          </Card>
        ))}
      </div>
      <Card className="overflow-hidden">
        {loading?<div className="flex justify-center py-12"><Spinner size="lg"/></div>
          :rows.length===0?<p className="text-zinc-500 text-sm text-center py-12">Tidak ada data.</p>:(
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-zinc-800">
                    {['Order ID','User','Plan','Nominal','Status','Dibuat','Aksi'].map(h=>(
                      <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-zinc-500 uppercase whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {rows.map(r=>(
                    <tr key={r.orderId} className="border-b border-zinc-800/60 hover:bg-zinc-800/40 transition-colors">
                      <td className="px-4 py-3 font-mono text-xs text-zinc-400 max-w-[140px] truncate">{r.orderId}</td>
                      <td className="px-4 py-3">
                        <div className="text-xs font-medium text-zinc-300">{r.userName||'—'}</div>
                        <div className="text-[11px] text-zinc-500 truncate max-w-[140px]">{r.userEmail}</div>
                      </td>
                      <td className="px-4 py-3 text-xs font-bold text-zinc-200 uppercase">{r.plan}</td>
                      <td className="px-4 py-3 text-xs text-zinc-300 font-mono whitespace-nowrap">{fmtRp(r.amount)}</td>
                      <td className="px-4 py-3"><span className={`inline-flex px-2 py-0.5 rounded-md text-[11px] font-bold border capitalize ${STATUS_COLOR[r.status]||STATUS_COLOR.expired}`}>{r.status}</span></td>
                      <td className="px-4 py-3 text-[11px] text-zinc-500 whitespace-nowrap">{fmtDt(r.createdAt)}</td>
                      <td className="px-4 py-3">
                        {r.status==='pending'&&(
                          <Btn variant="success" small onClick={()=>setConfirmModal(r.orderId)}>✓ Konfirmasi</Btn>
                        )}
                        {r.status==='paid'&&<span className="text-[11px] text-zinc-600">{r.paidAt?fmtDt(r.paidAt):'sudah lunas'}</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
      </Card>
      {confirmModal&&(
        <Confirm danger={false}
          msg={`Konfirmasi manual pembayaran untuk order ${confirmModal}? Plan user akan langsung diaktifkan.`}
          onConfirm={()=>doConfirm(confirmModal)} onCancel={()=>setConfirmModal(null)}/>
      )}
      <p className="text-xs text-zinc-600">Tombol <strong className="text-zinc-400">✓ Konfirmasi</strong> mengaktifkan plan manual — gunakan jika user sudah bayar tapi status masih pending.</p>
    </div>
  );
}

/* ─── API Docs ────────────────────────────────────────────────────────────── */

const API_DOCS=[
  {category:'Auth',eps:[
    {m:'GET',p:'/api/auth/google',d:'Redirect ke Google OAuth',
     res:null,note:'Redirect ke Google consent screen'},
    {m:'GET',p:'/api/auth/callback',d:'Callback OAuth, set session cookie',
     res:{success:true,user:{id:'u_abc123',email:'user@gmail.com',name:'User Name',plan:'free'}}},
    {m:'GET',p:'/api/auth/me',d:'Cek session user yang sedang login',
     res:{success:true,user:{id:'u_abc123',email:'user@gmail.com',name:'User Name',plan:'premium',keyId:'key_xyz789'}}},
    {m:'POST',p:'/api/auth/logout',d:'Hapus session dan logout',
     res:{success:true}},
  ]},
  {category:'Upload & Files',eps:[
    {m:'POST',p:'/api/upload',d:'Upload file. Header: X-API-Key. Body: multipart/form-data field "file".',
     req:'Header: X-API-Key: dtdb_xxx\nContent-Type: multipart/form-data\nBody: { file: <binary> }',
     res:{success:true,file:{id:'f_abc123xyz',originalName:'video.mp4',mimeType:'video/mp4',size:10485760,category:'video',public:true,downloads:0,url:'https://dongtube.my.id/api/file/f_abc123xyz',uploadedAt:'2025-01-15T10:30:00.000Z'}}},
    {m:'GET',p:'/api/file/:id',d:'Stream file. File publik tidak perlu auth.',
     res:'<binary file content>',note:'Support Range header untuk streaming video'},
    {m:'GET',p:'/api/files',d:'List semua file milik API key.',
     req:'GET /api/files?page=1&limit=20&category=video&search=nama',
     res:{success:true,data:{items:[{id:'f_abc123',originalName:'video.mp4',size:10485760,category:'video',public:true,downloads:5,uploadedAt:'2025-01-15T10:30:00Z'}],total:1,page:1,pages:1}}},
    {m:'PUT',p:'/api/file/:id',d:'Update metadata file.',
     req:{public:false,originalName:'nama-baru.mp4'},
     res:{success:true,file:{id:'f_abc123',public:false,originalName:'nama-baru.mp4'}}},
    {m:'DELETE',p:'/api/file/:id',d:'Hapus file. Hanya pemilik bisa menghapus.',
     res:{success:true,message:'File f_abc123 berhasil dihapus'}},
  ]},
  {category:'KV Store',eps:[
    {m:'GET',p:'/api/kv',d:'Baca nilai dari KV store.',
     req:'GET /api/kv?key=my-config',
     res:{success:true,key:'my-config',value:{setting:'value',updated:'2025-01-15'},sha:'abc123def456'}},
    {m:'PUT',p:'/api/kv',d:'Tulis nilai ke KV store.',
     req:{key:'my-config',value:{setting:'new-value',count:42}},
     res:{success:true,key:'my-config',sha:'def456ghi789'}},
    {m:'DELETE',p:'/api/kv',d:'Hapus entry KV.',
     req:'DELETE /api/kv?key=my-config',
     res:{success:true,message:'Key my-config dihapus'}},
    {m:'GET',p:'/api/kv/list',d:'List semua keys milik API key.',
     req:'GET /api/kv/list?prefix=settings/',
     res:{success:true,keys:[{key:'settings/theme',sha:'abc123',updatedAt:'2025-01-15T10:00:00Z'}],total:1}},
  ]},
  {category:'Subscription',eps:[
    {m:'GET',p:'/api/plans',d:'Daftar plan yang tersedia (publik).',
     res:{success:true,plans:[{id:'free',name:'Free',price:0,storageBytes:10485760,rateLimit:10000,features:['10 MB Storage']},{id:'premium',name:'Premium',price:10000,storageBytes:524288000,rateLimit:50000,features:['500 MB Storage']}]}},
    {m:'POST',p:'/api/subscribe',d:'Buat order subscription baru via Pakasir QRIS.',
     req:{plan:'premium'},
     res:{success:true,order:{orderId:'INV-20250115-ABC123',plan:'premium',amount:10000,status:'pending',qrisUrl:'https://pakasir.id/qris/INV-20250115-ABC123',expiresAt:'2025-01-15T10:45:00.000Z'}}},
    {m:'GET',p:'/api/subscribe/status/:orderId',d:'Cek status pembayaran.',
     res:{success:true,order:{orderId:'INV-20250115-ABC123',status:'paid',plan:'premium',paidAt:'2025-01-15T10:35:00.000Z'}}},
  ]},
  {category:'User Info',eps:[
    {m:'GET',p:'/api/user/me',d:'Info user & plan aktif. Header: X-API-Key.',
     res:{success:true,user:{id:'u_abc123',email:'user@gmail.com',name:'User Name',plan:'premium',planExpiresAt:'2025-02-15T00:00:00.000Z',planDaysLeft:30},usage:{storageUsed:52428800,storageLimit:524288000,storagePercent:10,fileCount:5}}},
    {m:'GET',p:'/api/user/stats',d:'Statistik penggunaan storage dan file.',
     res:{success:true,stats:{totalFiles:5,totalSize:52428800,totalSizeHuman:'50 MB',byCategory:{video:3,image:2}}}},
    {m:'GET',p:'/api/user/backup',d:'Download backup semua data user.',
     res:{meta:{exportedAt:'2025-01-15T10:00:00.000Z',keyId:'key_xyz789'},files:[{id:'f_abc123',originalName:'video.mp4',size:10485760}],kv:[{key:'my-config',value:{setting:'value'}}]}},
    {m:'POST',p:'/api/user/backup',d:'Restore backup data user.',
     req:{data:{files:[],kv:[]},mode:'merge'},
     res:{success:true,summary:{filesImported:2,kvImported:1}}},
  ]},
];

const M_COLOR={
  GET:'bg-blue-900/60 text-blue-300 border-blue-700',
  POST:'bg-emerald-900/60 text-emerald-300 border-emerald-700',
  PUT:'bg-amber-900/60 text-amber-300 border-amber-700',
  DELETE:'bg-red-900/60 text-red-300 border-red-700',
};

function APIDocsTab() {
  const [activeCat,setActiveCat]=useState(null);
  const [expanded,setExpanded]=useState(null);
  const cats=API_DOCS.map(c=>c.category);
  const displayed=activeCat?API_DOCS.filter(c=>c.category===activeCat):API_DOCS;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-white font-bold text-xl">API Reference</h2>
          <p className="text-zinc-500 text-sm mt-0.5">Semua endpoint dengan contoh request & response JSON lengkap</p>
        </div>
        <div className="bg-zinc-800/50 border border-zinc-700 rounded-xl px-4 py-2 text-xs font-mono text-zinc-400">
          Base URL: <span className="text-blue-400">/api</span> · Auth: <span className="text-amber-400">X-API-Key: dtdb_xxx</span>
        </div>
      </div>

      <div className="flex gap-2 flex-wrap">
        <button onClick={()=>setActiveCat(null)}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition ${!activeCat?'bg-blue-600 border-blue-600 text-white':'bg-zinc-800 border-zinc-700 text-zinc-400 hover:text-zinc-200'}`}>
          Semua
        </button>
        {cats.map(c=>(
          <button key={c} onClick={()=>setActiveCat(c===activeCat?null:c)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition ${activeCat===c?'bg-blue-600 border-blue-600 text-white':'bg-zinc-800 border-zinc-700 text-zinc-400 hover:text-zinc-200'}`}>
            {c}
          </button>
        ))}
      </div>

      {displayed.map(cat=>(
        <div key={cat.category}>
          <h3 className="text-white font-bold text-base mb-3">{cat.category}</h3>
          <div className="space-y-2">
            {cat.eps.map((ep,idx)=>{
              const key=`${cat.category}-${idx}`;
              const isOpen=expanded===key;
              return (
                <Card key={key} className="overflow-hidden">
                  <button onClick={()=>setExpanded(isOpen?null:key)}
                    className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-zinc-800/40 transition">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-bold border min-w-[56px] justify-center ${M_COLOR[ep.m]||M_COLOR.GET}`}>{ep.m}</span>
                    <code className="text-emerald-300 font-mono text-sm flex-1">{ep.p}</code>
                    <span className="text-zinc-500 text-xs hidden sm:block max-w-xs truncate">{ep.d}</span>
                    <span className="text-zinc-600 text-xs">{isOpen?'▲':'▼'}</span>
                  </button>
                  {isOpen&&(
                    <div className="border-t border-zinc-800 px-4 pb-4 pt-3 space-y-3">
                      <p className="text-zinc-400 text-sm">{ep.d}</p>
                      {ep.note&&<div className="bg-blue-900/20 border border-blue-700/40 rounded-lg px-3 py-2 text-blue-300 text-xs flex items-center gap-2"><Icon d={ICONS.note} size={12} className="flex-shrink-0"/>{ep.note}</div>}
                      {ep.req&&(
                        <div>
                          <p className="text-xs text-zinc-500 font-semibold uppercase mb-1.5">Request</p>
                          <pre className="bg-zinc-950 text-blue-300 text-xs p-3 rounded-xl font-mono overflow-x-auto whitespace-pre-wrap">
                            {typeof ep.req==='string'?ep.req:JSON.stringify(ep.req,null,2)}
                          </pre>
                        </div>
                      )}
                      {ep.res&&(
                        <div>
                          <p className="text-xs text-zinc-500 font-semibold uppercase mb-1.5">Response JSON (200 OK)</p>
                          <pre className="bg-zinc-950 text-green-300 text-xs p-3 rounded-xl font-mono overflow-x-auto whitespace-pre-wrap">
                            {typeof ep.res==='string'?ep.res:JSON.stringify(ep.res,null,2)}
                          </pre>
                        </div>
                      )}
                      <div>
                        <p className="text-xs text-zinc-500 font-semibold uppercase mb-1.5">Error Response (4xx / 5xx)</p>
                        <pre className="bg-zinc-950 text-red-300 text-xs p-3 rounded-xl font-mono overflow-x-auto">
                          {JSON.stringify({success:false,error:'Pesan error spesifik'},null,2)}
                        </pre>
                      </div>
                    </div>
                  )}
                </Card>
              );
            })}
          </div>
        </div>
      ))}

      <Card className="p-5">
        <h3 className="text-white font-bold mb-3 flex items-center gap-2"><Icon d={ICONS.lock} size={14} className="text-zinc-400"/>Autentikasi &amp; Rate Limit</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <p className="text-xs text-zinc-500 font-semibold uppercase mb-2">HTTP Header Auth</p>
            <pre className="bg-zinc-950 text-green-300 text-xs font-mono p-3 rounded-xl">{`GET /api/files HTTP/1.1
Host: dongtube.my.id
X-API-Key: dtdb_abc123xyz...`}</pre>
          </div>
          <div>
            <p className="text-xs text-zinc-500 font-semibold uppercase mb-2">Rate Limit Exceeded (429)</p>
            <pre className="bg-zinc-950 text-red-300 text-xs font-mono p-3 rounded-xl">{JSON.stringify({success:false,error:'Rate limit exceeded',retryAfter:60,limit:10000,remaining:0},null,2)}</pre>
          </div>
        </div>
      </Card>
    </div>
  );
}

/* ─── Main Shell ──────────────────────────────────────────────────────────── */

const TABS=[
  {id:'overview',   label:'Overview',     icon:ICONS.overview},
  {id:'users',      label:'Users',        icon:ICONS.users},
  {id:'keys',       label:'API Keys',     icon:ICONS.key},
  {id:'subscriptions',label:'Subscriptions',icon:ICONS.credit},
  {id:'plans',      label:'Plans',        icon:ICONS.package},
  {id:'server',     label:'Server',       icon:ICONS.server},
  {id:'settings',   label:'Settings',     icon:ICONS.settings},
  {id:'files',      label:'Files',        icon:ICONS.files},
  {id:'kv',         label:'KV Store',     icon:ICONS.kv},
  {id:'db',         label:'DB Editor',    icon:ICONS.db},
  {id:'fs',         label:'File System',  icon:ICONS.fs},
  {id:'backup',     label:'Backup',       icon:ICONS.backup},
  {id:'apidocs',    label:'API Docs',     icon:ICONS.apidocs},
];

export default function AdminPage() {
  const [authed,setAuthed]=useState(false);
  const [tab,setTab]=useState('overview');
  const [toast,setToast]=useState(null);
  const [checking,setChk]=useState(true);

  useEffect(()=>{
    api('/api/admin/overview').then(res=>{
      if(res.success) setAuthed(true);
      setChk(false);
    });
  },[]);

  function showToast(msg,type='success'){setToast({msg,type});}

  async function logout() {
    await api('/api/admin/login',{method:'DELETE'});
    setAuthed(false);
  }

  if(checking) return <div className="min-h-screen bg-zinc-950 flex items-center justify-center"><Spinner size="lg"/></div>;
  if(!authed) return <LoginScreen onLogin={()=>setAuthed(true)}/>;

  return (
    <div className="min-h-screen bg-zinc-950 text-white">
      <div className="border-b border-zinc-800 bg-zinc-900/95 backdrop-blur sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between h-14">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center text-xs font-bold tracking-tight">D</div>
            <span className="font-semibold text-white text-sm">DongtubeDB</span>
            <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-red-900/60 text-red-300 border border-red-800 uppercase tracking-wide">Admin</span>
          </div>
          <button onClick={logout} className="text-xs text-zinc-500 hover:text-red-400 transition flex items-center gap-1.5 px-2 py-1 rounded-md hover:bg-red-900/20">
            Logout
          </button>
        </div>
        <div className="max-w-7xl mx-auto px-2 flex gap-0 overflow-x-auto scrollbar-none">
          {TABS.map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)}
              className={`px-3 py-2.5 text-xs font-medium whitespace-nowrap border-b-2 transition flex items-center gap-1.5 ${tab===t.id?'border-blue-500 text-blue-400':'border-transparent text-zinc-500 hover:text-zinc-200'}`}>
              <Icon d={t.icon} size={12}/>{t.label}
            </button>
          ))}
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 py-6">
        {tab==='overview'      &&<OverviewTab      toast={showToast}/>}
        {tab==='users'         &&<UsersTab         toast={showToast}/>}
        {tab==='keys'          &&<KeysTab          toast={showToast}/>}
        {tab==='subscriptions' &&<SubscriptionsTab toast={showToast}/>}
        {tab==='plans'         &&<PlansTab         toast={showToast}/>}
        {tab==='server'        &&<ServerTab        toast={showToast}/>}
        {tab==='settings'      &&<SettingsTab      toast={showToast}/>}
        {tab==='files'         &&<FilesTab         toast={showToast}/>}
        {tab==='kv'            &&<KVTab            toast={showToast}/>}
        {tab==='db'            &&<DBTab            toast={showToast}/>}
        {tab==='fs'            &&<FSTab            toast={showToast}/>}
        {tab==='backup'        &&<BackupTab        toast={showToast}/>}
        {tab==='apidocs'       &&<APIDocsTab/>}
      </div>
      {toast&&<Toast msg={toast.msg} type={toast.type} onDone={()=>setToast(null)}/>}
    </div>
  );
}
