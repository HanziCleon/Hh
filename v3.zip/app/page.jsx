'use client';

import { useState, useEffect, useRef } from 'react';
import Script from 'next/script';

// ─── Helpers ─────────────────────────────────────────────────────────────────

function fmt(bytes) {
  if (!bytes) return '0 B';
  const k = 1024, sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${(bytes / Math.pow(k, i)).toFixed(1)} ${sizes[i]}`;
}

function fmtRp(n) {
  return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(n);
}

function fmtDate(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
}

function copy(text, toast) {
  navigator.clipboard.writeText(text)
    .then(() => toast('Tersalin!', 'success'))
    .catch(() => toast('Gagal copy', 'error'));
}

function kvExample(tab, apiKey) {
  const key    = apiKey || 'YOUR_API_KEY';
  const domain = typeof window !== 'undefined' ? window.location.origin : 'https://dongtube.my.id';
  const ex = {
    write:  `fetch('${domain}/api/kv/my-config', {\n  method: 'PUT',\n  headers: {\n    'Content-Type': 'application/json',\n    'X-API-Key': '${key}'\n  },\n  body: JSON.stringify({ theme: 'dark', version: 2 })\n});`,
    read:   `fetch('${domain}/api/kv/my-config', {\n  headers: { 'X-API-Key': '${key}' }\n}).then(r => r.json()).then(console.log);`,
    list:   `fetch('${domain}/api/kv?mode=all', {\n  headers: { 'X-API-Key': '${key}' }\n}).then(r => r.json()).then(console.log);`,
    del:    `fetch('${domain}/api/kv/my-config', {\n  method: 'DELETE',\n  headers: { 'X-API-Key': '${key}' }\n});`,
  };
  return ex[tab] || '';
}

function fileExample(tab, apiKey) {
  const key    = apiKey || 'YOUR_API_KEY';
  const domain = typeof window !== 'undefined' ? window.location.origin : 'https://dongtube.my.id';
  const ex = {
    upload:   `const form = new FormData();\nform.append('file', fileInput.files[0]);\nform.append('public', 'true');\n\nfetch('${domain}/api/upload', {\n  method: 'POST',\n  headers: { 'X-API-Key': '${key}' },\n  body: form\n}).then(r => r.json()).then(console.log);`,
    list:     `fetch('${domain}/api/files', {\n  headers: { 'X-API-Key': '${key}' }\n}).then(r => r.json()).then(console.log);`,
    download: `// File public — tidak perlu key\nfetch('${domain}/api/files/FILE_ID');\n\n// File private — key diperlukan\nfetch('${domain}/api/files/FILE_ID', {\n  headers: { 'X-API-Key': '${key}' }\n});`,
    del:      `fetch('${domain}/api/files/FILE_ID', {\n  method: 'DELETE',\n  headers: { 'X-API-Key': '${key}' }\n});`,
  };
  return ex[tab] || '';
}

function tiktokExample(tab, apiKey) {
  const key    = apiKey || 'YOUR_API_KEY';
  const domain = typeof window !== 'undefined' ? window.location.origin : 'https://dongtube.my.id';
  const ex = {
    info:  `// Ambil info video (thumbnail otomatis di-upload ke DongtubeDB)\nfetch('${domain}/api/tiktok?url=https://vm.tiktok.com/xxx')\n  .then(r => r.json()).then(console.log);`,
    video: `// Download video — hasilnya URL DongtubeDB\nfetch('${domain}/api/tiktok/video?url=https://vm.tiktok.com/xxx', {\n  headers: { 'X-API-Key': '${key}' }\n}).then(r => r.json()).then(console.log);`,
    audio: `// Ekstrak audio MP3 192k — hasilnya URL DongtubeDB\nfetch('${domain}/api/tiktok/audio?url=https://vm.tiktok.com/xxx', {\n  headers: { 'X-API-Key': '${key}' }\n}).then(r => r.json()).then(console.log);`,
    slide: `// Ambil semua gambar slide — hasilnya array URL DongtubeDB\nfetch('${domain}/api/tiktok/slide?url=https://vm.tiktok.com/xxx', {\n  headers: { 'X-API-Key': '${key}' }\n}).then(r => r.json()).then(console.log);`,
  };
  return ex[tab] || '';
}

// ─── Components ───────────────────────────────────────────────────────────────

function Toast({ toast }) {
  if (!toast) return null;
  const cls = toast.type === 'error'
    ? 'bg-red-50 border-red-200 text-red-700'
    : toast.type === 'warn'
    ? 'bg-amber-50 border-amber-200 text-amber-700'
    : 'bg-emerald-50 border-emerald-200 text-emerald-700';
  return (
    <div className={`fixed bottom-6 left-1/2 -translate-x-1/2 z-[100] px-5 py-3 rounded-xl border text-sm font-medium shadow-xl ${cls} transition-all max-w-[90vw] text-center`}>
      {toast.msg}
    </div>
  );
}

function Modal({ title, children, onClose, maxW = 'max-w-md' }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
      onClick={e => e.target === e.currentTarget && onClose()}>
      <div className={`bg-white rounded-2xl shadow-2xl w-full ${maxW} p-6 max-h-[90vh] overflow-y-auto`}>
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-bold text-zinc-900 text-lg">{title}</h3>
          <button onClick={onClose} className="text-zinc-400 hover:text-zinc-600 text-2xl leading-none w-8 h-8 flex items-center justify-center rounded-lg hover:bg-zinc-100">&times;</button>
        </div>
        {children}
      </div>
    </div>
  );
}

function ModalQRIS({ title, children, maxW = 'max-w-sm' }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className={`bg-white rounded-3xl shadow-2xl w-full ${maxW} overflow-hidden max-h-[95vh] overflow-y-auto`}>
        <div className="px-6 pt-6 pb-2 border-b border-zinc-100">
          <h3 className="font-bold text-zinc-900 text-base text-center">{title}</h3>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}

function CodeBlock({ code }) {
  return (
    <pre className="bg-zinc-950 text-emerald-300 rounded-xl p-4 text-xs font-mono overflow-x-auto leading-relaxed whitespace-pre">
      {code}
    </pre>
  );
}

function Tabs({ tabs, active, onChange }) {
  return (
    <div className="overflow-x-auto mb-3 -mx-1 px-1">
      <div className="flex gap-1 p-1 bg-zinc-100 rounded-lg w-max">
        {tabs.map(t => (
          <button key={t.value} onClick={() => onChange(t.value)}
            className={`flex-shrink-0 px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${active === t.value ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'}`}>
            {t.label}
          </button>
        ))}
      </div>
    </div>
  );
}

// ─── Storage Progress Bar ─────────────────────────────────────────────────────

function StorageBar({ used, limit, percent, plan }) {
  const color =
    percent >= 90 ? '#ef4444' :
    percent >= 70 ? '#f59e0b' :
    plan?.id === 'max'     ? '#f59e0b' :
    plan?.id === 'premium' ? '#a855f7' : '#6b7280';

  return (
    <div>
      <div className="flex justify-between text-xs text-zinc-500 mb-1.5">
        <span>{fmt(used)} terpakai</span>
        <span>{fmt(limit)} total</span>
      </div>
      <div className="h-2.5 bg-zinc-100 rounded-full overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${Math.min(100, percent)}%`, background: color }}
        />
      </div>
      <div className="flex justify-between text-xs mt-1.5">
        <span className="font-semibold" style={{ color }}>{percent}% terpakai</span>
        <span className="text-zinc-400">{fmt(Math.max(0, limit - used))} tersisa</span>
      </div>
    </div>
  );
}

// ─── Plan Badge ───────────────────────────────────────────────────────────────

function PlanBadge({ plan, size = 'sm' }) {
  const color = plan?.color || '#6b7280';
  const sz = size === 'lg' ? 'px-4 py-1.5 text-sm font-bold' : 'px-2.5 py-0.5 text-xs font-semibold';
  return (
    <span className={`inline-flex items-center rounded-full border ${sz}`}
      style={{ color, borderColor: color, background: color + '18' }}>
      {plan?.name || 'FREE'}
    </span>
  );
}

// ─── QRIS Display ─────────────────────────────────────────────────────────────

function QrisDisplay({ qrisString, amount, orderId, plan, expiresAt, onPaid, onCancel }) {
  const [countdown, setCountdown] = useState(() => {
    if (!expiresAt) return 15 * 60;
    const sisa = Math.max(0, Math.floor((new Date(expiresAt) - Date.now()) / 1000));
    return sisa;
  });
  const [status,   setStatus]   = useState('pending');
  const [checking, setChecking] = useState(false);
  const intervalRef = useRef(null);
  const pollRef     = useRef(null);

  useEffect(() => {
    intervalRef.current = setInterval(() => {
      setCountdown(c => {
        if (c <= 1) { clearInterval(intervalRef.current); return 0; }
        return c - 1;
      });
    }, 1000);
    return () => clearInterval(intervalRef.current);
  }, []);

  async function checkNow() {
    if (checking || status !== 'pending') return;
    setChecking(true);
    try {
      const r = await fetch(`/api/subscribe/${orderId}`, {
        headers: { 'X-API-Key': window.__dtdb_apikey || '', 'Cache-Control': 'no-store' },
      });
      const d = await r.json();
      if (d.status === 'paid') {
        setStatus('paid');
        clearInterval(pollRef.current);
        setTimeout(() => onPaid(d.planResult), 800);
      } else if (d.status === 'expired') {
        setStatus('expired');
        clearInterval(pollRef.current);
      }
    } catch (_) {}
    setChecking(false);
  }

  useEffect(() => {
    if (status !== 'pending') return;
    pollRef.current = setInterval(async () => {
      try {
        const r = await fetch(`/api/subscribe/${orderId}`, {
          headers: { 'X-API-Key': window.__dtdb_apikey || '', 'Cache-Control': 'no-store' },
        });
        const d = await r.json();
        if (d.status === 'paid') {
          setStatus('paid');
          clearInterval(pollRef.current);
          setTimeout(() => onPaid(d.planResult), 800);
        } else if (d.status === 'expired') {
          setStatus('expired');
          clearInterval(pollRef.current);
        }
      } catch (_) {}
    }, 4000);
    return () => clearInterval(pollRef.current);
  }, [orderId, status]);

  const mm = String(Math.floor(countdown / 60)).padStart(2, '0');
  const ss = String(countdown % 60).padStart(2, '0');
  const isUrgent = countdown > 0 && countdown < 120;

  const qrSize = 220;
  const qrUrl  = qrisString
    ? `https://api.qrserver.com/v1/create-qr-code/?size=${qrSize * 2}x${qrSize * 2}&ecc=M&data=${encodeURIComponent(qrisString)}`
    : null;

  function downloadQR() {
    if (!qrUrl) return;
    const a = document.createElement('a');
    a.href = qrUrl;
    a.download = `QRIS-${orderId}.png`;
    a.target = '_blank';
    a.click();
  }

  if (status === 'paid') {
    return (
      <div className="flex flex-col items-center py-6 gap-4">
        <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center">
          <svg className="w-10 h-10 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <div className="text-center">
          <h4 className="text-xl font-bold text-zinc-900 mb-1">Pembayaran Berhasil!</h4>
          <p className="text-sm text-zinc-500">Plan <span className="font-semibold" style={{ color: plan?.color }}>{plan?.name}</span> aktif 30 hari.</p>
          <p className="text-xs text-zinc-400 mt-1">Halaman akan refresh otomatis...</p>
        </div>
        <button onClick={onCancel}
          className="px-6 py-2.5 bg-emerald-600 text-white rounded-xl text-sm font-semibold hover:bg-emerald-700 transition-colors">
          Tutup
        </button>
      </div>
    );
  }

  if (status === 'expired') {
    return (
      <div className="flex flex-col items-center py-6 gap-4">
        <div className="w-16 h-16 rounded-full bg-zinc-100 flex items-center justify-center">
          <svg className="w-8 h-8 text-zinc-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </div>
        <div className="text-center">
          <h4 className="text-base font-bold text-zinc-700 mb-1">Order Kedaluwarsa</h4>
          <p className="text-sm text-zinc-400">Silakan buat order baru untuk melanjutkan pembayaran.</p>
        </div>
        <button onClick={onCancel}
          className="px-6 py-2.5 bg-zinc-200 text-zinc-700 rounded-xl text-sm font-semibold hover:bg-zinc-300 transition-colors">
          Tutup
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-5">

      <div className="flex items-center justify-between p-3.5 rounded-2xl"
        style={{ background: (plan?.color || '#6b7280') + '12', border: `1.5px solid ${plan?.color || '#6b7280'}30` }}>
        <div>
          <p className="text-[11px] text-zinc-400 font-medium uppercase tracking-wide mb-0.5">Upgrade ke</p>
          <p className="font-bold text-zinc-900 text-sm">{plan?.name}</p>
          <p className="text-xs font-semibold" style={{ color: plan?.color }}>{plan?.priceLabel}</p>
        </div>
        <PlanBadge plan={plan} size="lg" />
      </div>

      <div className="flex flex-col items-center gap-3">
        {qrUrl ? (
          <div className="relative p-3 bg-white rounded-2xl shadow-md border border-zinc-100">
            <img src={qrUrl} alt="QRIS" width={qrSize} height={qrSize} className="block rounded-lg" />
          </div>
        ) : (
          <div style={{ width: qrSize, height: qrSize }}
            className="bg-zinc-50 rounded-2xl flex flex-col items-center justify-center border border-dashed border-zinc-200 gap-2">
            <svg className="w-8 h-8 text-zinc-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                d="M12 4v1m6 11h2m-6 0h-2v4m0-11v3m0 0h.01M12 12h4.01M16 20h4M4 12h4m12 0h.01M5 8h2a1 1 0 001-1V5a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1zm12 0h2a1 1 0 001-1V5a1 1 0 00-1-1h-2a1 1 0 00-1 1v2a1 1 0 001 1zM5 20h2a1 1 0 001-1v-2a1 1 0 00-1-1H5a1 1 0 00-1 1v2a1 1 0 001 1z" />
            </svg>
            <p className="text-xs text-zinc-400">QRIS tidak tersedia</p>
          </div>
        )}

        <div className={`flex items-center gap-2 px-4 py-2 rounded-xl ${isUrgent ? 'bg-red-50 border border-red-200' : 'bg-zinc-50 border border-zinc-100'}`}>
          <svg className={`w-3.5 h-3.5 flex-shrink-0 ${isUrgent ? 'text-red-500' : 'text-zinc-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <span className={`text-xs ${isUrgent ? 'text-red-600' : 'text-zinc-500'}`}>Berakhir dalam</span>
          <span className={`font-mono font-bold text-sm ${isUrgent ? 'text-red-600' : 'text-zinc-800'}`}>{mm}:{ss}</span>
        </div>
      </div>

      <div className="text-center py-1">
        <p className="text-3xl font-bold text-zinc-900">{fmtRp(amount)}</p>
        <p className="text-xs text-zinc-400 mt-1">Scan QRIS via aplikasi bank / e-wallet</p>
      </div>

      <div className="flex items-center gap-2 p-3 bg-zinc-50 rounded-xl border border-zinc-100">
        <div className="flex-1 min-w-0">
          <p className="text-[10px] text-zinc-400 mb-0.5">Order ID</p>
          <p className="text-xs font-mono text-zinc-600 truncate">{orderId}</p>
        </div>
        <button onClick={() => navigator.clipboard.writeText(orderId)}
          className="text-xs text-zinc-400 hover:text-zinc-700 px-2.5 py-1.5 rounded-lg hover:bg-zinc-200 flex-shrink-0 transition-colors">
          Copy
        </button>
      </div>

      {qrUrl && (
        <button onClick={downloadQR}
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border-2 border-dashed border-zinc-200 text-xs font-semibold text-zinc-500 hover:border-violet-400 hover:text-violet-600 hover:bg-violet-50 transition-all">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
          </svg>
          Download QR Code
        </button>
      )}

      <div className="flex items-center justify-between gap-3 px-1">
        <div className="flex items-center gap-2 text-xs text-zinc-400">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse flex-shrink-0" />
          Cek otomatis tiap 4 detik...
        </div>
        <button onClick={checkNow} disabled={checking}
          className="text-xs font-semibold text-violet-600 hover:text-violet-700 disabled:opacity-40 px-3 py-1.5 rounded-lg hover:bg-violet-50 transition-colors border border-violet-200 flex-shrink-0">
          {checking ? 'Mengecek...' : 'Cek Sekarang'}
        </button>
      </div>

      <button onClick={onCancel}
        className="w-full py-2.5 rounded-xl border border-zinc-200 text-sm font-medium text-zinc-500 hover:bg-zinc-50 hover:text-zinc-700 transition-colors">
        Batalkan
      </button>

    </div>
  );
}

// ─── Plan Upgrade Modal ───────────────────────────────────────────────────────

function UpgradeModal({ plans, currentPlan, apiKey, onClose, onSuccess, showToast }) {
  const [selected, setSelected] = useState(null);
  const [loading,  setLoading]  = useState(false);
  const [order,    setOrder]    = useState(null);

  const paidPlans = plans.filter(p => p.price > 0);

  async function handleOrder() {
    if (!selected) return;
    setLoading(true);
    try {
      const r = await fetch('/api/subscribe', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', 'X-API-Key': apiKey },
        body:    JSON.stringify({ plan: selected }),
      });
      const d = await r.json();
      if (!d.success) throw new Error(d.error || 'Gagal membuat order');
      setOrder(d.order);
    } catch (e) {
      showToast(e.message, 'error');
    } finally {
      setLoading(false);
    }
  }

  if (order) {
    const planInfo = plans.find(p => p.id === order.plan);
    return (
      <ModalQRIS title="Bayar via QRIS">
        <QrisDisplay
          qrisString={order.qrisString}
          amount={order.amount}
          orderId={order.orderId}
          expiresAt={order.expiresAt}
          plan={planInfo}
          onPaid={(result) => { onSuccess(result); }}
          onCancel={onClose}
        />
      </ModalQRIS>
    );
  }

  return (
    <Modal title="Upgrade Plan" onClose={onClose} maxW="max-w-lg">
      <div className="space-y-3 mb-6">
        {paidPlans.map(plan => (
          <button key={plan.id} onClick={() => setSelected(plan.id)}
            className={`w-full text-left p-4 rounded-xl border-2 transition-all ${selected === plan.id ? 'border-violet-500 bg-violet-50' : 'border-zinc-200 hover:border-zinc-300'}`}>
            <div className="flex items-start justify-between gap-3 mb-3">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-bold text-zinc-900">{plan.name}</span>
                  {currentPlan?.id === plan.id && (
                    <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-medium">Aktif</span>
                  )}
                </div>
                <p className="text-sm font-semibold" style={{ color: plan.color }}>{plan.priceLabel}</p>
              </div>
              <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 mt-0.5 ${selected === plan.id ? 'border-violet-500 bg-violet-500' : 'border-zinc-300'}`}>
                {selected === plan.id && <div className="w-2 h-2 rounded-full bg-white" />}
              </div>
            </div>
            <ul className="space-y-1">
              {plan.features.map(f => (
                <li key={f} className="flex items-center gap-2 text-xs text-zinc-600">
                  <svg className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                  </svg>
                  {f}
                </li>
              ))}
            </ul>
          </button>
        ))}
      </div>

      <button onClick={handleOrder} disabled={!selected || loading}
        className="w-full py-3 rounded-xl bg-violet-600 text-white font-semibold text-sm hover:bg-violet-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors">
        {loading ? 'Membuat order...' : selected ? `Bayar ${fmtRp(plans.find(p => p.id === selected)?.price || 0)}` : 'Pilih plan dulu'}
      </button>

      <p className="text-xs text-zinc-400 text-center mt-3">
        Pembayaran via QRIS · Aktif 30 hari · Tidak auto-renew
      </p>
    </Modal>
  );
}

// ─── Rotate Key Modal ─────────────────────────────────────────────────────────

function RotateKeyModal({ keyId, apiKey, plan, onDone, onClose, showToast }) {
  const [loading,    setLoading]    = useState(false);
  const [newKey,     setNewKey]     = useState(null);
  const [revealed,   setRevealed]   = useState(false);
  const [mode,       setMode]       = useState('rotate'); // 'rotate' | 'custom'
  const [customVal,  setCustomVal]  = useState('');
  const [customDone, setCustomDone] = useState(false);

  const canCustom = plan?.customApiKey === true;

  async function handleRotate() {
    if (!confirm('Generate API key baru? Key lama tidak bisa dipakai lagi.')) return;
    setLoading(true);
    try {
      const r = await fetch(`/api/keys/${keyId}/rotate`, {
        method:  'POST',
        headers: { 'X-API-Key': apiKey },
      });
      const d = await r.json();
      if (!d.success) throw new Error(d.error);
      setNewKey(d.apiKey);
    } catch (e) {
      showToast(e.message, 'error');
    } finally {
      setLoading(false);
    }
  }

  async function handleSetCustom() {
    const trimmed = customVal.trim();
    if (trimmed.length < 10) { showToast('Minimal 10 karakter', 'error'); return; }
    if (trimmed.length > 128) { showToast('Maksimal 128 karakter', 'error'); return; }
    if (!/^[a-zA-Z0-9_\-.]+$/.test(trimmed)) {
      showToast('Hanya huruf, angka, underscore, dash, dan titik yang diperbolehkan', 'error');
      return;
    }
    if (!confirm('Set custom API key? Key lama tidak bisa dipakai lagi.')) return;
    setLoading(true);
    try {
      const r = await fetch(`/api/keys/${keyId}/setcustom`, {
        method:  'POST',
        headers: { 'X-API-Key': apiKey, 'Content-Type': 'application/json' },
        body:    JSON.stringify({ customKey: trimmed }),
      });
      const d = await r.json();
      if (!d.success) throw new Error(d.error);
      setCustomDone(true);
      onDone(trimmed);
    } catch (e) {
      showToast(e.message, 'error');
    } finally {
      setLoading(false);
    }
  }

  // Tampilkan key baru hasil rotate
  if (newKey) {
    return (
      <Modal title="Simpan API Key Baru" onClose={() => { onDone(newKey); onClose(); }}>
        <div className="space-y-4">
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-sm text-amber-800">
            <strong>Ini satu-satunya kesempatan melihat key ini.</strong> Setelah ditutup, tidak bisa ditampilkan lagi.
          </div>
          <div className="relative">
            <div className="p-3 bg-zinc-950 rounded-xl font-mono text-sm text-emerald-300 break-all pr-24">
              {revealed ? newKey : '•'.repeat(Math.min(newKey.length, 48))}
            </div>
            <button onClick={() => setRevealed(v => !v)}
              className="absolute right-3 top-3 text-zinc-500 hover:text-zinc-300 text-xs px-2 py-1 rounded">
              {revealed ? 'Sembunyikan' : 'Lihat'}
            </button>
          </div>
          <div className="flex gap-2">
            <button onClick={() => copy(newKey, showToast)}
              className="flex-1 py-2.5 bg-zinc-900 text-white rounded-xl text-sm font-semibold hover:bg-zinc-800">
              Copy Key
            </button>
            <button onClick={() => { onDone(newKey); onClose(); }}
              className="flex-1 py-2.5 bg-emerald-600 text-white rounded-xl text-sm font-semibold hover:bg-emerald-700">
              Sudah disimpan
            </button>
          </div>
        </div>
      </Modal>
    );
  }

  // Tampilkan konfirmasi custom key berhasil
  if (customDone) {
    return (
      <Modal title="Custom API Key Aktif" onClose={onClose}>
        <div className="space-y-4">
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-sm text-emerald-800">
            Custom API key berhasil diset. Gunakan nilai yang kamu tulis tadi untuk semua request.
          </div>
          <button onClick={onClose}
            className="w-full py-2.5 bg-zinc-900 text-white rounded-xl text-sm font-semibold hover:bg-zinc-800">
            Tutup
          </button>
        </div>
      </Modal>
    );
  }

  return (
    <Modal title="Kelola API Key" onClose={onClose}>
      <div className="space-y-4">
        {/* Tab selector — hanya tampil kalau plan punya customApiKey */}
        {canCustom && (
          <div className="flex gap-1 p-1 bg-zinc-100 rounded-lg">
            <button onClick={() => setMode('rotate')}
              className={`flex-1 py-2 rounded-md text-xs font-semibold transition-all ${mode === 'rotate' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'}`}>
              Generate Acak
            </button>
            <button onClick={() => setMode('custom')}
              className={`flex-1 py-2 rounded-md text-xs font-semibold transition-all ${mode === 'custom' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'}`}>
              Custom Key
            </button>
          </div>
        )}

        {mode === 'rotate' && (
          <>
            <p className="text-sm text-zinc-600">
              API key lama akan <strong>tidak bisa dipakai lagi</strong>. Semua app yang pakai key lama harus diupdate.
              Key baru hanya ditampilkan <strong>sekali</strong>.
            </p>
            <div className="flex gap-2">
              <button onClick={onClose}
                className="flex-1 py-2.5 bg-zinc-100 text-zinc-700 rounded-xl text-sm font-semibold hover:bg-zinc-200">
                Batal
              </button>
              <button onClick={handleRotate} disabled={loading}
                className="flex-1 py-2.5 bg-red-600 text-white rounded-xl text-sm font-semibold hover:bg-red-700 disabled:opacity-40">
                {loading ? 'Memproses...' : 'Generate Baru'}
              </button>
            </div>
          </>
        )}

        {mode === 'custom' && (
          <>
            <div className="p-3 bg-violet-50 border border-violet-200 rounded-xl text-xs text-violet-700">
              <strong>Plan {plan?.name}:</strong> Kamu bisa set API key dengan nilai kustom. Key lama akan langsung hangus.
            </div>
            <div>
              <label className="block text-xs text-zinc-500 mb-1.5 font-medium">Nilai Custom Key</label>
              <input
                type="text"
                value={customVal}
                onChange={e => setCustomVal(e.target.value)}
                placeholder="contoh: myapp_prod_secret123"
                className="w-full border border-zinc-200 rounded-xl px-3 py-2.5 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-violet-400 transition-all"
              />
              <p className="text-[11px] text-zinc-400 mt-1.5">
                10–128 karakter. Hanya huruf, angka, underscore (_), dash (-), dan titik (.) yang diperbolehkan.
              </p>
            </div>
            <div className="flex gap-2">
              <button onClick={onClose}
                className="flex-1 py-2.5 bg-zinc-100 text-zinc-700 rounded-xl text-sm font-semibold hover:bg-zinc-200">
                Batal
              </button>
              <button onClick={handleSetCustom} disabled={loading || customVal.trim().length < 10}
                className="flex-1 py-2.5 bg-violet-600 text-white rounded-xl text-sm font-semibold hover:bg-violet-700 disabled:opacity-40">
                {loading ? 'Menyimpan...' : 'Set Custom Key'}
              </button>
            </div>
          </>
        )}
      </div>
    </Modal>
  );
}

// ─── Login Page ───────────────────────────────────────────────────────────────

function LoginPage() {
  const clientId = process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID || '';
  return (
    <>
      <Script src="https://accounts.google.com/gsi/client" strategy="afterInteractive" />
      <div id="g_id_onload" data-client_id={clientId} data-ux_mode="redirect"
        data-login_uri="/api/auth/callback" data-auto_prompt="false" />

      <main className="min-h-screen flex items-center justify-center px-5 py-12 bg-zinc-50">
        <div className="max-w-5xl w-full grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-16 items-center">

          <div>
            <div className="inline-flex items-center gap-2 mb-6">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span className="text-xs font-bold uppercase tracking-widest text-zinc-400">DongtubeDB</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold leading-tight tracking-tight text-zinc-900 mb-4">
              Database &amp; Storage<br />API siap pakai
            </h1>
            <p className="text-zinc-500 leading-relaxed mb-8">
              Login dengan Google dan langsung dapat API key. KV store, file storage, stream video — semua dalam satu endpoint.
            </p>

            <div className="grid grid-cols-3 gap-2 mb-8">
              {[
                { name: 'FREE',    storage: '10 MB',  price: 'Gratis',    color: '#6b7280' },
                { name: 'PREMIUM', storage: '500 MB', price: 'Rp 10.000', color: '#a855f7' },
                { name: 'MAX',     storage: '1 GB',   price: 'Rp 15.000', color: '#f59e0b' },
              ].map(p => (
                <div key={p.name} className="p-3 bg-white border border-zinc-200 rounded-xl text-center">
                  <div className="text-xs font-bold mb-1" style={{ color: p.color }}>{p.name}</div>
                  <div className="text-sm font-bold text-zinc-900">{p.storage}</div>
                  <div className="text-xs text-zinc-400 mt-0.5">{p.price}</div>
                </div>
              ))}
            </div>

            <div className="flex flex-col gap-3">
              <p className="text-xs text-zinc-400 font-medium">Login untuk dapat API key gratis</p>
              <div className="g_id_signin" data-type="standard" data-shape="rectangular"
                data-theme="outline" data-text="signin_with" data-size="large"
                data-logo_alignment="left" data-width="280" />
            </div>
          </div>

          <div className="space-y-3">
            {[
              { t: 'Key-Value JSON Store',  d: 'Simpan config, user data, state — akses via REST API' },
              { t: 'File Storage',          d: 'Upload semua tipe file, stream video & audio' },
              { t: 'API Key Permanen',      d: 'Key tidak bisa dihapus, bisa generate baru kapan saja' },
              { t: 'Storage Meter',         d: 'Pantau sisa storage realtime dengan progress bar' },
              { t: 'Upgrade Plan',          d: 'Bayar via QRIS, langsung aktif, tidak auto-renew' },
            ].map(f => (
              <div key={f.t} className="p-4 bg-white border border-zinc-200 rounded-xl">
                <p className="font-semibold text-zinc-900 text-sm">{f.t}</p>
                <p className="text-xs text-zinc-500 mt-0.5">{f.d}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
    </>
  );
}

// ─── Dashboard ────────────────────────────────────────────────────────────────

function Dashboard({ me: initialMe, plans, firstLoginKey, onLogout }) {
  const [toast,       setToast]       = useState(null);
  const [modal,       setModal]       = useState(null);
  // FIX: ambil apiKey dari sessionStorage saat mount supaya loadHistory & operasi
  // lain tetap bisa jalan di sesi yang bukan first-login.
  const [apiKey,      setApiKey]      = useState(() => {
    if (firstLoginKey) return firstLoginKey;
    if (typeof sessionStorage !== 'undefined') return sessionStorage.getItem('dtdb_apikey') || '';
    return '';
  });
  const [kvTab,       setKvTab]       = useState('write');
  const [fileTab,     setFileTab]     = useState('upload');
  const [tiktokTab,   setTiktokTab]   = useState('info');
  const [subHistory,  setSubHistory]  = useState([]);
  const [showHistory, setShowHistory] = useState(false);
  const [me,          setMe]          = useState(initialMe);

  const { user, plan, storage, keyInfo } = me;

  function showToast(msg, type = 'success') {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  }

  useEffect(() => {
    if (apiKey) window.__dtdb_apikey = apiKey;
  }, [apiKey]);

  useEffect(() => {
    const id = setInterval(async () => {
      try {
        const r = await fetch('/api/auth/me', { headers: { 'Cache-Control': 'no-store' } });
        const d = await r.json();
        if (d.success) setMe(d);
      } catch (_) {}
    }, 30_000);
    return () => clearInterval(id);
  }, []);

  async function loadHistory() {
    const key = apiKey || (typeof sessionStorage !== 'undefined' ? sessionStorage.getItem('dtdb_apikey') : '');
    if (!key) { showToast('API key tidak ditemukan. Silakan login ulang.', 'warn'); return; }
    try {
      const r = await fetch('/api/subscribe', { headers: { 'X-API-Key': key, 'Cache-Control': 'no-store' } });
      const d = await r.json();
      if (d.success) setSubHistory(d.history || []);
    } catch (_) {}
    setShowHistory(true);
  }

  function handleUpgradeSuccess() {
    showToast('Plan berhasil diupgrade! Halaman akan refresh...', 'success');
    setTimeout(() => window.location.reload(), 2000);
  }

  const hasStorage = storage && storage.limit > 0;

  return (
    <div className="min-h-screen bg-zinc-100">

      {/* Navbar */}
      <nav className="bg-white border-b border-zinc-200 sticky top-0 z-30 shadow-sm">
        <div className="max-w-3xl mx-auto px-4 h-14 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-7 h-7 rounded-lg bg-violet-600 flex items-center justify-center flex-shrink-0">
              <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2 1 3 3 3h10c2 0 3-1 3-3V7c0-2-1-3-3-3H7C5 4 4 5 4 7z M8 9h8M8 13h5" />
              </svg>
            </div>
            <span className="font-bold text-zinc-900 truncate">DongtubeDB</span>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <PlanBadge plan={plan} />
            {user?.picture
              ? <img src={user.picture} alt={user.name} className="w-8 h-8 rounded-full border-2 border-zinc-200 flex-shrink-0" />
              : <div className="w-8 h-8 rounded-full bg-zinc-200 flex items-center justify-center text-xs font-bold text-zinc-500 flex-shrink-0">{user?.name?.[0] || '?'}</div>
            }
            <button onClick={onLogout}
              className="text-xs text-zinc-400 hover:text-red-500 px-2.5 py-1.5 rounded-lg hover:bg-red-50 transition-colors whitespace-nowrap">
              Keluar
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-3xl mx-auto px-4 py-5 space-y-4">

        {/* First Login Banner */}
        {firstLoginKey && (
          <div className="rounded-2xl bg-amber-50 border border-amber-200 p-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-amber-400 flex items-center justify-center flex-shrink-0 mt-0.5">
                <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
                </svg>
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-amber-900 text-sm mb-0.5">Simpan API Key kamu sekarang!</p>
                <p className="text-xs text-amber-700 mb-3">Ditampilkan <strong>satu kali saja</strong>. Setelah refresh tidak bisa dilihat lagi.</p>
                <div className="flex items-center gap-2 bg-white rounded-xl p-2.5 border border-amber-200">
                  <code className="text-xs font-mono text-zinc-800 flex-1 break-all">{firstLoginKey}</code>
                  <button onClick={() => copy(firstLoginKey, showToast)}
                    className="flex-shrink-0 text-xs font-bold text-amber-700 hover:text-amber-900 px-3 py-1.5 bg-amber-100 hover:bg-amber-200 rounded-lg transition-colors">
                    Salin
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Profil & Plan */}
        <div className="bg-white rounded-2xl border border-zinc-200 shadow-sm overflow-hidden">
          <div className="h-20 w-full" style={{
            background: `linear-gradient(135deg, ${plan?.color || '#6b7280'}22 0%, ${plan?.color || '#6b7280'}08 100%)`,
            borderBottom: `1px solid ${plan?.color || '#6b7280'}20`,
          }} />
          <div className="px-5 pb-5 -mt-8">
            {/* FIX: tombol tidak akan overflow — items-start + mt-8 pada tombol */}
            <div className="flex items-start justify-between gap-3 mb-4">
              <div className="flex items-end gap-3 min-w-0">
                {user?.picture
                  ? <img src={user.picture} alt={user.name} className="w-16 h-16 rounded-2xl border-4 border-white shadow-md flex-shrink-0" />
                  : <div className="w-16 h-16 rounded-2xl border-4 border-white shadow-md bg-zinc-200 flex items-center justify-center text-xl font-bold text-zinc-500 flex-shrink-0">{user?.name?.[0] || '?'}</div>
                }
                <div className="mb-1 min-w-0">
                  <p className="font-bold text-zinc-900 text-base leading-tight truncate">{user?.name || 'Pengguna'}</p>
                  <p className="text-xs text-zinc-400 truncate">{user?.email}</p>
                </div>
              </div>
              <div className="flex-shrink-0 mt-8">
                {plan?.id === 'free' ? (
                  <button onClick={() => setModal('upgrade')}
                    className="px-3 py-1.5 bg-violet-600 text-white rounded-xl text-xs font-bold hover:bg-violet-700 shadow-sm transition-colors whitespace-nowrap">
                    Upgrade
                  </button>
                ) : (
                  <button onClick={() => setModal('upgrade')}
                    className="px-3 py-1.5 border-2 text-xs font-bold rounded-xl transition-colors hover:opacity-80 whitespace-nowrap"
                    style={{ borderColor: plan?.color, color: plan?.color }}>
                    Perpanjang
                  </button>
                )}
              </div>
            </div>

            <div className="flex items-center flex-wrap gap-2">
              <PlanBadge plan={plan} size="lg" />
              {plan?.expiry ? (
                <span className="text-xs text-zinc-400">
                  Aktif hingga <span className="text-zinc-600 font-medium">{fmtDate(plan.expiry)}</span>
                  {plan.daysLeft !== null && plan.daysLeft <= 7 && (
                    <span className="ml-1.5 px-2 py-0.5 bg-red-100 text-red-600 rounded-full font-semibold text-[11px]">{plan.daysLeft} hari lagi</span>
                  )}
                </span>
              ) : plan?.id === 'free' ? (
                <span className="text-xs text-zinc-400">Gratis selamanya</span>
              ) : (
                <span className="text-xs text-zinc-400">Tidak ada expiry</span>
              )}
            </div>
          </div>
        </div>

        {/* Storage */}
        {hasStorage && (
          <div className="bg-white rounded-2xl border border-zinc-200 shadow-sm p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg bg-zinc-100 flex items-center justify-center">
                  <svg className="w-3.5 h-3.5 text-zinc-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                  </svg>
                </div>
                <h2 className="text-sm font-bold text-zinc-700">Storage</h2>
              </div>
              <span className="text-xs text-zinc-400 bg-zinc-50 px-2 py-1 rounded-lg border border-zinc-100">{storage.totalFiles} file</span>
            </div>
            <StorageBar used={storage.used} limit={storage.limit} percent={storage.percent} plan={plan} />
            <div className="mt-4 grid grid-cols-3 gap-2">
              {[
                { l: 'Terpakai',  v: storage.usedHuman     },
                { l: 'Tersedia',  v: storage.remainingHuman },
                { l: 'Kapasitas', v: storage.limitHuman     },
              ].map(s => (
                <div key={s.l} className="p-3 bg-zinc-50 rounded-xl border border-zinc-100 text-center">
                  <p className="text-[10px] text-zinc-400 uppercase tracking-wide mb-1">{s.l}</p>
                  <p className="font-bold text-zinc-900 text-sm">{s.v}</p>
                </div>
              ))}
            </div>
            {storage.percent >= 80 && (
              <div className="mt-3 flex items-start gap-2.5 p-3 bg-amber-50 border border-amber-200 rounded-xl">
                <svg className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
                </svg>
                <p className="text-xs text-amber-800">
                  Storage hampir penuh ({storage.percent}%).{' '}
                  <button onClick={() => setModal('upgrade')} className="underline font-semibold hover:text-amber-900">Upgrade plan</button>
                  {' '}untuk kapasitas lebih besar.
                </p>
              </div>
            )}
          </div>
        )}

        {/* API Key */}
        <div className="bg-white rounded-2xl border border-zinc-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-zinc-100 flex items-center justify-center">
                <svg className="w-3.5 h-3.5 text-zinc-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
                </svg>
              </div>
              <h2 className="text-sm font-bold text-zinc-700">API Key</h2>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs font-semibold"
              style={keyInfo?.enabled
                ? { borderColor: '#86efac', background: '#f0fdf4', color: '#16a34a' }
                : { borderColor: '#fca5a5', background: '#fef2f2', color: '#dc2626' }}>
              <span className={`w-1.5 h-1.5 rounded-full ${keyInfo?.enabled ? 'bg-emerald-500' : 'bg-red-500'}`} />
              {keyInfo?.enabled ? 'Aktif' : 'Nonaktif'}
            </div>
          </div>

          {apiKey ? (
            <div className="mb-4">
              <div className="flex items-center gap-2 p-3.5 bg-zinc-950 rounded-xl">
                <code className="text-emerald-300 text-xs font-mono flex-1 break-all leading-relaxed">{apiKey}</code>
                <button onClick={() => copy(apiKey, showToast)}
                  className="flex-shrink-0 text-zinc-500 hover:text-white bg-zinc-800 hover:bg-zinc-700 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors">
                  Salin
                </button>
              </div>
              <p className="text-[11px] text-zinc-400 mt-2 px-1">Simpan key ini. Tidak akan ditampilkan lagi setelah refresh.</p>
            </div>
          ) : (
            <div className="mb-4 p-3.5 bg-zinc-50 rounded-xl border border-zinc-100">
              <p className="text-xs text-zinc-500">API key tersimpan aman di server.</p>
              <p className="text-[11px] text-zinc-400 mt-1">Gunakan tombol "Generate Baru" untuk mengganti. Key lama langsung hangus.</p>
            </div>
          )}

          {/* FIX: flex-col di mobile, flex-row di sm+ — tombol tidak terpotong */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
            <div className="flex-1 p-2.5 rounded-xl text-xs text-center border"
              style={plan?.customApiKey
                ? { background: '#faf5ff', borderColor: '#e9d5ff', color: '#7c3aed' }
                : { background: '#fafafa', borderColor: '#e4e4e7', color: '#a1a1aa' }}>
              {plan?.customApiKey ? `Plan ${plan.name}: Custom API Key tersedia` : 'Upgrade PREMIUM/MAX untuk Custom API Key'}
            </div>
            <button onClick={() => setModal('rotate')}
              className="flex-shrink-0 px-4 py-2.5 bg-zinc-900 hover:bg-zinc-700 text-white rounded-xl text-xs font-bold transition-colors whitespace-nowrap">
              Generate Baru
            </button>
          </div>

          {keyInfo && (
            <div className="mt-3 grid grid-cols-2 gap-2">
              <div className="flex items-center justify-between p-2.5 bg-zinc-50 rounded-xl border border-zinc-100 text-xs">
                <span className="text-zinc-400">Key ID</span>
                <span className="font-mono text-zinc-500">{keyInfo.id?.slice(0, 14)}…</span>
              </div>
              <div className="flex items-center justify-between p-2.5 bg-zinc-50 rounded-xl border border-zinc-100 text-xs">
                <span className="text-zinc-400">Dibuat</span>
                <span className="text-zinc-600 font-medium">{fmtDate(keyInfo.createdAt)}</span>
              </div>
            </div>
          )}
        </div>

        {/* Perbandingan Plan */}
        <div className="bg-white rounded-2xl border border-zinc-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4 gap-3">
            <h2 className="text-sm font-bold text-zinc-700">Perbandingan Plan</h2>
            {plan?.id === 'free' && (
              <button onClick={() => setModal('upgrade')}
                className="flex-shrink-0 text-xs font-semibold text-violet-600 hover:text-violet-700 px-3 py-1.5 bg-violet-50 rounded-lg border border-violet-200 hover:bg-violet-100 transition-colors whitespace-nowrap">
                Upgrade Sekarang
              </button>
            )}
          </div>
          {/* FIX: 1 kolom di mobile kecil, 3 kolom di sm+ */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {plans.map(p => {
              const isActive = plan?.id === p.id;
              return (
                <div key={p.id} className="rounded-2xl border-2 overflow-hidden transition-all"
                  style={isActive
                    ? { borderColor: p.color, boxShadow: `0 0 0 1px ${p.color}20` }
                    : { borderColor: '#e4e4e7' }}>
                  <div className="p-1.5 text-center text-[11px] font-bold"
                    style={{ background: p.color, color: '#fff' }}>
                    {p.name}
                  </div>
                  <div className="p-3">
                    {/* Di mobile tampilkan storage + status aktif dalam satu baris */}
                    <div className="flex sm:block items-center justify-between gap-2 mb-2">
                      <div>
                        <p className="font-bold text-zinc-900 text-base">{p.storageLabel}</p>
                        <p className="text-xs text-zinc-500 mt-0.5">{p.priceLabel}</p>
                      </div>
                      {isActive && (
                        <span className="sm:hidden flex-shrink-0 text-[11px] font-bold px-2.5 py-1 rounded-xl"
                          style={{ color: p.color, background: p.color + '15' }}>
                          Aktif
                        </span>
                      )}
                    </div>
                    <ul className="space-y-1.5">
                      {p.features.slice(0, 3).map(f => (
                        <li key={f} className="flex items-start gap-1.5 text-[11px] text-zinc-600">
                          <svg className="w-3 h-3 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" style={{ color: p.color }}>
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                          </svg>
                          {f}
                        </li>
                      ))}
                    </ul>
                    {isActive && (
                      <div className="hidden sm:block mt-3 text-center text-[11px] font-bold py-1.5 rounded-xl"
                        style={{ color: p.color, background: p.color + '15' }}>
                        Plan Aktif
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* KV Store Examples */}
        <div className="bg-white rounded-2xl border border-zinc-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-zinc-100 flex items-center justify-center">
                <svg className="w-3.5 h-3.5 text-zinc-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h7" />
                </svg>
              </div>
              <h2 className="text-sm font-bold text-zinc-700">KV Store</h2>
            </div>
            <span className="text-[11px] text-zinc-400 bg-zinc-50 px-2 py-1 rounded-lg border border-zinc-100">Key-Value JSON</span>
          </div>
          <Tabs
            tabs={[
              { label: 'Tulis', value: 'write' },
              { label: 'Baca',  value: 'read'  },
              { label: 'List',  value: 'list'  },
              { label: 'Hapus', value: 'del'   },
            ]}
            active={kvTab}
            onChange={setKvTab}
          />
          <CodeBlock code={kvExample(kvTab, apiKey)} />
        </div>

        {/* File Storage Examples */}
        <div className="bg-white rounded-2xl border border-zinc-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-zinc-100 flex items-center justify-center">
                <svg className="w-3.5 h-3.5 text-zinc-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                </svg>
              </div>
              <h2 className="text-sm font-bold text-zinc-700">File Storage</h2>
            </div>
            <span className="text-[11px] text-zinc-400 bg-zinc-50 px-2 py-1 rounded-lg border border-zinc-100">Upload &amp; Stream</span>
          </div>
          <Tabs
            tabs={[
              { label: 'Upload',   value: 'upload'   },
              { label: 'List',     value: 'list'     },
              { label: 'Download', value: 'download' },
              { label: 'Hapus',    value: 'del'      },
            ]}
            active={fileTab}
            onChange={setFileTab}
          />
          <CodeBlock code={fileExample(fileTab, apiKey)} />
        </div>

        {/* TikTok Downloader API */}
        <div className="bg-white rounded-2xl border border-zinc-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-zinc-100 flex items-center justify-center">
                <svg className="w-3.5 h-3.5 text-zinc-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                </svg>
              </div>
              <h2 className="text-sm font-bold text-zinc-700">TikTok Downloader API</h2>
            </div>
            <a
              href="https://whatsapp.com/channel/0029Vb91qeW17Emm4TVqu53K"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[11px] text-zinc-400 bg-zinc-50 px-2 py-1 rounded-lg border border-zinc-100 hover:bg-emerald-50 hover:border-emerald-200 hover:text-emerald-600 transition-colors whitespace-nowrap"
            >
              WhatsApp Channel
            </a>
          </div>

          <div className="mb-3 p-3 bg-zinc-50 rounded-xl border border-zinc-100 text-xs text-zinc-500 leading-relaxed">
            Semua endpoint TikTok otomatis upload hasil (thumbnail, video, audio, gambar slide) ke DongtubeDB dan mengembalikan URL permanen.
            Header <code className="font-mono bg-zinc-200 px-1 rounded text-zinc-600">X-API-Key</code> opsional — kalau tidak dikirim, sistem akan pakai key server.
          </div>

          <Tabs
            tabs={[
              { label: 'Info',  value: 'info'  },
              { label: 'Video', value: 'video' },
              { label: 'Audio', value: 'audio' },
              { label: 'Slide', value: 'slide' },
            ]}
            active={tiktokTab}
            onChange={setTiktokTab}
          />
          <CodeBlock code={tiktokExample(tiktokTab, apiKey)} />

          <div className="mt-3 grid grid-cols-2 gap-2">
            {[
              { path: '/api/tiktok',       desc: 'Info + thumbnail' },
              { path: '/api/tiktok/video', desc: 'Download video MP4' },
              { path: '/api/tiktok/audio', desc: 'Ekstrak audio MP3' },
              { path: '/api/tiktok/slide', desc: 'Gambar slide' },
            ].map(ep => (
              <div key={ep.path} className="flex flex-col gap-0.5 p-2.5 bg-zinc-50 rounded-xl border border-zinc-100">
                <code className="text-[11px] font-mono text-cyan-600">{ep.path}</code>
                <span className="text-[11px] text-zinc-400">{ep.desc}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Riwayat Pembayaran */}
        <div className="bg-white rounded-2xl border border-zinc-200 shadow-sm p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-zinc-100 flex items-center justify-center">
                <svg className="w-3.5 h-3.5 text-zinc-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
              </div>
              <h2 className="text-sm font-bold text-zinc-700">Riwayat Pembayaran</h2>
            </div>
            {!showHistory
              ? <button onClick={loadHistory} className="text-xs font-semibold text-violet-600 hover:text-violet-700 px-3 py-1.5 bg-violet-50 rounded-lg border border-violet-200 transition-colors flex-shrink-0">Muat Riwayat</button>
              : <button onClick={loadHistory} className="text-xs text-zinc-400 hover:text-zinc-600 px-3 py-1.5 rounded-lg hover:bg-zinc-50 transition-colors flex items-center gap-1 flex-shrink-0">
                  <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                  Refresh
                </button>
            }
          </div>
          {showHistory && (
            subHistory.length === 0
              ? <p className="text-sm text-zinc-400 text-center py-6 bg-zinc-50 rounded-xl border border-zinc-100">Belum ada riwayat pembayaran.</p>
              : <div className="space-y-2">
                  {subHistory.map(s => (
                    <div key={s.orderId} className="flex items-center justify-between p-3.5 bg-zinc-50 rounded-xl border border-zinc-100 gap-3">
                      <div className="min-w-0">
                        <p className="font-mono text-xs text-zinc-600 mb-1 truncate">{s.orderId}</p>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                          s.status === 'paid'    ? 'bg-emerald-100 text-emerald-700' :
                          s.status === 'pending' ? 'bg-amber-100 text-amber-700' :
                          s.status === 'expired' ? 'bg-zinc-200 text-zinc-500' :
                          'bg-red-100 text-red-600'
                        }`}>{s.status.toUpperCase()}</span>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <p className="text-xs font-semibold text-zinc-700">{plans.find(p => p.id === s.plan)?.name || s.plan}</p>
                        <p className="text-[11px] text-zinc-400 mt-0.5">{fmtDate(s.createdAt)}</p>
                      </div>
                    </div>
                  ))}
                </div>
          )}
        </div>

        <p className="text-xs text-zinc-400 text-center pb-4">
          DongtubeDB · <a href="https://dongtube.my.id" className="hover:text-zinc-600 transition-colors">dongtube.my.id</a>
        </p>
      </main>

      {/* Modals */}
      {modal === 'upgrade' && (
        <UpgradeModal
          plans={plans}
          currentPlan={plan}
          apiKey={apiKey}
          onClose={() => setModal(null)}
          onSuccess={handleUpgradeSuccess}
          showToast={showToast}
        />
      )}
      {modal === 'rotate' && (
        <RotateKeyModal
          keyId={keyInfo?.id}
          apiKey={apiKey}
          plan={plan}
          onDone={(newK) => {
            setApiKey(newK);
            if (typeof sessionStorage !== 'undefined') sessionStorage.setItem('dtdb_apikey', newK);
            setModal(null);
          }}
          onClose={() => setModal(null)}
          showToast={showToast}
        />
      )}

      <Toast toast={toast} />
    </div>
  );
}

// ─── Root Page ────────────────────────────────────────────────────────────────

export default function Page() {
  const [me,            setMe]            = useState(null);
  const [plans,         setPlans]         = useState([]);
  const [loading,       setLoading]       = useState(true);
  const [firstLoginKey, setFirstLoginKey] = useState(null);

  // FIX: hapus useCallback yang tidak terpakai (apiKeyFromCookie dead code)

  useEffect(() => {
    const urlParams    = new URLSearchParams(window.location.search);
    const isFirstLogin = urlParams.get('firstLogin') === '1';

    async function init() {
      try {
        const rp = await fetch('/api/plans');
        const dp = await rp.json();
        if (dp.success) setPlans(dp.plans);
      } catch (_) {}

      try {
        const rm = await fetch('/api/auth/me');
        const dm = await rm.json();

        if (dm.success) {
          setMe(dm);

          if (isFirstLogin) {
            window.history.replaceState({}, '', '/');
            try {
              const rk = await fetch('/api/auth/newkey');
              const dk = await rk.json();
              if (dk.apiKey) {
                setFirstLoginKey(dk.apiKey);
                sessionStorage.setItem('dtdb_apikey', dk.apiKey);
              }
            } catch (_) {}
          }
        }
      } catch (_) {}

      setLoading(false);
    }

    init();
  }, []);

  async function handleLogout() {
    await fetch('/api/auth/logout', { method: 'POST' }).catch(() => {});
    sessionStorage.removeItem('dtdb_apikey');
    window.location.reload();
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-zinc-50">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-2 border-violet-300 border-t-violet-600 rounded-full animate-spin" />
          <p className="text-sm text-zinc-400">Memuat...</p>
        </div>
      </div>
    );
  }

  if (!me) return <LoginPage />;

  return (
    <Dashboard
      me={me}
      plans={plans}
      firstLoginKey={firstLoginKey}
      onLogout={handleLogout}
    />
  );
}
