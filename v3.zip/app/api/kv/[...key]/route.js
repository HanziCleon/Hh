export const dynamic = 'force-dynamic';
// export const maxDuration = 60; // Vercel-only: comment out untuk self-hosted
import { NextResponse } from 'next/server';
import { ensureInit } from '../../../../src/lib/init.js';
import { getAuth } from '../../../../src/lib/apiAuth.js';
import { kvRead, kvWrite, kvDelete } from '../../../../src/services/KVService.js';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';


function normalizeKey(k) { return (k || '').replace(/^\/+/, '').replace(/\/{2,}/g, '/'); }

/**
 * Validasi key: tolak path traversal dan upaya bypass namespace user lain.
 * - Tidak boleh melebihi 512 karakter
 * - Tidak boleh mengandung segmen ".."
 * - Tidak boleh mengandung null byte
 * - User biasa tidak boleh membuat key yang diawali "u:<id>/" (prefix itu tugas server)
 */
const MAX_KEY_LENGTH = 512;
function validateKey(rawKey) {
  if (!rawKey) return false;
  // FIX BUG #3: Batasi panjang key untuk mencegah DoS via key raksasa yang
  // langsung masuk ke SQL query dan ke storage tanpa batas sebelumnya.
  if (rawKey.length > MAX_KEY_LENGTH) return false;
  // Tolak path traversal
  if (/(^|\/)\.\.($|\/)/.test(rawKey)) return false;
  // Tolak null byte
  if (rawKey.includes('\x00')) return false;
  // Tolak upaya user biasa menyisipkan prefix namespace secara eksplisit
  if (/^u:[^/]+\//.test(rawKey)) return false;
  return true;
}

function userKey(keyRecord, rawKey) {
  return keyRecord.role === 'admin' ? rawKey : `u:${keyRecord.id}/${rawKey}`;
}

export async function GET(request, { params }) {
  await ensureInit();
  const { keyRecord, error } = getAuth(request);
  if (error) return error;

  // FIX BUG-5: Di Next.js 15, params adalah Promise dan harus di-await.
  // Di Next.js 14 masih sync — await tidak merusak apa-apa, jadi aman di kedua versi.
  const resolvedParams = await params;
  const rawKey = normalizeKey(resolvedParams.key.join('/'));
  if (!rawKey || !validateKey(rawKey)) {
    return NextResponse.json({ success: false, error: 'Key tidak valid atau mengandung karakter yang tidak diizinkan.' }, { status: 400 });
  }

  try {
    const { data, sha } = kvRead(userKey(keyRecord, rawKey));
    if (data === null) return NextResponse.json({ success: false, error: 'Key not found.' }, { status: 404 });
    return NextResponse.json({ success: true, key: rawKey, data, sha }, { headers: { ETag: sha } });
  } catch {
    return NextResponse.json({ success: false, error: 'Read failed.' }, { status: 500 });
  }
}

export async function PUT(request, { params }) {
  await ensureInit();
  const { keyRecord, error } = getAuth(request);
  if (error) return error;

  // FIX BUG-5: await params untuk Next.js 15 compatibility
  const resolvedParams = await params;
  const rawKey = normalizeKey(resolvedParams.key.join('/'));
  if (!rawKey || !validateKey(rawKey)) {
    return NextResponse.json({ success: false, error: 'Key tidak valid atau mengandung karakter yang tidak diizinkan.' }, { status: 400 });
  }

  let rawBody;
  try { rawBody = await request.text(); } catch { rawBody = ''; }

  let value;
  try { value = JSON.parse(rawBody); } catch { value = null; }

  const sha = request.headers.get('if-match') || request.headers.get('x-sha') || undefined;

  try {
    const newSha = kvWrite(userKey(keyRecord, rawKey), value, sha);
    return NextResponse.json({ success: true, key: rawKey, sha: newSha });
  } catch (err) {
    if (err.status === 409) return NextResponse.json({ success: false, error: err.message }, { status: 409 });
    return NextResponse.json({ success: false, error: 'Write failed.' }, { status: 500 });
  }
}

export async function DELETE(request, { params }) {
  await ensureInit();
  const { keyRecord, error } = getAuth(request);
  if (error) return error;

  // FIX BUG-5: await params untuk Next.js 15 compatibility
  const resolvedParams = await params;
  const rawKey = normalizeKey(resolvedParams.key.join('/'));
  if (!rawKey || !validateKey(rawKey)) {
    return NextResponse.json({ success: false, error: 'Key tidak valid atau mengandung karakter yang tidak diizinkan.' }, { status: 400 });
  }

  try {
    const existed = kvDelete(userKey(keyRecord, rawKey));
    return NextResponse.json({ success: true, deleted: existed });
  } catch {
    return NextResponse.json({ success: false, error: 'Delete failed.' }, { status: 500 });
  }
}
