export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { ensureInit } from '../../../src/lib/init.js';
import { getAuth } from '../../../src/lib/apiAuth.js';
import { kvListDir, kvListAll } from '../../../src/services/KVService.js';
export { OPTIONS } from '../../../src/lib/corsOptions.js';


function normalizeKey(k) { return (k || '').replace(/^\/+/, '').replace(/\/{2,}/g, '/'); }

export async function GET(request) {
  await ensureInit();
  const { keyRecord, error } = getAuth(request);
  if (error) return error;

  const url = new URL(request.url);
  const prefix = url.searchParams.get('prefix') || '';
  const mode = url.searchParams.get('mode') || 'dir';
  const isAdmin = keyRecord.role === 'admin';

  const effectivePrefix = isAdmin
    ? normalizeKey(prefix)
    : `u:${keyRecord.id}/${normalizeKey(prefix)}`;

  try {
    if (mode === 'all') {
      const results = kvListAll(effectivePrefix);
      return NextResponse.json({
        success: true, prefix: effectivePrefix,
        items: results.map(r => ({
          ...r,
          key: isAdmin ? r.key : r.key.replace(`u:${keyRecord.id}/`, ''),
        })),
      });
    }
    return NextResponse.json({ success: true, prefix: effectivePrefix, items: kvListDir(effectivePrefix) });
  } catch (err) {
    return NextResponse.json({ success: false, error: 'Failed to list keys.' }, { status: 500 });
  }
}
