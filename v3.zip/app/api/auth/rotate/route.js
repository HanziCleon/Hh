export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { ensureInit } from '../../../../src/lib/init.js';
import { getAuth } from '../../../../src/lib/apiAuth.js';
import { rotateKey } from '../../../../src/services/KeyManager.js';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';


export async function POST(request) {
  await ensureInit();
  const { keyRecord, error } = getAuth(request);
  if (error) return error;

  const newRawKey = rotateKey(keyRecord.id);
  if (!newRawKey) return NextResponse.json({ success: false, error: 'Key not found.' }, { status: 404 });

  return NextResponse.json({
    success: true,
    notice: ' New API key generated — save it now, it will NOT be shown again!',
    apiKey: newRawKey,
  });
}
