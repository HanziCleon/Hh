export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';
import { NextResponse } from 'next/server';
import { OAuth2Client } from 'google-auth-library';
import { ensureInit } from '../../../../src/lib/init.js';
import { findOrCreateUser } from '../../../../src/services/UserService.js';
import { getKey } from '../../../../src/services/KeyManager.js';

const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

export async function POST(request) {
  await ensureInit();
  const { credential } = await request.json().catch(() => ({}));

  if (!credential) return NextResponse.json({ success: false, error: 'Missing credential.' }, { status: 400 });
  if (!process.env.GOOGLE_CLIENT_ID) return NextResponse.json({ success: false, error: 'GOOGLE_CLIENT_ID not configured.' }, { status: 500 });

  try {
    const ticket = await client.verifyIdToken({ idToken: credential, audience: process.env.GOOGLE_CLIENT_ID });
    const payload = ticket.getPayload();
    const { user, apiKey, isNew } = await findOrCreateUser({
      googleId: payload.sub, email: payload.email, name: payload.name, picture: payload.picture,
    });
    const keyInfo = getKey(user.keyId);
    return NextResponse.json({
      success: true, isNew, user, keyInfo,
      ...(apiKey ? { apiKey, notice: ' Save your API key — it will NOT be shown again!' } : {}),
    });
  } catch (err) {
    return NextResponse.json({ success: false, error: 'Google token verification failed.' }, { status: 401 });
  }
}
