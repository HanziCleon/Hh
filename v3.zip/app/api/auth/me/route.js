export const dynamic = 'force-dynamic';
import { NextResponse }    from 'next/server';
import { ensureInit }      from '../../../../src/lib/init.js';
import { getAuth }         from '../../../../src/lib/apiAuth.js';
import { getUserByKeyId }  from '../../../../src/services/UserService.js';
import { getKey }          from '../../../../src/services/KeyManager.js';
import { getOwnerStats }   from '../../../../src/services/DatabaseService.js';
import { formatBytes }     from '../../../../src/services/StorageService.js';
import {

  getActivePlan,
  getPlan,
  getPlanDaysLeft,
  checkStorageQuota,
} from '../../../../src/services/PlanService.js';
import { logger } from '../../../../src/utils/logger.js';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';


export async function GET(request) {
  await ensureInit();
  const { keyRecord, error } = getAuth(request);
  if (error) return error;

  const user    = getUserByKeyId(keyRecord.id);
  const keyInfo = getKey(keyRecord.id);

  // ── Plan info ──────────────────────────────────────────────────────────────
  const activePlan = getActivePlan(user || {});
  const planDetail = getPlan(activePlan);
  const daysLeft   = user ? getPlanDaysLeft(user) : null;

  // ── Storage stats ──────────────────────────────────────────────────────────
  let storageInfo = null;
  try {
    const stats = getOwnerStats(keyRecord.id);
    const quota = checkStorageQuota(user || {}, stats.totalSize || 0);
    storageInfo = {
      used:          stats.totalSize || 0,
      usedHuman:     formatBytes(stats.totalSize || 0),
      limit:         quota.limit,
      limitHuman:    formatBytes(quota.limit),
      remaining:     quota.remaining,
      remainingHuman: formatBytes(quota.remaining),
      percent:       quota.percent,
      totalFiles:    stats.totalFiles || 0,
    };
  } catch (err) {
    // BUG-4 FIX: Jangan silent fail — log error untuk debugging
    logger.warn(`Failed to get storage stats for ${keyRecord.id}: ${err.message}`);
    // Return null untuk storageInfo, endpoint tetap 200 dengan storageInfo=null
  }

  return NextResponse.json({
    success: true,
    user: user || {
      keyId: keyRecord.id,
      note: 'Manual API key (no Google account linked)',
    },
    keyInfo: keyInfo ? {
      id:         keyInfo.id,
      label:      keyInfo.label,
      role:       keyInfo.role,
      enabled:    keyInfo.enabled,
      createdAt:  keyInfo.createdAt,
      //  rawKey TIDAK dikembalikan — hanya tersedia sekali saat generate
    } : null,
    plan: {
      id:          activePlan,
      name:        planDetail.name,
      color:       planDetail.color,
      price:       planDetail.price,
      priceLabel:  planDetail.priceLabel,
      storageLabel: planDetail.storageLabel,
      customApiKey: planDetail.customApiKey,
      features:    planDetail.features,
      expiry:      user?.planExpiry || null,
      daysLeft,
      activatedAt: user?.planActivatedAt || null,
    },
    storage: storageInfo,
  });
}

// DELETE /api/auth/me — hapus akun sendiri
export async function DELETE(request) {
  await ensureInit();
  const { keyRecord, error } = getAuth(request);
  if (error) return error;

  const { deleteUser } = await import('../../../../src/services/UserService.js');
  const user = getUserByKeyId(keyRecord.id);
  if (!user) return NextResponse.json({ success: false, error: 'No user account linked.' }, { status: 404 });

  deleteUser(user.id);

  // FIX BUG #2: Hapus cookie sesi setelah akun dihapus.
  // Sebelumnya cookie _dtdb_session tetap ada di browser — setiap request berikutnya
  // akan gagal dengan 403 "key tidak ditemukan" yang membingungkan.
  // Bersihkan semua cookie auth sekaligus agar browser langsung redirect ke login.
  const res = NextResponse.json({ success: true, message: 'Account deleted.' });
  const cookieOpts = { maxAge: 0, path: '/' };
  res.cookies.set('_dtdb_session', '', cookieOpts);
  res.cookies.set('_dtdb_newkey',  '', cookieOpts);
  return res;
}
