export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { cookies }      from 'next/headers';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';


/**
 * GET /api/auth/newkey
 *
 * Endpoint sekali-pakai untuk mengambil API key baru setelah registrasi.
 * Key disimpan sementara di cookie HttpOnly selama 5 menit.
 * Setelah diambil, cookie langsung dihapus.
 *
 * Tidak memanggil ensureInit() karena hanya membaca cookie — tidak ada akses DB.
 */
export async function GET() {
  // FIX: cookies() harus di-await di Next.js 15 (async cookies API).
  // await tidak merusak apapun di Next.js 14 — aman di kedua versi.
  const cookieStore = await cookies();
  const rawKey = cookieStore.get('_dtdb_newkey')?.value;

  if (!rawKey) {
    return NextResponse.json({ success: false, error: 'Key tidak tersedia atau sudah kadaluarsa.' }, { status: 404 });
  }

  // Hapus cookie setelah diambil (one-time read)
  // FIX BUG #5: Sertakan atribut secure dan sameSite saat menghapus cookie
  // agar konsisten dengan saat cookie diset di callback/route.js (cookieOpts()).
  // Browser dengan mode strict bisa mengabaikan set-cookie tanpa atribut yang cocok.
  const response = NextResponse.json({
    success: true,
    apiKey:  rawKey,
    notice:  'Simpan key ini sekarang — tidak akan bisa ditampilkan lagi!',
  });

  response.cookies.set('_dtdb_newkey', '', {
    httpOnly: true,
    secure:   process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge:   0,
    path:     '/',
  });

  return response;
}
