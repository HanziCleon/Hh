export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';
import { NextResponse } from 'next/server';

export async function POST() {
  // Logout hanya menghapus cookie sesi — tidak butuh akses DB.
  // ensureInit() tidak diperlukan di sini.
  const response = NextResponse.json({ success: true });
  response.cookies.set('_dtdb_session', '', { maxAge: 0, path: '/' });
  return response;
}
