export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';
import { NextResponse } from 'next/server';
import { OAuth2Client } from 'google-auth-library';
import crypto from 'crypto';
import { ensureInit } from '../../../../src/lib/init.js';
import { findOrCreateUser } from '../../../../src/services/UserService.js';

const DOMAIN        = process.env.DOMAIN || 'http://localhost:3000';
const GOOGLE_CID    = process.env.GOOGLE_CLIENT_ID     || '';
const GOOGLE_SECRET = process.env.GOOGLE_CLIENT_SECRET || '';

// FIX-1: Gunakan OAuth2Client untuk verifikasi JWT signature Google One Tap
const _oauthClient = new OAuth2Client(GOOGLE_CID);

/**
 * Verifikasi JWT Google One Tap secara kriptografis.
 * Tidak bisa dipalsukan karena signature diverifikasi dengan public key Google.
 */
async function verifyGoogleCredential(credential) {
  const ticket = await _oauthClient.verifyIdToken({
    idToken:  credential,
    audience: GOOGLE_CID,
  });
  return ticket.getPayload(); // { sub, email, name, picture, ... }
}

/**
 * pendingSessions disimpan di global scope agar tidak hilang saat
 * Next.js hot-reload modul (module cache direfresh tapi global tetap).
 * TTL 2 menit sudah cukup untuk round-trip OAuth.
 */
if (!global.__dtdb_pending_sessions) {
  global.__dtdb_pending_sessions = new Map();
}
const pendingSessions = global.__dtdb_pending_sessions;

// Bersihkan token kadaluarsa setiap 5 menit
if (!global.__dtdb_ps_cleanup) {
  global.__dtdb_ps_cleanup = true;
  setInterval(() => {
    const now = Date.now();
    for (const [t, s] of pendingSessions) {
      if (s.exp < now) pendingSessions.delete(t);
    }
  }, 5 * 60 * 1000);
}

function cookieOpts() {
  return {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
  };
}

function buildResponse(keyId, apiKey, isNew) {
  const opts = cookieOpts();
  if (isNew && apiKey) {
    const resp = NextResponse.redirect(`${DOMAIN}/?firstLogin=1`, { status: 302 });
    resp.cookies.set('_dtdb_newkey', apiKey, { ...opts, maxAge: 300 });
    resp.cookies.set('_dtdb_session', keyId, { ...opts, maxAge: 60 * 60 * 24 * 30 });
    return resp;
  }
  const resp = NextResponse.redirect(`${DOMAIN}/`, { status: 302 });
  if (keyId) resp.cookies.set('_dtdb_session', keyId, { ...opts, maxAge: 60 * 60 * 24 * 30 });
  return resp;
}

// ─── POST: Google One Tap (credential langsung) ───────────────────────────────

export async function POST(request) {
  await ensureInit();
  let credential;
  try {
    const form = await request.formData();
    credential = form.get('credential');
  } catch {
    return NextResponse.redirect(`${DOMAIN}/?error=invalid_body`, { status: 302 });
  }
  if (!credential) return NextResponse.redirect(`${DOMAIN}/?error=no_credential`, { status: 302 });

  // FIX-1: Verifikasi JWT signature secara kriptografis — tidak bisa dipalsukan
  let profile;
  try {
    profile = await verifyGoogleCredential(credential);
  } catch (e) {
    console.error('[Auth] Google credential verification failed:', e.message);
    return NextResponse.redirect(`${DOMAIN}/?error=invalid_token`, { status: 302 });
  }

  const { sub: googleId, email, name, picture } = profile;
  if (!email) return NextResponse.redirect(`${DOMAIN}/?error=no_email`, { status: 302 });

  const { user, apiKey, isNew } = await findOrCreateUser({ googleId, email, name, picture });

  // FIX SARAN-5: Gunakan crypto.randomBytes (CSPRNG) bukan Math.random()
  // yang bukan cryptographically secure — meski TTL hanya 2 menit, best practice
  // tetap harus menggunakan sumber entropy yang aman untuk semua token.
  const token = crypto.randomBytes(24).toString('hex');
  pendingSessions.set(token, { keyId: user.keyId, apiKey, isNew, exp: Date.now() + 120_000 });

  return NextResponse.redirect(`${DOMAIN}/api/auth/callback?t=${token}`, { status: 302 });
}

// ─── GET: OAuth redirect (code) atau token relay ──────────────────────────────

export async function GET(request) {
  await ensureInit();
  const { searchParams } = new URL(request.url);

  // Token relay — dipakai setelah POST agar cookie bisa diset via GET redirect
  const t = searchParams.get('t');
  if (t) {
    const session = pendingSessions.get(t);
    pendingSessions.delete(t);
    if (!session || session.exp < Date.now()) {
      return NextResponse.redirect(`${DOMAIN}/?error=session_expired`, { status: 302 });
    }
    return buildResponse(session.keyId, session.apiKey, session.isNew);
  }

  // OAuth code exchange (Google redirect)
  const code = searchParams.get('code');
  if (!code) return NextResponse.redirect(`${DOMAIN}/?error=no_code`, { status: 302 });

  let tokenRes;
  try {
    const r = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id:     GOOGLE_CID,
        client_secret: GOOGLE_SECRET,
        redirect_uri:  `${DOMAIN}/api/auth/callback`,
        grant_type:    'authorization_code',
      }),
    });
    tokenRes = await r.json();
  } catch {
    return NextResponse.redirect(`${DOMAIN}/?error=token_exchange`, { status: 302 });
  }

  if (!tokenRes.id_token) return NextResponse.redirect(`${DOMAIN}/?error=no_id_token`, { status: 302 });

  // FIX-1: Verifikasi JWT dari OAuth code exchange juga
  let profile;
  try {
    profile = await verifyGoogleCredential(tokenRes.id_token);
  } catch (e) {
    console.error('[Auth] OAuth id_token verification failed:', e.message);
    return NextResponse.redirect(`${DOMAIN}/?error=invalid_token`, { status: 302 });
  }

  const { sub: googleId, email, name, picture } = profile;
  if (!email) return NextResponse.redirect(`${DOMAIN}/?error=no_email`, { status: 302 });

  const { user, apiKey, isNew } = await findOrCreateUser({ googleId, email, name, picture });
  return buildResponse(user.keyId, apiKey, isNew);
}
