export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';
// FIX BUG-4: maxDuration = 0 tidak valid di Next.js serverless (Vercel dll).
// Untuk self-hosted (custom server), timeout diatur di level server — baris ini tidak berpengaruh.
// Untuk Vercel Pro/Enterprise, set ke nilai maksimum plan (300 / 800 detik).
// Baris ini dikomentari agar tidak menyebabkan error di platform serverless.
// export const maxDuration = 300;

import { NextResponse } from 'next/server';
import {
  createWriteStream, mkdirSync, unlinkSync, existsSync,
  renameSync, copyFileSync,
} from 'fs';
import { pipeline } from 'stream/promises';
import { Readable, PassThrough } from 'stream';
import { tmpdir } from 'os';
import crypto from 'crypto';
import path from 'path';
import { ensureInit } from '../../../src/lib/init.js';
import { getAuth } from '../../../src/lib/apiAuth.js';
import { getFilePath } from '../../../src/services/StorageService.js';
import { insertFile, getOwnerStats } from '../../../src/services/DatabaseService.js';
import { getCategory, getMimeType, getExtension, isAllowedExtension } from '../../../src/utils/fileTypes.js';
export { OPTIONS } from '../../../src/lib/corsOptions.js';
import { addCors } from '../../../src/lib/corsOptions.js';


// FIX HMR: Mutex di global scope agar tidak reset saat Next.js hot-reload di development.
if (!global.__dtdb_upload_locks) global.__dtdb_upload_locks = new Map();
const _uploadLocks = global.__dtdb_upload_locks;

async function withUploadLock(keyId, fn) {
  while (_uploadLocks.get(keyId)) await _uploadLocks.get(keyId);
  let resolve;
  const lock = new Promise(r => { resolve = r; });
  _uploadLocks.set(keyId, lock);
  try { return await fn(); }
  finally { _uploadLocks.delete(keyId); resolve(); }
}

// ── Pindahkan file dengan fallback cross-filesystem ──────────────────────────
// renameSync() gagal dengan EXDEV jika src dan dst di filesystem berbeda
// (misal /tmp adalah tmpfs, storage ada di ext4)
function moveFile(src, dst) {
  try {
    renameSync(src, dst);
  } catch (e) {
    if (e.code === 'EXDEV') {
      copyFileSync(src, dst);
      unlinkSync(src);
    } else {
      throw e;
    }
  }
}

// ── Parse multipart + stream file langsung ke disk (tanpa buffer RAM) ────────
//
// FIX KRITIS — tee stream dengan PassThrough:
//   fileTypeFromStream() mengkonsumsi stream sampai habis.
//   Jika dijalankan SETELAH pipeline maka file sudah ditulis (aman),
//   tapi tidak bisa mendapat tipe. Jika SEBELUM pipeline, stream sudah ended.
//
//   Solusi: cabangkan fileStream ke DUA PassThrough secara paralel:
//     1. passForType  → fileTypeFromStream() (hanya baca ~4700 byte awal)
//     2. passForDisk  → writeStream ke disk
//   Data mengalir sekali, tidak ada copy ke RAM.
//
async function parseAndSaveMultipart(request, destPath, maxBytes) {
  const Busboy = (await import('busboy')).default;
  const { fileTypeFromStream } = await import('file-type');

  const contentType = request.headers.get('content-type') || '';

  const bb = Busboy({
    headers: { 'content-type': contentType },
    limits: { fileSize: Infinity, files: 1 },
  });

  return new Promise((resolve, reject) => {
    const fields = {};
    let fileInfo       = null;
    let fileSizeActual = 0;
    let detectedMime   = null;
    let detectedExt    = null;
    let sizeLimitHit   = false;
    let pipelinePromise = null;

    bb.on('field', (name, value) => { fields[name] = value; });

    bb.on('file', (fieldname, fileStream, info) => {
      fileInfo = info;

      // Hitung ukuran; hentikan jika melebihi batas
      fileStream.on('data', chunk => {
        fileSizeActual += chunk.length;
        if (!sizeLimitHit && fileSizeActual > maxBytes) {
          sizeLimitHit = true;
          // Drain stream agar busboy selesai normal (tidak hang)
          fileStream.resume();
        }
      });

      // Tee stream ke dua PassThrough paralel
      const passForType = new PassThrough();
      const passForDisk = new PassThrough();

      fileStream.pipe(passForType);
      fileStream.pipe(passForDisk);

      // Deteksi MIME dari awal stream
      const typePromise = fileTypeFromStream(passForType)
        .then(detected => {
          if (detected) {
            detectedMime = detected.mime;
            detectedExt  = detected.ext;
          }
          // Drain sisa passForType agar tidak block passForDisk
          passForType.resume();
        })
        .catch(() => { passForType.resume(); });

      // Tulis ke disk
      mkdirSync(path.dirname(destPath), { recursive: true });
      const writeStream = createWriteStream(destPath);

      pipelinePromise = Promise.all([
        pipeline(passForDisk, writeStream),
        typePromise,
      ]);
    });

    bb.on('finish', async () => {
      try {
        if (pipelinePromise) await pipelinePromise;
        resolve({ fields, fileInfo, actualSize: fileSizeActual, detectedMime, detectedExt, sizeLimitHit });
      } catch (e) {
        reject(e);
      }
    });

    bb.on('error', reject);

    // Pipe Web ReadableStream → Node.js busboy
    Readable.fromWeb(request.body).pipe(bb);
  });
}

// ── Main handler ─────────────────────────────────────────────────────────────

export async function POST(request) {
  await ensureInit();
  const { keyRecord, error } = getAuth(request);
  if (error) return error;

  const MAX_MB    = parseInt(process.env.MAX_FILE_SIZE_MB || '11264'); // default 11 GB
  const MAX_BYTES = MAX_MB * 1024 * 1024;

  // Early reject berdasarkan Content-Length (sebelum terima data)
  const contentLength = request.headers.get('content-length');
  if (contentLength) {
    const cl = parseInt(contentLength);
    // +10MB toleransi untuk multipart overhead
    if (cl > MAX_BYTES + 10 * 1024 * 1024) {
      return addCors(NextResponse.json(
        { success: false, error: `File terlalu besar. Maks: ${MAX_MB} MB` },
        { status: 413 }
      ));
    }
    // Early quota check
    if (keyRecord.maxStorage > 0) {
      const stats = getOwnerStats(keyRecord.id);
      if (stats.totalSize + cl > keyRecord.maxStorage) {
        return addCors(NextResponse.json({ success: false, error: 'Kuota storage penuh.' }, { status: 413 }));
      }
    }
  }

  // Generate ID file
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const rand  = crypto.randomBytes(8);
  let idStr = '';
  for (let i = 0; i < 8; i++) idStr += chars[rand[i] % chars.length];

  // Tulis ke tmp dulu (ekstensi belum diketahui)
  // Gunakan os.tmpdir() agar kompatibel di semua platform
  const tmpPath = path.join(tmpdir(), `dtdb_upload_${idStr}`);

  let parsed;
  try {
    parsed = await parseAndSaveMultipart(request, tmpPath, MAX_BYTES);
  } catch (e) {
    try { if (existsSync(tmpPath)) unlinkSync(tmpPath); } catch (_) {}
    // "stream has been aborted" → client disconnect / timeout saat upload
    const isAbort = e.message?.includes('aborted') || e.name === 'AbortError';
    return addCors(NextResponse.json(
      { success: false, error: isAbort
          ? 'Upload dibatalkan atau koneksi terputus. Coba upload ulang.'
          : `Gagal memproses upload: ${e.message}` },
      { status: isAbort ? 499 : 400 }
    ));
  }

  const { fields, fileInfo, actualSize, detectedMime, detectedExt, sizeLimitHit } = parsed;

  if (!fileInfo) {
    try { if (existsSync(tmpPath)) unlinkSync(tmpPath); } catch (_) {}
    return addCors(NextResponse.json({ success: false, error: 'Tidak ada file dalam request.' }, { status: 400 }));
  }

  // Tolak file yang melebihi batas (dihitung saat streaming)
  if (sizeLimitHit || actualSize > MAX_BYTES) {
    try { if (existsSync(tmpPath)) unlinkSync(tmpPath); } catch (_) {}
    return addCors(NextResponse.json(
      { success: false, error: `File terlalu besar. Maks: ${MAX_MB} MB` },
      { status: 413 }
    ));
  }

  // Tentukan ekstensi dan tipe MIME
  const originalName = (fileInfo.filename || 'unknown')
    .replace(/[^a-zA-Z0-9._\-() ]/g, '_')
    .substring(0, 255);
  const declaredExt  = getExtension(originalName);
  const ext          = detectedExt || declaredExt;
  const mimeType     = detectedMime
    || getMimeType(declaredExt)
    || fileInfo.mimeType
    || 'application/octet-stream';
  const category = getCategory(ext || declaredExt);

  // Blokir ekstensi yang bisa dieksekusi browser/server (XSS / RCE risk)
  if (!isAllowedExtension(ext || declaredExt)) {
    try { if (existsSync(tmpPath)) unlinkSync(tmpPath); } catch (_) {}
    return addCors(NextResponse.json(
      { success: false, error: `Ekstensi .${ext || declaredExt} tidak diizinkan.` },
      { status: 415 }
    ));
  }

  const isPublic = fields.public === 'true';
  const tags = fields.tags
    ? fields.tags.split(',').map(t => t.trim()).filter(Boolean)
    : [];
  let metadata = {};
  try { if (fields.metadata) metadata = JSON.parse(fields.metadata); } catch {}

  const fileId    = ext ? `${idStr}.${ext}` : idStr;
  const finalPath = getFilePath(category, fileId);
  const DOMAIN    = process.env.DOMAIN || process.env.NEXT_PUBLIC_DOMAIN || 'http://localhost:3000';

  return withUploadLock(keyRecord.id, async () => {
    // Quota check final dengan ukuran nyata
    if (keyRecord.maxStorage > 0) {
      const stats = getOwnerStats(keyRecord.id);
      if (stats.totalSize + actualSize > keyRecord.maxStorage) {
        try { unlinkSync(tmpPath); } catch (_) {}
        return addCors(NextResponse.json({ success: false, error: 'Kuota storage penuh.' }, { status: 413 }));
      }
    }

    // Pindahkan tmp → lokasi final
    // Gunakan moveFile() yang handle EXDEV (cross-filesystem rename)
    try {
      mkdirSync(path.dirname(finalPath), { recursive: true });
      moveFile(tmpPath, finalPath);
    } catch (e) {
      try { if (existsSync(tmpPath)) unlinkSync(tmpPath); } catch (_) {}
      return addCors(NextResponse.json(
        { success: false, error: `Gagal menyimpan file: ${e.message}` },
        { status: 500 }
      ));
    }

    // Simpan record ke database
    const record = {
      id: fileId, originalName, storedName: fileId, category, mimeType,
      size: actualSize, apiKeyId: keyRecord.id, owner: keyRecord.label,
      uploadedAt: new Date().toISOString(), downloads: 0, lastAccessed: null,
      public: isPublic, tags, metadata,
    };

    try {
      insertFile(record);
    } catch (e) {
      try { if (existsSync(finalPath)) unlinkSync(finalPath); } catch (_) {}
      return addCors(NextResponse.json(
        { success: false, error: `Gagal simpan record: ${e.message}` },
        { status: 500 }
      ));
    }

    return addCors(NextResponse.json({
      success: true,
      file: {
        id: fileId,
        url: `${DOMAIN}/api/files/${fileId}`,
        originalName, category, mimeType,
        size: actualSize,
        uploadedAt: record.uploadedAt,
        public: isPublic, tags,
      },
    }, { status: 201 }));
  });
}
