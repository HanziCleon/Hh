export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { ensureInit } from '../../../src/lib/init.js';
import { getAuth } from '../../../src/lib/apiAuth.js';
import { listFiles } from '../../../src/services/DatabaseService.js';
export { OPTIONS } from '../../../src/lib/corsOptions.js';
import { addCors } from '../../../src/lib/corsOptions.js';

const DOMAIN = process.env.DOMAIN || process.env.NEXT_PUBLIC_DOMAIN || '';

export async function GET(request) {
  await ensureInit();
  const { keyRecord, error } = getAuth(request);
  if (error) return error;

  const url = new URL(request.url);
  const p = url.searchParams;
  const isAdmin = keyRecord.role === 'admin';
  const owner = p.get('owner');

  const result = listFiles({
    apiKeyId: isAdmin && !owner ? undefined : isAdmin && owner ? owner : keyRecord.id,
    category: p.get('category'),
    search: p.get('search'),
    sort: p.get('sort'),
    order: p.get('order'),
    page: parseInt(p.get('page')) || 1,
    limit: parseInt(p.get('limit')) || 50,
    tags: p.get('tags') ? p.get('tags').split(',').map(t => t.trim()) : undefined,
  });

  // Tambahkan url ke setiap item
  result.items = result.items.map(f => ({
    ...f,
    url: `${DOMAIN}/api/files/${f.id}`,
  }));

  return addCors(NextResponse.json({ success: true, ...result }));
}
