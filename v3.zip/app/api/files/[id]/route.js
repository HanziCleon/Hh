export const dynamic = 'force-dynamic';
export const runtime  = 'nodejs';

import { NextResponse } from 'next/server';
import { createReadStream, existsSync, statSync, unlinkSync } from 'fs';
import { Readable } from 'stream';
import { ensureInit }      from '../../../../src/lib/init.js';
import { getAuth, getOptionalAuth } from '../../../../src/lib/apiAuth.js';
import { getFilePath } from '../../../../src/services/StorageService.js';
import { getFile, deleteRecord, updateFile, recordDownload } from '../../../../src/services/DatabaseService.js';
import { getMimeType, getExtension } from '../../../../src/utils/fileTypes.js';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';
import { addCors } from '../../../../src/lib/corsOptions.js';


const MAX_CHUNK = 2 * 1024 * 1024; // 2 MB per chunk — cegah OOM saat range terbuka

export async function GET(request, { params }) {
  await ensureInit();
  // FIX: await params untuk Next.js 15 compatibility (params adalah Promise di Next.js 15)
  const { id } = await params;
  if (!/^[a-zA-Z0-9._\-]{1,100}$/.test(id)) {
    return addCors(NextResponse.json({ success: false, error: 'Invalid file ID.' }, { status: 400 }));
  }

  const record = getFile(id);
  if (!record) return addCors(NextResponse.json({ success: false, error: 'File not found.' }, { status: 404 }));

  if (!record.public) {
    const authResult = getOptionalAuth(request);
    // FIX BUG-7: rate-limited → 429 bukan 401 (pesan sebelumnya menyesatkan)
    if (authResult.rateLimited) {
      return addCors(NextResponse.json({ success: false, error: 'Rate limit exceeded. Coba lagi dalam beberapa saat.' }, { status: 429 }));
    }
    const { keyRecord } = authResult;
    if (!keyRecord) return addCors(NextResponse.json({ success: false, error: 'This file is private. Provide an API key.' }, { status: 401 }));
    if (keyRecord.id !== record.apiKeyId && keyRecord.role !== 'admin') {
      return addCors(NextResponse.json({ success: false, error: 'Access denied.' }, { status: 403 }));
    }
  }

  const filePath = getFilePath(record.category, record.storedName);
  if (!existsSync(filePath)) return addCors(NextResponse.json({ success: false, error: 'File not found on disk.' }, { status: 404 }));

  const stat      = statSync(filePath);
  const fileSize  = stat.size;
  const mimeType  = record.mimeType || getMimeType(getExtension(record.storedName));
  const safeCache = record.public ? 'public, max-age=31536000, immutable' : 'private, no-store';
  // FIX #4: originalName bisa null → crash tanpa fallback
  // FIX HEADER-INJECT: strip semua karakter kontrol (\r \n \t dll.) + quote + backslash.
  // Meski originalName disanitasi saat upload, admin bisa edit DB langsung dan memasukkan
  // \r\n yang dapat memisahkan/menginjeksi HTTP header (HTTP response splitting).
  const safeName  = (record.originalName || record.storedName || 'file')
    .replace(/[\x00-\x1f\x7f"\\]/g, '_')
    .trim() || 'file';

  // FIX BUG-5: SVG XSS — file SVG (dan format scriptable lain) dirender inline di browser
  // dan bisa eksekusi JavaScript di origin yang sama → stored XSS.
  // Paksa Content-Disposition: attachment untuk format yang bisa mengandung script.
  const SCRIPTABLE_TYPES = new Set(['image/svg+xml', 'application/xml', 'text/xml', 'application/xhtml+xml', 'text/html']);
  const forceDownload = SCRIPTABLE_TYPES.has(mimeType.split(';')[0].trim());

  const commonHeaders = {
    'Content-Type':              mimeType,
    'Accept-Ranges':             'bytes',
    'Cache-Control':             safeCache,
    'Content-Disposition':       forceDownload
      ? `attachment; filename="${safeName}"`
      : `inline; filename="${safeName}"`,
    // FIX BUG-5: nosniff wajib ada di semua respons file untuk mencegah MIME sniffing
    'X-Content-Type-Options':    'nosniff',
    'X-File-ID':                 record.id,
    'X-File-Category':           record.category,
    'Access-Control-Allow-Origin': '*',
  };

  // ── JSON Auto Pretty-Print ─────────────────────────────────────────────────
  // Jika file adalah JSON dan diakses langsung dari browser (Accept: text/html),
  // tampilkan JSON viewer HTML yang profesional — bukan raw text.
  const isJsonMime = mimeType.split(';')[0].trim() === 'application/json'
    || (record.storedName || '').endsWith('.json');
  const acceptHdr  = request.headers.get('accept') || '';
  const isBrowser  = acceptHdr.includes('text/html');

  // FIX BUG-JSONMEM: Batasi JSON viewer ke maks 5MB.
  // Tanpa batas ini, JSON 100MB dibaca penuh ke RAM → OOM crash server.
  const JSON_VIEWER_MAX = 5 * 1024 * 1024; // 5 MB
  if (isJsonMime && isBrowser && existsSync(filePath) && fileSize <= JSON_VIEWER_MAX) {
    try {
      const raw  = (await import('fs')).readFileSync(filePath, 'utf8');
      const json = JSON.parse(raw);
      const pretty = JSON.stringify(json, null, 2);
      const escaped = pretty
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');

      // Syntax-highlight: strings biru, numbers ungu, keys hijau, booleans/null oranye
      const highlighted = escaped.replace(
        /("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g,
        (match) => {
          if (/^"/.test(match)) {
            if (/:$/.test(match)) return `<span class="jk">${match}</span>`;
            return `<span class="js">${match}</span>`;
          }
          if (/true|false/.test(match)) return `<span class="jb">${match}</span>`;
          if (/null/.test(match))       return `<span class="jn">${match}</span>`;
          return `<span class="ji">${match}</span>`;
        }
      );

      const byteSize = Buffer.byteLength(raw, 'utf8');
      const kbSize   = byteSize < 1024
        ? `${byteSize} B`
        : byteSize < 1024 * 1024
        ? `${(byteSize / 1024).toFixed(1)} KB`
        : `${(byteSize / 1024 / 1024).toFixed(2)} MB`;

      const lineCount = raw.split('\n').length;
      const domain = process.env.DOMAIN || process.env.NEXT_PUBLIC_DOMAIN || '';
      const rawUrl = `${domain}/api/files/${record.id}`;

      const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${safeName}</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#0f1117;color:#e2e8f0;min-height:100vh}
  .topbar{position:sticky;top:0;z-index:10;background:#161b27;border-bottom:1px solid #2d3748;padding:12px 20px;display:flex;align-items:center;gap:12px;flex-wrap:wrap}
  .badge{display:inline-flex;align-items:center;gap:6px;background:#1e2535;border:1px solid #2d3748;border-radius:8px;padding:4px 10px;font-size:12px;color:#94a3b8}
  .badge .dot{width:7px;height:7px;border-radius:50%;background:#22c55e;animation:pulse 2s infinite}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
  .filename{font-weight:700;font-size:15px;color:#f1f5f9;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .actions{display:flex;gap:8px;margin-left:auto}
  .btn{display:inline-flex;align-items:center;gap:5px;padding:6px 14px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;border:none;transition:.15s}
  .btn-ghost{background:transparent;color:#94a3b8;border:1px solid #2d3748}.btn-ghost:hover{background:#1e2535;color:#e2e8f0}
  .btn-primary{background:#3b82f6;color:#fff}.btn-primary:hover{background:#2563eb}
  .btn-copy{background:#1e2535;color:#94a3b8;border:1px solid #2d3748}.btn-copy:hover{background:#262f42;color:#e2e8f0}
  .meta-row{display:flex;gap:8px;flex-wrap:wrap;padding:10px 20px;background:#0d1117;border-bottom:1px solid #1e2535;font-size:11px;color:#64748b}
  .meta-row span b{color:#94a3b8}
  .container{padding:20px;overflow-x:auto}
  pre{background:#0d1117;border:1px solid #1e2535;border-radius:12px;padding:24px;font-family:'Fira Code','Cascadia Code','JetBrains Mono',monospace;font-size:13px;line-height:1.7;tab-size:2;overflow-x:auto;counter-reset:line}
  .jk{color:#7dd3a8;font-weight:600}
  .js{color:#93c5fd}
  .ji{color:#f9a8d4}
  .jb{color:#fbbf24}
  .jn{color:#fb923c}
  .toast{position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:#22c55e;color:#fff;padding:10px 20px;border-radius:10px;font-size:13px;font-weight:600;opacity:0;transition:opacity .3s;pointer-events:none;z-index:99}
  .toast.show{opacity:1}
</style>
</head>
<body>
<div class="topbar">
  <span class="filename">📄 ${safeName}</span>
  <div class="badge"><span class="dot"></span>JSON</div>
  <div class="actions">
    <button class="btn btn-copy" onclick="copyRaw()">⎘ Copy URL</button>
    <button class="btn btn-ghost" onclick="copyJson()">⎘ Copy JSON</button>
    <a class="btn btn-primary" href="${rawUrl}" download="${safeName}">↓ Download</a>
  </div>
</div>
<div class="meta-row">
  <span><b>Size:</b> ${kbSize}</span>
  <span><b>Lines:</b> ${lineCount}</span>
  <span><b>ID:</b> ${record.id}</span>
  <span><b>Uploaded:</b> ${new Date(record.uploadedAt).toLocaleString('id-ID')}</span>
  <span><b>Raw URL:</b> <a href="${rawUrl}" style="color:#3b82f6">${rawUrl}</a></span>
</div>
<div class="container">
  <pre id="json-content">${highlighted}</pre>
</div>
<div class="toast" id="toast"></div>
<script>
const RAW = ${JSON.stringify(raw)};
const RAW_URL = ${JSON.stringify(rawUrl)};
function showToast(msg){
  const t=document.getElementById('toast');
  t.textContent=msg;t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'),2000);
}
function copyJson(){
  navigator.clipboard.writeText(RAW).then(()=>showToast('JSON copied!')).catch(()=>showToast('Failed'));
}
function copyRaw(){
  navigator.clipboard.writeText(RAW_URL).then(()=>showToast('URL copied!')).catch(()=>showToast('Failed'));
}
</script>
</body>
</html>`;

      return new Response(html, {
        status: 200,
        headers: {
          'Content-Type': 'text/html; charset=utf-8',
          'Cache-Control': safeCache,
          'Access-Control-Allow-Origin': '*',
          'X-File-ID': record.id,
        },
      });
    } catch (_) {
      // JSON parse gagal atau baca file gagal → fallback ke serve biasa
    }
  }

  const range = request.headers.get('range');
  if (range) {
    // Support: "bytes=N-M", "bytes=N-" (open end)
    // Tidak support suffix "bytes=-N" — browser video player tidak pakai ini
    const match = range.replace(/bytes=/, '').match(/^(\d+)-(\d*)$/);
    if (!match) {
      return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${fileSize}` } });
    }

    const start = parseInt(match[1], 10);

    // FIX RFC 7233: jika end eksplisit tapi lebih besar dari EOF, clamp ke fileSize-1
    // Sebelumnya langsung 416 — ini salah, browser sah kirim end > fileSize
    let end = match[2] !== ''
      ? Math.min(parseInt(match[2], 10), fileSize - 1)  // clamp, bukan 416
      : Math.min(start + MAX_CHUNK - 1, fileSize - 1);  // open range → cap 2MB

    if (start >= fileSize || start > end) {
      return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${fileSize}` } });
    }

    recordDownload(id);
    const stream = createReadStream(filePath, { start, end });
    return new Response(Readable.toWeb(stream), {
      status: 206,
      headers: {
        ...commonHeaders,
        'Content-Range':  `bytes ${start}-${end}/${fileSize}`,
        'Content-Length': String(end - start + 1),
      },
    });
  }

  // Tanpa range — stream penuh, tidak buffer ke memory
  recordDownload(id);
  const stream = createReadStream(filePath);
  return new Response(Readable.toWeb(stream), {
    status: 200,
    headers: { ...commonHeaders, 'Content-Length': String(fileSize) },
  });
}

export async function HEAD(request, { params }) {
  await ensureInit();
  // FIX: await params untuk Next.js 15 compatibility
  const { id } = await params;
  if (!/^[a-zA-Z0-9._\-]{1,100}$/.test(id)) return new Response(null, { status: 400 });

  const record = getFile(id);
  if (!record) return new Response(null, { status: 404 });

  if (!record.public) {
    const authResult = getOptionalAuth(request);
    // FIX BUG-7: rate-limited → 429
    if (authResult.rateLimited) return new Response(null, { status: 429 });
    const { keyRecord } = authResult;
    if (!keyRecord || (keyRecord.id !== record.apiKeyId && keyRecord.role !== 'admin')) {
      return new Response(null, { status: 403 });
    }
  }

  const filePath = getFilePath(record.category, record.storedName);
  if (!existsSync(filePath)) return new Response(null, { status: 404 });

  const stat = statSync(filePath);
  // FIX BUG-HEAD-CORS: HEAD response harus juga menyertakan CORS header.
  // Tanpa ini, browser yang melakukan HEAD request untuk cek metadata file
  // (mis. video player saat probe durasi) akan diblokir CORS.
  return new Response(null, {
    status: 200,
    headers: {
      'Content-Length':             String(stat.size),
      'Content-Type':               record.mimeType || 'application/octet-stream',
      'Accept-Ranges':              'bytes',
      'Access-Control-Allow-Origin': '*',
    },
  });
}

export async function DELETE(request, { params }) {
  await ensureInit();
  const { keyRecord, error } = getAuth(request);
  if (error) return error;

  // FIX: await params untuk Next.js 15 compatibility
  const { id } = await params;
  const record = getFile(id);
  if (!record) return addCors(NextResponse.json({ success: false, error: 'File not found.' }, { status: 404 }));

  if (keyRecord.id !== record.apiKeyId && keyRecord.role !== 'admin') {
    return addCors(NextResponse.json({ success: false, error: 'Access denied.' }, { status: 403 }));
  }

  try { unlinkSync(getFilePath(record.category, record.storedName)); } catch {}
  deleteRecord(id);
  return addCors(NextResponse.json({ success: true, message: 'File deleted successfully.' }));
}

export async function PATCH(request, { params }) {
  await ensureInit();
  const { keyRecord, error } = getAuth(request);
  if (error) return error;

  // FIX: await params untuk Next.js 15 compatibility
  const { id } = await params;
  const record = getFile(id);
  if (!record) return addCors(NextResponse.json({ success: false, error: 'File not found.' }, { status: 404 }));

  if (keyRecord.id !== record.apiKeyId && keyRecord.role !== 'admin') {
    return addCors(NextResponse.json({ success: false, error: 'Access denied.' }, { status: 403 }));
  }

  const body = await request.json().catch(() => ({}));
  const updates = {};
  for (const k of ['public', 'tags', 'metadata']) {
    if (body[k] !== undefined) updates[k] = body[k];
  }

  // FIX: Batasi ukuran metadata dan jumlah tags untuk mencegah DoS via disk I/O.
  // Tanpa batas ini, user bisa PATCH metadata dengan objek JSON raksasa (ratusan MB)
  // yang akan di-serialize dan ditulis ke disk setiap kali, menghabiskan I/O & storage.
  if (updates.metadata !== null && updates.metadata !== undefined) {
    const metaStr = JSON.stringify(updates.metadata);
    if (metaStr.length > 64 * 1024) { // 64 KB
      return addCors(NextResponse.json({ success: false, error: 'Metadata terlalu besar (maks 64 KB).' }, { status: 413 }));
    }
  }
  if (Array.isArray(updates.tags)) {
    if (updates.tags.length > 50) {
      return addCors(NextResponse.json({ success: false, error: 'Terlalu banyak tags (maks 50).' }, { status: 400 }));
    }
    // Sanitasi setiap tag: string, max 64 chars
    updates.tags = updates.tags
      .filter(t => typeof t === 'string')
      .map(t => t.trim().substring(0, 64))
      .filter(Boolean);
  }

  updateFile(id, updates);
  return addCors(NextResponse.json({ success: true, file: getFile(id) }));
}
