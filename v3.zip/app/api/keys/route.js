export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { ensureInit } from '../../../src/lib/init.js';
import { getAuth, getAdminAuth } from '../../../src/lib/apiAuth.js';
import { createKey, listKeys } from '../../../src/services/KeyManager.js';
export { OPTIONS } from '../../../src/lib/corsOptions.js';


export async function GET(request) {
  await ensureInit();
  const { error } = getAdminAuth(request);
  if (error) return error;
  const keys = listKeys();
  return NextResponse.json({ success: true, total: keys.length, keys });
}

export async function POST(request) {
  await ensureInit();
  const { error } = getAdminAuth(request);
  if (error) return error;

  const body = await request.json().catch(() => ({}));
  const { label, role = 'user', maxStorage = 0, rateLimit = 0 } = body;

  if (!label || typeof label !== 'string' || label.trim().length < 2) {
    return NextResponse.json({ success: false, error: 'label is required (min 2 chars).' }, { status: 400 });
  }
  if (!['user', 'admin'].includes(role)) {
    return NextResponse.json({ success: false, error: 'role must be "user" or "admin".' }, { status: 400 });
  }

  const { record, rawKey } = createKey({ label: label.trim(), role, maxStorage: parseInt(maxStorage) || 0, rateLimit: parseInt(rateLimit) || 0 });
  return NextResponse.json({ success: true, message: ' Save this key — it will NOT be shown again!', apiKey: rawKey, record }, { status: 201 });
}
