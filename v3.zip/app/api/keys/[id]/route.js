export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { ensureInit } from '../../../../src/lib/init.js';
import { getAuth, getAdminAuth } from '../../../../src/lib/apiAuth.js';
import { getKey, deleteKey, updateKey } from '../../../../src/services/KeyManager.js';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';


export async function GET(request, { params }) {
  await ensureInit();
  const { keyRecord, error } = getAuth(request);
  if (error) return error;

  // FIX Bug 1: await params untuk Next.js 15 compatibility
  const { id } = await params;
  if (keyRecord.role !== 'admin' && keyRecord.id !== id) {
    return NextResponse.json({ success: false, error: 'Access denied.' }, { status: 403 });
  }
  const key = getKey(id);
  if (!key) return NextResponse.json({ success: false, error: 'Key not found.' }, { status: 404 });
  return NextResponse.json({ success: true, key });
}

export async function PATCH(request, { params }) {
  await ensureInit();
  const { error } = getAdminAuth(request);
  if (error) return error;

  // FIX Bug 1: await params untuk Next.js 15 compatibility
  const { id } = await params;

  // FIX Bug 4: Cek eksistensi key secara eksplisit sebelum update.
  // Jika body kosong {}, updateKey() mengembalikan true tanpa menyentuh DB —
  // bahkan kalau key tidak ada. Dengan pengecekan eksplisit ini, PATCH ke ID
  // yang tidak ada selalu mengembalikan 404 terlepas dari isi body.
  const existing = getKey(id);
  if (!existing) return NextResponse.json({ success: false, error: 'Key not found.' }, { status: 404 });

  const body = await request.json().catch(() => ({}));
  updateKey(id, body);
  return NextResponse.json({ success: true, key: getKey(id) });
}

export async function DELETE(request, { params }) {
  await ensureInit();
  const { keyRecord, error } = getAdminAuth(request);
  if (error) return error;

  // FIX Bug 1: await params untuk Next.js 15 compatibility
  const { id } = await params;
  if (id === keyRecord.id) {
    return NextResponse.json({ success: false, error: 'Cannot delete your own key.' }, { status: 400 });
  }
  const ok = deleteKey(id);
  if (!ok) return NextResponse.json({ success: false, error: 'Key not found.' }, { status: 404 });
  return NextResponse.json({ success: true, message: 'Key deleted.' });
}
