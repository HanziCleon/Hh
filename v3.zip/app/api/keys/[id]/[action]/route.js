export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { ensureInit } from '../../../../../src/lib/init.js';
import { getAuth, getAdminAuth } from '../../../../../src/lib/apiAuth.js';
import { revokeKey, enableKey, rotateKey, setCustomKey } from '../../../../../src/services/KeyManager.js';
import { getUserByKeyId } from '../../../../../src/services/UserService.js';
import { getActivePlan, getPlan } from '../../../../../src/services/PlanService.js';
export { OPTIONS } from '../../../../../src/lib/corsOptions.js';


export async function POST(request, { params }) {
  await ensureInit();
  // FIX: await params untuk Next.js 15 compatibility
  const { id, action } = await params;

  if (action === 'rotate') {
    const { keyRecord, error } = getAuth(request);
    if (error) return error;
    if (keyRecord.role !== 'admin' && keyRecord.id !== id) {
      return NextResponse.json({ success: false, error: 'Access denied.' }, { status: 403 });
    }
    const newRawKey = rotateKey(id);
    if (!newRawKey) return NextResponse.json({ success: false, error: 'Key not found.' }, { status: 404 });
    return NextResponse.json({ success: true, message: 'New key generated — save it now!', apiKey: newRawKey });
  }

  if (action === 'setcustom') {
    const { keyRecord, error } = getAuth(request);
    if (error) return error;
    if (keyRecord.role !== 'admin' && keyRecord.id !== id) {
      return NextResponse.json({ success: false, error: 'Access denied.' }, { status: 403 });
    }

    // Cek plan user — hanya premium/max yang boleh set custom key
    if (keyRecord.role !== 'admin') {
      const user       = getUserByKeyId(keyRecord.id);
      const activePlan = user ? getActivePlan(user) : 'free';
      const planObj    = getPlan(activePlan);
      if (!planObj?.customApiKey) {
        return NextResponse.json({
          success: false,
          error: 'Custom API Key hanya tersedia untuk plan PREMIUM dan MAX.',
        }, { status: 403 });
      }
    }

    const body = await request.json().catch(() => ({}));
    const { customKey } = body;

    if (!customKey || typeof customKey !== 'string') {
      return NextResponse.json({ success: false, error: 'customKey wajib diisi.' }, { status: 400 });
    }
    const trimmed = customKey.trim();
    if (trimmed.length < 10) {
      return NextResponse.json({ success: false, error: 'Custom key minimal 10 karakter.' }, { status: 400 });
    }
    if (trimmed.length > 128) {
      return NextResponse.json({ success: false, error: 'Custom key maksimal 128 karakter.' }, { status: 400 });
    }
    if (!/^[a-zA-Z0-9_\-\.]+$/.test(trimmed)) {
      return NextResponse.json({
        success: false,
        error: 'Custom key hanya boleh mengandung huruf, angka, underscore, dash, dan titik.',
      }, { status: 400 });
    }

    try {
      const ok = setCustomKey(id, trimmed);
      if (!ok) return NextResponse.json({ success: false, error: 'Key not found.' }, { status: 404 });
    } catch (err) {
      const status = err.status || 500;
      return NextResponse.json({ success: false, error: err.message }, { status });
    }
    return NextResponse.json({ success: true, message: 'Custom API key berhasil diset. Gunakan nilai yang kamu tulis tadi untuk autentikasi.' });
  }

  const { error } = getAdminAuth(request);
  if (error) return error;

  if (action === 'revoke') {
    const ok = revokeKey(id);
    if (!ok) return NextResponse.json({ success: false, error: 'Key not found.' }, { status: 404 });
    return NextResponse.json({ success: true, message: 'Key revoked.' });
  }

  if (action === 'enable') {
    const ok = enableKey(id);
    if (!ok) return NextResponse.json({ success: false, error: 'Key not found.' }, { status: 404 });
    return NextResponse.json({ success: true, message: 'Key enabled.' });
  }

  return NextResponse.json({ success: false, error: 'Unknown action.' }, { status: 400 });
}
