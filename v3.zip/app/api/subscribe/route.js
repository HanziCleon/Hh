export const dynamic = 'force-dynamic';
import { NextResponse }           from 'next/server';
import { ensureInit }             from '../../../src/lib/init.js';
import { getAuth }                from '../../../src/lib/apiAuth.js';
import { getUserByKeyId }         from '../../../src/services/UserService.js';
import { createOrder, getUserSubscriptions } from '../../../src/services/SubscriptionService.js';
import { getActivePlan, getPlan, getPlanDaysLeft, getAllPlans } from '../../../src/services/PlanService.js';
export { OPTIONS } from '../../../src/lib/corsOptions.js';


// POST /api/subscribe — buat order upgrade plan
export async function POST(request) {
  await ensureInit();
  const { keyRecord, error } = getAuth(request);
  if (error) return error;

  const user = getUserByKeyId(keyRecord.id);
  if (!user) return NextResponse.json({ success: false, error: 'User tidak ditemukan' }, { status: 404 });

  let body;
  try { body = await request.json(); }
  catch { return NextResponse.json({ success: false, error: 'Body JSON tidak valid' }, { status: 400 }); }

  const { plan } = body;
  // FIX BUG B: Validasi plan dinamis via getAllPlans() — mendukung plan custom dari admin.
  // Sebelumnya: hardcoded ['premium', 'max'] → plan custom tidak bisa dibeli.
  const validPlans = getAllPlans().filter(p => p.price > 0).map(p => p.id);
  if (!plan || !validPlans.includes(plan)) {
    return NextResponse.json(
      { success: false, error: `Plan tidak valid. Plan berbayar tersedia: ${validPlans.join(', ')}` },
      { status: 400 }
    );
  }

  try {
    const order = await createOrder(user, plan);
    return NextResponse.json({ success: true, order });
  } catch (e) {
    console.error('[/api/subscribe POST]', e.message);
    return NextResponse.json(
      { success: false, error: e.message || 'Gagal membuat order' },
      { status: 502 }
    );
  }
}

// GET /api/subscribe — riwayat subscription user
export async function GET(request) {
  await ensureInit();
  const { keyRecord, error } = getAuth(request);
  if (error) return error;

  const user = getUserByKeyId(keyRecord.id);
  if (!user) return NextResponse.json({ success: false, error: 'User tidak ditemukan' }, { status: 404 });

  const activePlan  = getActivePlan(user);
  const planInfo    = getPlan(activePlan);
  const daysLeft    = getPlanDaysLeft(user);
  const history     = getUserSubscriptions(user.id);

  return NextResponse.json({
    success: true,
    currentPlan: {
      id:        activePlan,
      name:      planInfo.name,
      color:     planInfo.color,
      expiry:    user.planExpiry || null,
      daysLeft,
      storage:   planInfo.storageLabel,
    },
    history,
  });
}
