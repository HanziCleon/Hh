export const dynamic = 'force-dynamic';
import { NextResponse }  from 'next/server';
import { ensureInit }    from '../../../../src/lib/init.js';
import { handleWebhook } from '../../../../src/services/SubscriptionService.js';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';


/**
 * POST /api/subscribe/webhook — Pakasir payment callback (BONUS / fast-path)
 *
 * Sistem pembayaran utama menggunakan POLLING AKTIF (di init.js) yang
 * mengecek Pakasir API setiap PAYMENT_POLL_INTERVAL_MS milidetik.
 *
 * Endpoint ini adalah fast-path opsional: jika Pakasir mengirim webhook,
 * plan langsung diaktifkan tanpa menunggu interval polling berikutnya.
 *
 * Keamanan:
 * - FIX SECURITY: Secret dibaca dari header X-Webhook-Secret (bukan query param).
 *   Query param terekspos di server log, CDN log, dan Referer header — tidak aman
 *   untuk menyimpan credential. Header HTTP tidak di-log oleh sebagian besar proxy/CDN.
 *   Sebagai fallback kompatibilitas, query param ?secret= masih diterima HANYA jika
 *   header tidak tersedia (untuk dashboard payment gateway yang tidak support custom header).
 * - Webhook tetap cross-verify ke Pakasir Transaction Detail API sebelum
 *   mengaktifkan plan (tidak langsung percaya payload webhook mentah-mentah).
 * - Jika WEBHOOK_SECRET tidak di-set, semua webhook ditolak 503.
 *
 * Cara setup:
 * 1. Set WEBHOOK_SECRET=<random-string> di .env.local
 * 2. Buka dashboard Pakasir → Edit Proyek → Webhook URL
 *    Isi: https://yourdomain.com/api/subscribe/webhook
 *    Tambahkan custom header: X-Webhook-Secret: <WEBHOOK_SECRET>
 *    (Fallback jika tidak support custom header: tambahkan ?secret=<WEBHOOK_SECRET> di URL)
 */
export async function POST(request) {
  await ensureInit();

  // ── Autentikasi webhook via X-Webhook-Secret header (atau query param sebagai fallback) ──
  const webhookSecret = process.env.WEBHOOK_SECRET;
  if (!webhookSecret) {
    // WEBHOOK_SECRET tidak di-set — tolak semua webhook untuk keamanan.
    // Set WEBHOOK_SECRET=<random-string> di .env.local lalu daftarkan di dashboard Pakasir.
    console.error('[Webhook] DITOLAK: WEBHOOK_SECRET belum dikonfigurasi. Set env var WEBHOOK_SECRET.');
    return NextResponse.json({ ok: false, msg: 'Webhook tidak dikonfigurasi di server ini.' }, { status: 503 });
  }

  const crypto = (await import('crypto')).default;

  // FIX SECURITY: Prioritaskan header X-Webhook-Secret.
  // Query param ?secret= diterima sebagai fallback kompatibilitas HANYA jika header kosong,
  // karena beberapa dashboard payment gateway tidak mendukung custom header.
  // Gunakan header jika memungkinkan — lebih aman karena tidak muncul di server log.
  const url = new URL(request.url);
  const incoming = request.headers.get('x-webhook-secret')
    || url.searchParams.get('secret')
    || '';

  const a = crypto.createHash('sha256').update(incoming).digest();
  const b = crypto.createHash('sha256').update(webhookSecret).digest();
  const isValid = crypto.timingSafeEqual(a, b);
  if (!isValid) {
    console.warn('[Webhook] Ditolak: secret tidak valid');
    return NextResponse.json({ ok: false, msg: 'Unauthorized' }, { status: 403 });
  }

  let payload;
  try {
    const ct = request.headers.get('content-type') || '';
    if (ct.includes('application/json')) {
      payload = await request.json();
    } else {
      const text = await request.text();
      payload = Object.fromEntries(new URLSearchParams(text));
    }
  } catch {
    return NextResponse.json({ ok: false, msg: 'Invalid payload' }, { status: 400 });
  }

  console.log('[Webhook] Incoming:', JSON.stringify(payload).slice(0, 200));

  try {
    // crossVerify: true → verifikasi ulang ke Pakasir API sebelum aktifkan plan
    const result = await handleWebhook(payload, { crossVerify: true });
    return NextResponse.json(result, { status: 200 });
  } catch (e) {
    console.error('[Webhook] Error:', e.message);
    return NextResponse.json({ ok: false, msg: e.message }, { status: 500 });
  }
}
