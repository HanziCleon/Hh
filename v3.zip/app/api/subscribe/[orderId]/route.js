export const dynamic = 'force-dynamic';
import { NextResponse }  from 'next/server';
import { ensureInit }    from '../../../../src/lib/init.js';
import { getAuth }       from '../../../../src/lib/apiAuth.js';
import { getUserByKeyId } from '../../../../src/services/UserService.js';
import { checkOrder }    from '../../../../src/services/SubscriptionService.js';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';


// GET /api/subscribe/[orderId] — cek status pembayaran
export async function GET(request, { params }) {
  await ensureInit();
  const { keyRecord, error } = getAuth(request);
  if (error) return error;

  const user = getUserByKeyId(keyRecord.id);
  if (!user) return NextResponse.json({ success: false, error: 'User tidak ditemukan' }, { status: 404 });

  // FIX: await params untuk Next.js 15 compatibility
  const { orderId } = await params;
  if (!orderId) return NextResponse.json({ success: false, error: 'orderId diperlukan' }, { status: 400 });

  try {
    const result = await checkOrder(orderId, user.id);

    if (!result.found) {
      return NextResponse.json({ success: false, error: 'Order tidak ditemukan' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      orderId,
      status:     result.status,
      plan:       result.plan,
      activated:  result.status === 'paid',
      planResult: result.planResult || null,
    }, {
      headers: { 'Cache-Control': 'no-store, no-cache', 'Pragma': 'no-cache' },
    });
  } catch (e) {
    console.error('[/api/subscribe/[orderId] GET]', e.message);
    return NextResponse.json(
      { success: false, error: e.message || 'Gagal cek order' },
      { status: 500 }
    );
  }
}
