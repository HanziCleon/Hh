export const dynamic = 'force-dynamic';

import path from 'path';
import { run, uploadFile, makeTmp, cleanTmp, pretty, YTDLP } from '../_lib.js';

/**
 * GET /api/tiktok/video?url=<tiktok_url>
 *
 * Downloads the TikTok video, uploads it to DongtubeDB,
 * and returns the DongtubeDB file URL.
 *
 * Optional header: X-API-Key — uses your own DongtubeDB key.
 */
export async function GET(request) {
  const tmp = await makeTmp();
  try {
    const { searchParams } = new URL(request.url);
    const url = searchParams.get('url');
    if (!url) return pretty({ status: false, error: 'Parameter "url" wajib diisi' }, 400);

    const apiKey  = request.headers.get('x-api-key') || undefined;
    const outPath = path.join(tmp, 'video.mp4');

    // Download via yt-dlp
    const cmd = `${YTDLP} -f "bv*+ba/b" --merge-output-format mp4 --no-check-certificate --geo-bypass -o "${outPath}" "${url}"`;
    await run(cmd);

    // Upload to DongtubeDB
    const filename = `tiktok_video_${Date.now()}.mp4`;
    const file     = await uploadFile(outPath, filename, 'video/mp4', apiKey);

    return pretty({
      status:   true,
      type:     'video',
      filename: file.originalName,
      size:     file.size,
      url:      file.url,
      mimeType: file.mimeType || 'video/mp4',
    });
  } catch (e) {
    return pretty({ status: false, error: e.toString() }, 500);
  } finally {
    await cleanTmp(tmp);
  }
}
