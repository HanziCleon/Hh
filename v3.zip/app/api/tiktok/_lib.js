import { exec }      from 'child_process';
import { promises as fs } from 'fs';
import path             from 'path';
import os               from 'os';

/* ─── Env config ───────────────────────────────────────────────────────────── */
export const YTDLP   = process.env.YTDLP_PATH   || './yt-dlp';
export const FFMPEG  = process.env.FFMPEG_PATH  || 'ffmpeg';
export const CHANNEL = 'https://whatsapp.com/channel/0029Vb91qeW17Emm4TVqu53K';
const SYS_KEY        = process.env.SYSTEM_API_KEY || '';
const DOMAIN         = process.env.DOMAIN || process.env.NEXT_PUBLIC_DOMAIN || 'http://localhost:3000';

/* ─── Shell runner ─────────────────────────────────────────────────────────── */
export function run(cmd, opts = {}) {
  return new Promise((resolve, reject) => {
    exec(cmd, { maxBuffer: 1024 * 1024 * 300, ...opts }, (err, stdout, stderr) => {
      if (err) return reject(stderr?.trim() || err.message);
      resolve(stdout);
    });
  });
}

/* ─── Temp directory helpers ───────────────────────────────────────────────── */
export async function makeTmp() {
  const dir = path.join(os.tmpdir(), `dtdb_${Date.now()}_${Math.random().toString(36).slice(2)}`);
  await fs.mkdir(dir, { recursive: true });
  return dir;
}

export async function cleanTmp(dir) {
  await fs.rm(dir, { recursive: true, force: true }).catch(() => {});
}

/* ─── Pretty-print JSON response (auto injects channel) ───────────────────── */
export function pretty(data, status = 200) {
  const payload = data && typeof data === 'object'
    ? { ...data, channel: CHANNEL }
    : data;
  return new Response(JSON.stringify(payload, null, 2), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
  });
}

/* ─── DongtubeDB upload helpers ────────────────────────────────────────────── */
function resolveKey(apiKey) {
  const key = apiKey || SYS_KEY;
  if (!key) throw new Error('SYSTEM_API_KEY belum dikonfigurasi di environment variables');
  return key;
}

/**
 * Fetch a remote URL and upload it directly to DongtubeDB.
 * Returns the file object from the upload response.
 */
export async function uploadUrl(remoteUrl, filename, apiKey) {
  const key = resolveKey(apiKey);

  const fetched = await fetch(remoteUrl, {
    headers: { 'User-Agent': 'Mozilla/5.0 (compatible; DongtubeBot/1.0)' },
  });
  if (!fetched.ok) throw new Error(`Gagal fetch ${remoteUrl}: HTTP ${fetched.status}`);

  const buf = await fetched.arrayBuffer();
  const ct  = fetched.headers.get('content-type') || 'application/octet-stream';

  const form = new FormData();
  form.append('file', new Blob([buf], { type: ct }), filename);
  form.append('public', 'true');

  const up = await fetch(`${DOMAIN}/api/upload`, {
    method: 'POST',
    headers: { 'X-API-Key': key },
    body: form,
  });
  const json = await up.json();
  if (!json.success) throw new Error(json.error || 'DongtubeDB upload gagal');
  return json.file;
}

/**
 * Read a local file and upload it to DongtubeDB.
 * Returns the file object from the upload response.
 */
export async function uploadFile(filePath, filename, mimeType, apiKey) {
  const key = resolveKey(apiKey);

  const buf  = await fs.readFile(filePath);
  const form = new FormData();
  form.append('file', new Blob([buf], { type: mimeType }), filename);
  form.append('public', 'true');

  const up = await fetch(`${DOMAIN}/api/upload`, {
    method: 'POST',
    headers: { 'X-API-Key': key },
    body: form,
  });
  const json = await up.json();
  if (!json.success) throw new Error(json.error || 'DongtubeDB upload gagal');
  return json.file;
}
