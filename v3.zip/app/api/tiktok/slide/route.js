export const dynamic = 'force-dynamic';

import { run, uploadUrl, pretty, YTDLP } from '../_lib.js';

/**
 * GET /api/tiktok/slide?url=<tiktok_url>
 *
 * Extracts all images from a TikTok slide post, uploads each one
 * to DongtubeDB, and returns the array of DongtubeDB URLs.
 *
 * Optional header: X-API-Key — uses your own DongtubeDB key.
 */
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const url = searchParams.get('url');
    if (!url) return pretty({ status: false, error: 'Parameter "url" wajib diisi' }, 400);

    const apiKey = request.headers.get('x-api-key') || undefined;

    // Fetch metadata via yt-dlp
    const cmd    = `${YTDLP} -j --no-check-certificate --geo-bypass "${url}"`;
    const output = await run(cmd);
    const data   = JSON.parse(output);

    // Collect raw image URLs
    let rawImages = [];
    if (data.entries && data.entries.length > 0) {
      rawImages = data.entries.map(e => e.url).filter(Boolean);
    } else if (data.thumbnails && data.thumbnails.length > 0) {
      rawImages = data.thumbnails.map(e => e.url).filter(Boolean);
    }

    if (rawImages.length === 0) {
      return pretty({ status: false, error: 'Tidak ada gambar slide yang ditemukan di URL ini' }, 404);
    }

    // Upload all images to DongtubeDB in parallel
    const ts       = Date.now();
    const results  = await Promise.allSettled(
      rawImages.map((imgUrl, i) => {
        const ext  = imgUrl.split('?')[0].split('.').pop() || 'jpg';
        const name = `slide_${i + 1}_${ts}.${ext}`;
        return uploadUrl(imgUrl, name, apiKey);
      })
    );

    const images = results.map((r, i) =>
      r.status === 'fulfilled'
        ? { index: i + 1, url: r.value.url, size: r.value.size, mimeType: r.value.mimeType }
        : { index: i + 1, url: null, error: r.reason?.message || 'Upload gagal' }
    );

    const successCount = images.filter(img => img.url).length;

    return pretty({
      status:  true,
      type:    'slide',
      title:   data.title || null,
      total:   images.length,
      success: successCount,
      images,
    });
  } catch (e) {
    return pretty({ status: false, error: e.toString() }, 500);
  }
}
