export const dynamic = 'force-dynamic';

import path from 'path';
import { run, uploadFile, makeTmp, cleanTmp, pretty, YTDLP, FFMPEG } from '../_lib.js';

/**
 * GET /api/tiktok/audio?url=<tiktok_url>
 *
 * Downloads the TikTok video, extracts audio via ffmpeg (192k MP3),
 * uploads it to DongtubeDB, and returns the DongtubeDB file URL.
 *
 * Optional header: X-API-Key — uses your own DongtubeDB key.
 */
export async function GET(request) {
  const tmp = await makeTmp();
  try {
    const { searchParams } = new URL(request.url);
    const url = searchParams.get('url');
    if (!url) return pretty({ status: false, error: 'Parameter "url" wajib diisi' }, 400);

    const apiKey    = request.headers.get('x-api-key') || undefined;
    const videoPath = path.join(tmp, 'video.mp4');
    const audioPath = path.join(tmp, 'audio.mp3');

    // Step 1: download video
    const dlCmd = `${YTDLP} -f "bv*+ba/b" --merge-output-format mp4 --no-check-certificate --geo-bypass -o "${videoPath}" "${url}"`;
    await run(dlCmd);

    // Step 2: extract audio via ffmpeg
    const ffCmd = `${FFMPEG} -i "${videoPath}" -vn -ab 192k -ar 44100 -y "${audioPath}"`;
    await run(ffCmd);

    // Step 3: upload to DongtubeDB
    const filename = `tiktok_audio_${Date.now()}.mp3`;
    const file     = await uploadFile(audioPath, filename, 'audio/mpeg', apiKey);

    return pretty({
      status:   true,
      type:     'audio',
      filename: file.originalName,
      size:     file.size,
      url:      file.url,
      mimeType: file.mimeType || 'audio/mpeg',
      bitrate:  '192k',
    });
  } catch (e) {
    return pretty({ status: false, error: e.toString() }, 500);
  } finally {
    await cleanTmp(tmp);
  }
}
