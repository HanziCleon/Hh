export const dynamic = 'force-dynamic';

import path from 'path';
import { run, uploadUrl, uploadFile, makeTmp, cleanTmp, pretty, YTDLP, FFMPEG } from './_lib.js';

function getPublicOrigin(request) {
  const envDomain = process.env.DOMAIN || process.env.NEXT_PUBLIC_DOMAIN;
  if (envDomain) return envDomain.replace(/\/$/, '');
  const host  = request.headers.get('x-forwarded-host') || request.headers.get('host');
  const proto = request.headers.get('x-forwarded-proto') || 'https';
  if (host) return `${proto}://${host}`;
  return new URL(request.url).origin;
}

/**
 * GET /api/tiktok?url=<tiktok_url>
 *
 * Auto download + upload semua ke DongtubeDB dalam satu request:
 * - Video  → upload → return url
 * - Audio  → extract via ffmpeg → upload → return url
 * - Slide  → upload semua gambar → return array url
 * - Thumbnail → upload → return url
 */
export async function GET(request) {
  const tmp = await makeTmp();
  try {
    const { searchParams } = new URL(request.url);
    const url = searchParams.get('url');
    if (!url) return pretty({ status: false, error: 'Parameter "url" wajib diisi' }, 400);

    const apiKey = request.headers.get('x-api-key') || undefined;

    // ── Ambil metadata ──────────────────────────────────────────────────────
    const metaOut = await run(`${YTDLP} -j --no-check-certificate --geo-bypass "${url}"`);
    const data    = JSON.parse(metaOut);
    const isSlide = Boolean(data.entries && data.entries.length > 0);

    // ── Upload thumbnail ────────────────────────────────────────────────────
    let thumbnailUrl = data.thumbnail || null;
    if (thumbnailUrl) {
      try {
        const ext  = thumbnailUrl.split('?')[0].split('.').pop() || 'jpg';
        const file = await uploadUrl(thumbnailUrl, `thumb_${Date.now()}.${ext}`, apiKey);
        thumbnailUrl = file.url;
      } catch { /* tetap pakai url asli */ }
    }

    // ── SLIDE ───────────────────────────────────────────────────────────────
    if (isSlide) {
      let rawImages = data.entries.map(e => e.url).filter(Boolean);
      if (rawImages.length === 0 && data.thumbnails) {
        rawImages = data.thumbnails.map(e => e.url).filter(Boolean);
      }

      const ts      = Date.now();
      const results = await Promise.allSettled(
        rawImages.map((imgUrl, i) => {
          const ext  = imgUrl.split('?')[0].split('.').pop() || 'jpg';
          return uploadUrl(imgUrl, `slide_${i + 1}_${ts}.${ext}`, apiKey);
        })
      );

      const images = results.map((r, i) =>
        r.status === 'fulfilled'
          ? { index: i + 1, url: r.value.url, size: r.value.size, mimeType: r.value.mimeType }
          : { index: i + 1, url: null, error: r.reason?.message || 'Upload gagal' }
      );

      return pretty({
        status:    true,
        type:      'slide',
        title:     data.title    || null,
        duration:  null,
        uploader:  data.uploader || data.creator || data.channel || null,
        thumbnail: thumbnailUrl,
        total:     images.length,
        success:   images.filter(i => i.url).length,
        images,
      });
    }

    // ── VIDEO + AUDIO ───────────────────────────────────────────────────────
    const videoPath = path.join(tmp, 'video.mp4');
    const audioPath = path.join(tmp, 'audio.mp3');

    // Download video
    await run(
      `${YTDLP} -f "bv*+ba/b" --merge-output-format mp4 ` +
      `--no-check-certificate --geo-bypass -o "${videoPath}" "${url}"`
    );

    // Extract audio via ffmpeg
    await run(`${FFMPEG} -i "${videoPath}" -vn -ab 192k -ar 44100 -y "${audioPath}"`);

    const ts = Date.now();

    // Upload video dan audio paralel
    const [videoFile, audioFile] = await Promise.all([
      uploadFile(videoPath, `tiktok_video_${ts}.mp4`, 'video/mp4',   apiKey),
      uploadFile(audioPath, `tiktok_audio_${ts}.mp3`, 'audio/mpeg',  apiKey),
    ]);

    return pretty({
      status:    true,
      type:      'video',
      title:     data.title    || null,
      duration:  data.duration || null,
      uploader:  data.uploader || data.creator || data.channel || null,
      thumbnail: thumbnailUrl,
      video: {
        url:      videoFile.url,
        filename: videoFile.originalName,
        size:     videoFile.size,
        mimeType: 'video/mp4',
      },
      audio: {
        url:      audioFile.url,
        filename: audioFile.originalName,
        size:     audioFile.size,
        mimeType: 'audio/mpeg',
        bitrate:  '192k',
      },
    });

  } catch (e) {
    return pretty({ status: false, error: e.toString() }, 500);
  } finally {
    await cleanTmp(tmp);
  }
}
