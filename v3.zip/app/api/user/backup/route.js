/**
 * User Self-Service Backup & Restore
 *
 * GET  /api/user/backup          → download backup data milik user sendiri
 * POST /api/user/backup          → restore/import data milik user sendiri
 * GET  /api/user/backup?info=1   → info saja (tidak download), untuk preview
 *
 * Auth: API Key via header x-api-key atau Bearer token
 *
 * Scope backup user:
 *   - API Keys milik user ini (berdasarkan apiKeyId)
 *   - File records milik user ini
 *   - KV keys dengan prefix "user:{apiKeyId}:"
 *
 * User TIDAK bisa backup data user lain atau tabel sistem.
 *
 * FIXES v2:
 *  FIX-1: kvListAll() return Array<{key,sha}>, BUKAN object.
 *          - Build: Object.entries(kvEntries) sebelumnya → [['0',{key,sha}],...] → SALAH
 *            Fix: langsung map array → { key, value: kvRead(key).data }
 *          - Restore replace: Object.keys(existing) → ['0','1',...] → delete tidak hapus apapun
 *            Fix: for (const entry of existing) kvDelete(entry.key)
 */

export const dynamic = 'force-dynamic';
// export const maxDuration = 60; // Vercel-only: comment out untuk self-hosted

import { NextResponse } from 'next/server';
import { existsSync }   from 'fs';
import { ensureInit }   from '../../../../src/lib/init.js';
import { getAuth }      from '../../../../src/lib/apiAuth.js';
import { listFiles }    from '../../../../src/services/DatabaseService.js';
import { listKeys }     from '../../../../src/services/KeyManager.js';
import { kvListAll, kvRead, kvWrite, kvDelete } from '../../../../src/services/KVService.js';
import { getFilePath }  from '../../../../src/services/StorageService.js';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';


// ─── GET: Download backup ─────────────────────────────────────────────────────

export async function GET(request) {
  await ensureInit();           // FIX #1: harus sebelum getAuth() — DB wajib siap dulu
  const auth = getAuth(request);
  if (auth.error) return auth.error;

  const { keyRecord } = auth;
  const url  = new URL(request.url);
  const info = url.searchParams.get('info') === '1';

  try {
    const backup = _buildUserBackup(keyRecord);

    if (info) {
      return NextResponse.json({
        success:    true,
        apiKeyId:   keyRecord.id,
        exportedAt: backup.meta.exportedAt,
        stats: {
          files:   backup.files.length,
          apiKeys: backup.apiKeys.length,
          kvKeys:  backup.kv.length,
        },
      });
    }

    const ts       = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const filename = `dongtube-user-backup-${ts}.json`;
    const body     = JSON.stringify(backup, null, 2);

    return new Response(body, {
      status: 200,
      headers: {
        'Content-Type':        'application/json; charset=utf-8',
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Content-Length':      Buffer.byteLength(body, 'utf8').toString(),
      },
    });
  } catch (err) {
    return NextResponse.json(
      { success: false, error: err.message },
      { status: 500 }
    );
  }
}

// ─── POST: Restore backup ─────────────────────────────────────────────────────

export async function POST(request) {
  await ensureInit();           // FIX #1: harus sebelum getAuth() — DB wajib siap dulu
  const auth = getAuth(request);
  if (auth.error) return auth.error;

  const { keyRecord } = auth;

  let body;
  try {
    const text = await request.text();
    body = JSON.parse(text);
  } catch (e) {
    return NextResponse.json(
      { success: false, error: `JSON tidak valid: ${e.message}` },
      { status: 400 }
    );
  }

  const { data, mode = 'merge' } = body;

  if (!data || typeof data !== 'object') {
    return NextResponse.json(
      { success: false, error: 'Field "data" diperlukan (isi file backup)' },
      { status: 400 }
    );
  }

  if (!['replace', 'merge'].includes(mode)) {
    return NextResponse.json(
      { success: false, error: 'mode harus: replace | merge' },
      { status: 400 }
    );
  }

  try {
    const result = await _restoreUserBackup(keyRecord, data, mode);
    return NextResponse.json({ success: true, mode, result });
  } catch (err) {
    return NextResponse.json(
      { success: false, error: err.message },
      { status: 500 }
    );
  }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function _buildUserBackup(keyRecord) {
  const apiKeyId = keyRecord.id;

  // BUG-1 FIX: gunakan noLimit:true agar semua file diambil, bukan max 200
  const { items: files } = listFiles({ apiKeyId, noLimit: true });

  // API Keys milik user ini
  const allKeys  = listKeys();
  const userKeys = allKeys.filter(k =>
    k.id === apiKeyId ||
    (keyRecord.userId && k.userId === keyRecord.userId)
  );

  // BUG-2 FIX: prefix harus sama dengan yang ditulis KV API: "u:{keyId}/"
  // bukan "user:{apiKeyId}:" — keduanya tidak pernah cocok sebelumnya.
  const kvPrefix  = `u:${apiKeyId}/`;
  const kvEntries = kvListAll(kvPrefix); // Array<{key, sha, updatedAt}>

  return {
    meta: {
      version:    '2.0',
      exportedAt: new Date().toISOString(),
      apiKeyId,
      generator:  'DongtubeDB user-backup',
    },
    files,
    apiKeys: userKeys.map(k => ({
      ...k,
      key: undefined, // jangan simpan raw key di backup
    })),
    // FIX-1: iterate array langsung, baca value via kvRead
    kv: kvEntries.map(entry => ({
      key:   entry.key,
      value: kvRead(entry.key).data,
    })),
  };
}

async function _restoreUserBackup(keyRecord, data, mode) {
  const apiKeyId = keyRecord.id;

  // Validasi: backup harus milik user ini
  if (data.meta?.apiKeyId && data.meta.apiKeyId !== apiKeyId) {
    throw new Error('Backup ini bukan milik API key Anda');
  }

  const result = { files: 0, kv: 0 };

  // ── Restore files ──────────────────────────────────────────────────────────
  if (Array.isArray(data.files)) {
    const safeFiles = data.files.map(f => ({ ...f, apiKeyId })); // paksa apiKeyId

    // FIX: Hanya restore record yang file fisiknya ada di disk.
    // Tanpa pengecekan ini, restore bisa menghasilkan "ghost record" — ada di DB
    // tapi file tidak ada di disk, sehingga GET /api/files/:id akan 404.
    const verifiedFiles = safeFiles.filter(f => {
      if (!f.storedName || !f.category) return false;
      try {
        return existsSync(getFilePath(f.category, f.storedName));
      } catch (_) {
        return false;
      }
    });
    const skippedCount = safeFiles.length - verifiedFiles.length;
    if (skippedCount > 0) {
      console.warn(`[backup/restore] ${skippedCount} file record dilewati karena file fisik tidak ada di disk.`);
    }

    // FIX #4: Gunakan q()/qSelect() — bukan akses langsung db.tables / db._load / db._saveSync
    if (mode === 'replace') {
      // Hapus semua file milik user ini, lalu insert ulang dari backup
      const { q: _q, qSelect: _qSelect, esc: _esc } = await import('../../../../src/lib/dongtube.js');
      _q(`DELETE FROM files WHERE apiKeyId = ${_esc(apiKeyId)}`);
      for (const f of verifiedFiles) {
        try {
          const tags     = JSON.stringify(Array.isArray(f.tags)     ? f.tags     : []);
          const metadata = JSON.stringify(f.metadata && typeof f.metadata === 'object' ? f.metadata : {});
          _q(`INSERT INTO files
                (id, originalName, storedName, category, mimeType, size,
                 apiKeyId, owner, uploadedAt, downloads, lastAccessed,
                 public, tags, metadata)
              VALUES
                (${_esc(f.id)}, ${_esc(f.originalName)}, ${_esc(f.storedName)},
                 ${_esc(f.category)}, ${_esc(f.mimeType)}, ${_esc(Number(f.size)||0)},
                 ${_esc(apiKeyId)}, ${_esc(f.owner)}, ${_esc(f.uploadedAt)},
                 ${_esc(Number(f.downloads)||0)}, ${_esc(f.lastAccessed||null)},
                 ${f.public ? 1 : 0}, ${_esc(tags)}, ${_esc(metadata)})`);
        } catch (_) {} // Skip record yang gagal — jangan abort seluruh restore
      }
    } else {
      // Merge: hanya insert file yang belum ada (berdasarkan id)
      const { q: _q, qSelect: _qSelect, esc: _esc } = await import('../../../../src/lib/dongtube.js');
      const existingRows = _qSelect(`SELECT id FROM files WHERE apiKeyId = ${_esc(apiKeyId)}`);
      const existingIds  = new Set(existingRows.map(r => r.id));
      for (const f of verifiedFiles) {
        if (!f.id || existingIds.has(f.id)) continue;
        try {
          const tags     = JSON.stringify(Array.isArray(f.tags)     ? f.tags     : []);
          const metadata = JSON.stringify(f.metadata && typeof f.metadata === 'object' ? f.metadata : {});
          _q(`INSERT INTO files
                (id, originalName, storedName, category, mimeType, size,
                 apiKeyId, owner, uploadedAt, downloads, lastAccessed,
                 public, tags, metadata)
              VALUES
                (${_esc(f.id)}, ${_esc(f.originalName)}, ${_esc(f.storedName)},
                 ${_esc(f.category)}, ${_esc(f.mimeType)}, ${_esc(Number(f.size)||0)},
                 ${_esc(apiKeyId)}, ${_esc(f.owner)}, ${_esc(f.uploadedAt)},
                 ${_esc(Number(f.downloads)||0)}, ${_esc(f.lastAccessed||null)},
                 ${f.public ? 1 : 0}, ${_esc(tags)}, ${_esc(metadata)})`);
        } catch (_) {} // Skip record yang gagal
      }
    }
        result.files = verifiedFiles.length;
  }

  // ── Restore KV ────────────────────────────────────────────────────────────
  if (Array.isArray(data.kv)) {
    // FIX #2 (backup): prefix harus cocok dengan yang ditulis KV API: "u:{keyId}/"
    const kvPrefix = `u:${apiKeyId}/`;

    if (mode === 'replace') {
      // FIX-1: kvListAll() return Array — iterate array, bukan Object.keys()
      const existing = kvListAll(kvPrefix); // Array<{key, sha, updatedAt}>
      for (const entry of existing) {
        try { kvDelete(entry.key); } catch (_) {}
      }
    }

    // BUG FIX — merge mode: bangun set key yang sudah ada SEBELUM mulai write.
    // Sebelumnya kvWrite() dipanggil tanpa pengecekan untuk kedua mode — artinya
    // merge mode tetap menimpa (overwrite) key yang sudah ada, bertentangan dengan
    // semantik merge (hanya tambah yang belum ada).
    const existingKvKeys = mode === 'merge'
      ? new Set(kvListAll(kvPrefix).map(e => e.key))
      : null; // replace mode: set null → tidak perlu cek

    for (const entry of data.kv) {
      const key = entry?.key;
      if (typeof key === 'string' && key.startsWith(kvPrefix)) {
        // Merge: skip key yang sudah ada (jangan timpa data aktif)
        if (existingKvKeys && existingKvKeys.has(key)) continue;
        try {
          kvWrite(key, entry.value);
          result.kv++;
        } catch (_) {} // Skip jika gagal — jangan abort seluruh restore
      }
    }
  }

  return result;
}
