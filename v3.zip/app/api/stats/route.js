export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { ensureInit } from '../../../src/lib/init.js';
import { getAuth } from '../../../src/lib/apiAuth.js';
import { getOwnerStats } from '../../../src/services/DatabaseService.js';
import { formatBytes } from '../../../src/services/StorageService.js';
export { OPTIONS } from '../../../src/lib/corsOptions.js';


export async function GET(request) {
  await ensureInit();
  const { keyRecord, error } = getAuth(request);
  if (error) return error;

  const stats = getOwnerStats(keyRecord.id);
  return NextResponse.json({
    success: true,
    owner: keyRecord.label,
    totalFiles: stats.totalFiles,
    totalSize: stats.totalSize,
    totalSizeHuman: formatBytes(stats.totalSize),
    totalDownloads: stats.totalDownloads,
    byCategory: stats.byCategory,
    maxStorage: keyRecord.maxStorage,
    maxStorageHuman: keyRecord.maxStorage ? formatBytes(keyRecord.maxStorage) : 'unlimited',
  });
}
