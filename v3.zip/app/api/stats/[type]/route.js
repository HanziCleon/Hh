export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { ensureInit } from '../../../../src/lib/init.js';
import { getAdminAuth } from '../../../../src/lib/apiAuth.js';
import { getGlobalStats } from '../../../../src/services/DatabaseService.js';
import { getStorageStats, formatBytes } from '../../../../src/services/StorageService.js';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';


export async function GET(request, { params }) {
  await ensureInit();
  const { error } = getAdminAuth(request);
  if (error) return error;

  // FIX: await params untuk Next.js 15 compatibility
  const { type } = await params;

  if (type === 'global') {
    const stats = getGlobalStats();
    return NextResponse.json({
      success: true,
      totalFiles: stats.totalFiles,
      totalSize: stats.totalSize,
      totalSizeHuman: formatBytes(stats.totalSize),
      totalDownloads: stats.totalDownloads,
      byCategory: stats.byCategory,
      uptime: Math.floor(process.uptime()),
      memoryMB: (process.memoryUsage().rss / 1024 / 1024).toFixed(1),
    });
  }

  if (type === 'storage') {
    const diskStats = getStorageStats();
    const formatted = {};
    for (const [cat, data] of Object.entries(diskStats.categories)) {
      formatted[cat] = { files: data.files, size: formatBytes(data.size) };
    }
    return NextResponse.json({ success: true, totalFiles: diskStats.totalFiles, totalSize: formatBytes(diskStats.totalSize), categories: formatted });
  }

  return NextResponse.json({ success: false, error: 'Unknown stats type.' }, { status: 404 });
}
