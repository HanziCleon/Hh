export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { ensureInit } from '../../../src/lib/init.js';
export { OPTIONS } from '../../../src/lib/corsOptions.js';


export async function GET() {
  await ensureInit();
  return NextResponse.json({
    status: 'ok', name: 'DongtubeDB', version: '3.0.0',
    uptime: Math.floor(process.uptime()),
    timestamp: new Date().toISOString(),
    features: { googleAuth: !!process.env.GOOGLE_CLIENT_ID, fileStorage: true, kvStore: true },
  });
}
