export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../src/lib/corsOptions.js';
import { NextResponse } from 'next/server';
import { ensureInit }   from '../../../src/lib/init.js';
import { getAllPlans }  from '../../../src/services/PlanService.js';

export async function GET() {
  // ensureInit() memastikan direktori data sudah ada dan PlanService sudah diinisialisasi
  // sebelum _loadPlansConfig() mencoba membaca plans-config.json dari DATA_DIR.
  await ensureInit();

  const plans = getAllPlans().map(p => ({
    id:           p.id,
    name:         p.name,
    storageLabel: p.storageLabel,
    storageBytes: p.storageBytes,
    price:        p.price,
    priceLabel:   p.priceLabel,
    color:        p.color,
    customApiKey: p.customApiKey,
    features:     p.features,
  }));

  return NextResponse.json({ success: true, plans });
}
