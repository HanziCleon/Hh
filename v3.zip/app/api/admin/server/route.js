export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';
import { NextResponse } from 'next/server';
import { requireAdmin } from '../../../../src/lib/adminAuth.js';
import { ensureInit }   from '../../../../src/lib/init.js';
import os from 'os';

function getServerHealth() {
  const mem    = process.memoryUsage();
  const uptime = process.uptime();

  const cpus    = os.cpus();
  const loadAvg = os.loadavg();

  return {
    uptime:     Math.floor(uptime),
    pid:        process.pid,
    nodeVersion: process.version,
    platform:   process.platform,
    arch:       process.arch,
    env:        process.env.NODE_ENV || 'production',
    memory: {
      heapUsed:  mem.heapUsed,
      heapTotal: mem.heapTotal,
      rss:       mem.rss,
      external:  mem.external,
      heapPercent: Math.round((mem.heapUsed / mem.heapTotal) * 100),
    },
    os: {
      totalMem:  os.totalmem(),
      freeMem:   os.freemem(),
      usedMem:   os.totalmem() - os.freemem(),
      memPercent: Math.round(((os.totalmem() - os.freemem()) / os.totalmem()) * 100),
      cpuCount:  cpus.length,
      cpuModel:  cpus[0]?.model || 'Unknown',
      loadAvg1:  loadAvg[0],
      loadAvg5:  loadAvg[1],
      loadAvg15: loadAvg[2],
      hostname:  os.hostname(),
      type:      os.type(),
    },
    startedAt: new Date(Date.now() - uptime * 1000).toISOString(),
    checkedAt: new Date().toISOString(),
  };
}

/**
 * GET /api/admin/server
 * Ambil info health server lengkap.
 */
export async function GET(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  return NextResponse.json({ success: true, health: getServerHealth() });
}

/**
 * POST /api/admin/server
 * Action: { action: 'restart' | 'flush' | 'gc' }
 *
 * restart — flush semua DB lalu keluar (PM2/nodemon akan restart otomatis)
 * flush   — paksa simpan semua tabel sekarang tanpa restart
 * gc      — paksa garbage collection (hanya kalau --expose-gc aktif)
 */
export async function POST(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  const body = await request.json().catch(() => ({}));
  const { action } = body;

  if (action === 'flush') {
    try {
      const { getDB, getUserDB } = await import('../../../../src/lib/dongtube.js');
      const db    = getDB();
      const users = getUserDB();
      const n1 = db.saveAll();
      const n2 = users.saveAll();
      return NextResponse.json({
        success: true,
        message: `Flush selesai — ${n1 + n2} tabel tersimpan.`,
        tables:  n1 + n2,
      });
    } catch (err) {
      return NextResponse.json({ success: false, error: err.message }, { status: 500 });
    }
  }

  if (action === 'gc') {
    if (typeof global.gc === 'function') {
      global.gc();
      return NextResponse.json({ success: true, message: 'Garbage collection selesai.', memory: process.memoryUsage() });
    }
    return NextResponse.json({
      success: false,
      error: 'GC tidak tersedia. Jalankan Node.js dengan flag --expose-gc.',
    }, { status: 400 });
  }

  if (action === 'restart') {
    // Flush semua data terlebih dahulu sebelum restart
    try {
      const { getDB, getUserDB } = await import('../../../../src/lib/dongtube.js');
      const db    = getDB();
      const users = getUserDB();
      db.saveAll();
      users.saveAll();
    } catch (_) {}

    // Kirim response dulu, baru restart setelah 600ms
    const response = NextResponse.json({
      success: true,
      message: 'Server akan restart dalam beberapa saat. Semua data sudah di-flush.',
    });

    setTimeout(() => {
      console.log('[admin/server] Restart dipicu oleh admin.');
      process.exit(0); // PM2/nodemon akan restart otomatis
    }, 600);

    return response;
  }

  return NextResponse.json({ success: false, error: 'action tidak valid. Pilih: restart | flush | gc' }, { status: 400 });
}
