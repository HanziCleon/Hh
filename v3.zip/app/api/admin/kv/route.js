export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';
import { NextResponse } from 'next/server';
import { requireAdmin } from '../../../../src/lib/adminAuth.js';
import { ensureInit }   from '../../../../src/lib/init.js';
import { kvRead, kvWrite, kvDelete, kvListAll } from '../../../../src/services/KVService.js';

export async function GET(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  const url    = new URL(request.url);
  const prefix = url.searchParams.get('prefix') || '';
  const key    = url.searchParams.get('key');

  // Baca satu key
  if (key) {
    const { data, sha } = kvRead(key);
    if (data === null) return NextResponse.json({ success: false, error: 'Key tidak ditemukan' }, { status: 404 });
    return NextResponse.json({ success: true, key, data, sha });
  }

  // List semua key (dengan optional prefix filter)
  const entries = kvListAll(prefix);
  return NextResponse.json({ success: true, data: entries, total: entries.length });
}

export async function PUT(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  const body = await request.json().catch(() => null);
  if (!body?.key) return NextResponse.json({ success: false, error: 'key diperlukan' }, { status: 400 });

  try {
    const sha = kvWrite(body.key, body.value, body.sha ?? null);
    return NextResponse.json({ success: true, key: body.key, sha });
  } catch (err) {
    if (err.status === 409) return NextResponse.json({ success: false, error: err.message }, { status: 409 });
    return NextResponse.json({ success: false, error: 'Write gagal' }, { status: 500 });
  }
}

export async function DELETE(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  const url = new URL(request.url);
  const key = url.searchParams.get('key');
  if (!key) return NextResponse.json({ success: false, error: 'key diperlukan' }, { status: 400 });

  const deleted = kvDelete(key);
  return NextResponse.json({ success: true, deleted });
}
