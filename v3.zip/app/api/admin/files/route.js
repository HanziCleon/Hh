export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';
import { NextResponse } from 'next/server';
import { requireAdmin } from '../../../../src/lib/adminAuth.js';
import { ensureInit }   from '../../../../src/lib/init.js';
import { listFiles }    from '../../../../src/services/DatabaseService.js';

const DOMAIN = process.env.DOMAIN || process.env.NEXT_PUBLIC_DOMAIN || '';

function withUrls(record) {
  return {
    ...record,
    fileUrl:  `${DOMAIN}/api/files/${record.id}`,  // record.id sudah include ekstensi
  };
}

export async function GET(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  const url    = new URL(request.url);
  const page   = parseInt(url.searchParams.get('page')  || '1');
  const limit  = parseInt(url.searchParams.get('limit') || '50');
  const search = url.searchParams.get('search') || undefined;

  const result = listFiles({ page, limit, search });
  // listFiles selalu return { total, page, limit, pages, items } — tidak pernah array
  return NextResponse.json({
    success: true,
    data: { ...result, items: result.items.map(withUrls) },
  });
}
