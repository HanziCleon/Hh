export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../../src/lib/corsOptions.js';
import { NextResponse }  from 'next/server';
import { requireAdmin }  from '../../../../../src/lib/adminAuth.js';
import { ensureInit }    from '../../../../../src/lib/init.js';
import { getFile, deleteRecord, updateFile } from '../../../../../src/services/DatabaseService.js';
import { deleteFile }    from '../../../../../src/services/StorageService.js';

const DOMAIN = process.env.DOMAIN || process.env.NEXT_PUBLIC_DOMAIN || '';

function withUrls(record) {
  if (!record) return record;
  return {
    ...record,
    fileUrl:  `${DOMAIN}/api/files/${record.id}`,
  };
}

export async function GET(request, { params }) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  // FIX Bug 1: await params untuk Next.js 15 compatibility
  const { id } = await params;
  const record = getFile(id);
  if (!record) return NextResponse.json({ success: false, error: 'File tidak ditemukan' }, { status: 404 });
  return NextResponse.json({ success: true, data: withUrls(record) });
}

export async function PATCH(request, { params }) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  // FIX Bug 1: await params untuk Next.js 15 compatibility
  const { id } = await params;
  const record = getFile(id);
  if (!record) return NextResponse.json({ success: false, error: 'File tidak ditemukan' }, { status: 404 });

  const body    = await request.json().catch(() => ({}));
  const updates = {};
  for (const k of ['public', 'tags', 'metadata', 'originalName']) {
    if (body[k] !== undefined) updates[k] = body[k];
  }

  // FIX #7: Sanitasi originalName agar konsisten dengan logika upload.
  if (updates.originalName !== undefined) {
    updates.originalName = String(updates.originalName)
      .replace(/[^a-zA-Z0-9._\-() ]/g, '_')
      .substring(0, 255);
  }

  updateFile(id, updates);
  return NextResponse.json({ success: true, data: withUrls(getFile(id)) });
}

export async function DELETE(request, { params }) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  // FIX Bug 1: await params untuk Next.js 15 compatibility
  const { id } = await params;
  const record = getFile(id);
  if (!record) return NextResponse.json({ success: false, error: 'File tidak ditemukan' }, { status: 404 });

  try { deleteFile(record.category, record.storedName); } catch (_) {}
  deleteRecord(id);
  return NextResponse.json({ success: true, message: `File ${id} berhasil dihapus` });
}
