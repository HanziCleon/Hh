export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';
import { NextResponse } from 'next/server';
import { requireAdmin } from '../../../../src/lib/adminAuth.js';
import { ensureInit }   from '../../../../src/lib/init.js';
import { DATA_ROOT }    from '../../../../src/lib/dongtube.js';
import { STORAGE_ROOT } from '../../../../src/services/StorageService.js';
import fs   from 'fs';
import path from 'path';

// Root yang bisa diakses admin: data/ dan storage/
const ALLOWED_ROOTS = {
  data:    DATA_ROOT,
  storage: STORAGE_ROOT,
};

/** Resolve dan validasi path — harus di dalam allowed roots */
function safePath(root, rel) {
  const base    = ALLOWED_ROOTS[root];
  if (!base) return null;
  const resolved = path.resolve(base, rel || '');
  // Cegah path traversal
  if (!resolved.startsWith(path.resolve(base))) return null;
  return resolved;
}

function formatBytes(b) {
  const u = ['B', 'KB', 'MB', 'GB'];
  let i = 0, v = b;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(1)} ${u[i]}`;
}

// GET /api/admin/fs?root=data&path=db  → list direktori atau baca file
export async function GET(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  const url     = new URL(request.url);
  const root    = url.searchParams.get('root') || 'data';
  const rel     = url.searchParams.get('path') || '';
  const action  = url.searchParams.get('action');   // read | stat

  const fullPath = safePath(root, rel);
  if (!fullPath) return NextResponse.json({ success: false, error: 'Path tidak diizinkan' }, { status: 403 });

  if (!fs.existsSync(fullPath)) {
    return NextResponse.json({ success: false, error: 'Path tidak ditemukan' }, { status: 404 });
  }

  const stat = fs.statSync(fullPath);

  // Baca isi file
  if (stat.isFile() && action === 'read') {
    const content = fs.readFileSync(fullPath, 'utf8');
    return NextResponse.json({ success: true, path: rel, content, size: stat.size });
  }

  // Stat satu file / folder
  if (action === 'stat') {
    return NextResponse.json({ success: true, stat: {
      path: rel, isDir: stat.isDirectory(), size: stat.size,
      formattedSize: formatBytes(stat.size),
      modifiedAt: stat.mtime.toISOString(), createdAt: stat.birthtime.toISOString(),
    }});
  }

  // List direktori
  if (stat.isDirectory()) {
    const entries = fs.readdirSync(fullPath).map(name => {
      const ep = path.join(fullPath, name);
      const es = fs.statSync(ep);
      return {
        name,
        path: path.join(rel, name).replace(/\\/g, '/'),
        isDir: es.isDirectory(),
        size: es.size,
        formattedSize: formatBytes(es.size),
        modifiedAt: es.mtime.toISOString(),
      };
    }).sort((a, b) => (b.isDir - a.isDir) || a.name.localeCompare(b.name));

    return NextResponse.json({
      success: true, root, path: rel,
      entries, total: entries.length,
      allowedRoots: Object.keys(ALLOWED_ROOTS),
    });
  }

  // File tanpa action read → kembalikan stat saja
  return NextResponse.json({ success: true, stat: {
    path: rel, isDir: false, size: stat.size,
    formattedSize: formatBytes(stat.size),
    modifiedAt: stat.mtime.toISOString(),
  }});
}

// POST /api/admin/fs  → buat folder atau tulis file
// body: { root, path, type: 'dir'|'file', content? }
export async function POST(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit(); // FIX: DATA_ROOT dan STORAGE_ROOT harus siap sebelum akses filesystem

  const body = await request.json().catch(() => null);
  if (!body?.root || !body?.path) {
    return NextResponse.json({ success: false, error: 'root dan path diperlukan' }, { status: 400 });
  }

  const fullPath = safePath(body.root, body.path);
  if (!fullPath) return NextResponse.json({ success: false, error: 'Path tidak diizinkan' }, { status: 403 });

  try {
    if (body.type === 'dir') {
      fs.mkdirSync(fullPath, { recursive: true });
      return NextResponse.json({ success: true, message: `Folder dibuat: ${body.path}` });
    } else {
      fs.mkdirSync(path.dirname(fullPath), { recursive: true });
      fs.writeFileSync(fullPath, body.content || '', 'utf8');
      return NextResponse.json({ success: true, message: `File ditulis: ${body.path}`, size: Buffer.byteLength(body.content || '') });
    }
  } catch (err) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

// PUT /api/admin/fs  → update (overwrite) isi file
export async function PUT(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit(); // FIX: pastikan paths diinisialisasi sebelum write

  const body = await request.json().catch(() => null);
  if (!body?.root || !body?.path || body.content === undefined) {
    return NextResponse.json({ success: false, error: 'root, path, dan content diperlukan' }, { status: 400 });
  }

  const fullPath = safePath(body.root, body.path);
  if (!fullPath) return NextResponse.json({ success: false, error: 'Path tidak diizinkan' }, { status: 403 });

  try {
    const tmp = fullPath + '.tmp';
    fs.writeFileSync(tmp, body.content, 'utf8');
    fs.renameSync(tmp, fullPath);
    return NextResponse.json({ success: true, message: `File disimpan: ${body.path}`, size: Buffer.byteLength(body.content) });
  } catch (err) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

// DELETE /api/admin/fs?root=data&path=db/test.json  → hapus file/folder
export async function DELETE(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit(); // FIX: pastikan ALLOWED_ROOTS terisi sebelum resolve path

  const url  = new URL(request.url);
  const root = url.searchParams.get('root') || 'data';
  const rel  = url.searchParams.get('path');

  if (!rel) return NextResponse.json({ success: false, error: 'path diperlukan' }, { status: 400 });

  const fullPath = safePath(root, rel);
  if (!fullPath) return NextResponse.json({ success: false, error: 'Path tidak diizinkan' }, { status: 403 });

  // Guard: cegah hapus root direktori itu sendiri
  const base = ALLOWED_ROOTS[root];
  if (base && path.resolve(fullPath) === path.resolve(base)) {
    return NextResponse.json({ success: false, error: 'Tidak dapat menghapus direktori root' }, { status: 403 });
  }

  if (!fs.existsSync(fullPath)) return NextResponse.json({ success: false, error: 'Tidak ditemukan' }, { status: 404 });

  try {
    const stat = fs.statSync(fullPath);
    if (stat.isDirectory()) {
      fs.rmSync(fullPath, { recursive: true });
    } else {
      fs.unlinkSync(fullPath);
    }
    return NextResponse.json({ success: true, message: `${rel} berhasil dihapus` });
  } catch (err) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
