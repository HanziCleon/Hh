export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';
import { NextResponse }  from 'next/server';
import { requireAdmin }  from '../../../../src/lib/adminAuth.js';
import { ensureInit }    from '../../../../src/lib/init.js';
import { getSubscriptionsByStatus } from '../../../../src/services/SubscriptionService.js';

// GET /api/admin/subscriptions?status=all|pending|paid|expired
export async function GET(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  const { searchParams } = new URL(request.url);
  const status = searchParams.get('status') || 'all';
  const limit  = parseInt(searchParams.get('limit') || '200');

  const rows = getSubscriptionsByStatus(status, limit);
  return NextResponse.json({
    success: true,
    total: rows.length,
    subscriptions: rows,
  }, { headers: { 'Cache-Control': 'no-store' } });
}
