export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../../src/lib/corsOptions.js';
import { NextResponse }  from 'next/server';
import { requireAdmin }  from '../../../../../src/lib/adminAuth.js';
import { ensureInit }    from '../../../../../src/lib/init.js';
import { adminConfirmOrder } from '../../../../../src/services/SubscriptionService.js';

// POST /api/admin/subscriptions/[orderId] — konfirmasi manual pembayaran
export async function POST(request, { params }) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  // FIX: await params untuk Next.js 15 compatibility
  const { orderId } = await params;
  const adminId = guard.adminId || 'admin';

  const result = adminConfirmOrder(orderId, adminId);
  if (!result.ok) {
    return NextResponse.json({ success: false, error: result.msg }, { status: 400 });
  }

  return NextResponse.json({
    success: true,
    message: result.msg,
    planResult: result.planResult,
    order: result.order,
  }, { headers: { 'Cache-Control': 'no-store' } });
}
