/**
 * POST /api/admin/db/import
 *
 * Body (JSON):
 *   {
 *     data: { ... }    // isi file export (objek dengan meta + db/users)
 *     mode: 'replace'  // 'replace' (default) atau 'merge'
 *     scope: 'all'     // 'all' | 'db' | 'users' — batasi scope yang diimport
 *   }
 *
 * Admin-only. Tidak ada batas ukuran — stream parsing.
 *
 * mode 'replace': isi tabel DIGANTI sepenuhnya
 * mode 'merge':   row baru DITAMBAHKAN, row dengan id yang sama di-skip
 */

export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../../src/lib/corsOptions.js';
// export const maxDuration = 60; // seconds // Vercel-only: comment out untuk self-hosted

// fetchCache: nonaktifkan cache fetch() internal di dalam route ini.
// Catatan: ini TIDAK berkaitan dengan body size limit.
// Di Next.js App Router dengan nodejs runtime, tidak ada body size limit bawaan
// untuk route handlers — limit dihandle secara eksplisit di kode (MAX_IMPORT_BYTES di bawah).

import { NextResponse } from 'next/server';
import { requireAdmin } from '../../../../../src/lib/adminAuth.js';
import { ensureInit }   from '../../../../../src/lib/init.js';
import { getDB, getUserDB } from '../../../../../src/lib/dongtube.js';

export async function POST(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  let body;
  try {
    // Baca body sebagai text dulu (menghindari next.js body limit default)
    // FIX: Batasi ukuran import agar tidak bisa mem-flood RAM server.
    // Admin seharusnya tidak perlu import lebih dari 500 MB sekaligus.
    const MAX_IMPORT_BYTES = 500 * 1024 * 1024; // 500 MB
    const text = await request.text();
    if (Buffer.byteLength(text, 'utf8') > MAX_IMPORT_BYTES) {
      return NextResponse.json(
        { success: false, error: 'File import terlalu besar (maks 500 MB). Gunakan mode merge bertahap.' },
        { status: 413 }
      );
    }
    body = JSON.parse(text);
  } catch (e) {
    return NextResponse.json(
      { success: false, error: `JSON tidak valid: ${e.message}` },
      { status: 400 }
    );
  }

  const { data, mode = 'replace', scope = 'all' } = body;

  if (!data || typeof data !== 'object') {
    return NextResponse.json(
      { success: false, error: 'Field "data" diperlukan (isi file backup)' },
      { status: 400 }
    );
  }

  if (!['replace', 'merge'].includes(mode)) {
    return NextResponse.json(
      { success: false, error: 'mode harus: replace | merge' },
      { status: 400 }
    );
  }

  if (!['all', 'db', 'users'].includes(scope)) {
    return NextResponse.json(
      { success: false, error: 'scope harus: all | db | users' },
      { status: 400 }
    );
  }

  try {
    // Support 2 format: { meta, db, users } atau { tableName: [...rows] }
    let dbPayload    = null;
    let usersPayload = null;

    if (data.meta && (data.db || data.users)) {
      // Format baru (v2): hasil dari endpoint export
      dbPayload    = data.db    || null;
      usersPayload = data.users || null;
    } else {
      // Format lama / raw: semua tabel masuk ke db
      dbPayload = data;
    }

    const results = { db: null, users: null };

    if ((scope === 'all' || scope === 'db') && dbPayload) {
      results.db = getDB().importData(dbPayload, mode);
    }

    if ((scope === 'all' || scope === 'users') && usersPayload) {
      results.users = getUserDB().importData(usersPayload, mode);
    }

    const totalImported = [
      ...(results.db?.imported    || []),
      ...(results.users?.imported || []),
    ].length;
    const totalSkipped = [
      ...(results.db?.skipped    || []),
      ...(results.users?.skipped || []),
    ].length;

    console.log(`[import]  Import selesai: mode=${mode} scope=${scope} imported=${totalImported} skipped=${totalSkipped}`);

    return NextResponse.json({
      success:  true,
      mode,
      scope,
      results,
      summary: { totalImported, totalSkipped },
    });
  } catch (err) {
    console.error('[import] Error:', err.message);
    return NextResponse.json(
      { success: false, error: err.message },
      { status: 500 }
    );
  }
}
