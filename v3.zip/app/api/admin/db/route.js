export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';
import { NextResponse } from 'next/server';
import { requireAdmin } from '../../../../src/lib/adminAuth.js';
import { ensureInit }   from '../../../../src/lib/init.js';
import { getDB, getUserDB, DB_DIR, USERS_DIR } from '../../../../src/lib/dongtube.js';
import fs   from 'fs';
import path from 'path';

/** Ambil store yang tepat berdasarkan nama tabel */
function getStore(table) {
  const userTables = ['users'];
  return userTables.includes(table) ? getUserDB() : getDB();
}

/** List semua file .json yang ada di kedua direktori */
function listAllTables() {
  const tables = [];
  for (const [dir, location] of [[DB_DIR, 'db'], [USERS_DIR, 'users']]) {
    if (!fs.existsSync(dir)) continue;
    for (const f of fs.readdirSync(dir)) {
      // BUG-3 FIX: '.json.tmp' berakhiran '.json' di beberapa kondisi edge-case
      // (misal rename parsial). Filter eksplisit agar tidak muncul di UI admin.
      if (f.endsWith('.json') && !f.endsWith('.json.tmp') && f !== 'backup.json') {
        const name = f.replace(/\.json$/, '');
        const stat = fs.statSync(path.join(dir, f));
        tables.push({
          name, location,
          filePath: path.join(dir, f),
          size: stat.size,
          modifiedAt: stat.mtime.toISOString(),
        });
      }
    }
  }
  return tables;
}

// GET /api/admin/db  → list semua tabel
// GET /api/admin/db?table=xxx  → baca isi tabel
export async function GET(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  const url   = new URL(request.url);
  const table = url.searchParams.get('table');

  if (!table) {
    return NextResponse.json({ success: true, data: listAllTables() });
  }

  // Validasi nama tabel (alphanumeric + underscore saja)
  if (!/^\w+$/.test(table)) {
    return NextResponse.json({ success: false, error: 'Nama tabel tidak valid' }, { status: 400 });
  }

  try {
    const store = getStore(table);
    const rows  = store.getTableData(table);
    return NextResponse.json({ success: true, table, data: rows, total: rows.length });
  } catch (err) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

// PUT /api/admin/db  → replace seluruh isi tabel
// body: { table: string, data: object[] }
export async function PUT(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  const body = await request.json().catch(() => null);
  if (!body?.table || !Array.isArray(body.data)) {
    return NextResponse.json({ success: false, error: 'table dan data (array) diperlukan' }, { status: 400 });
  }

  if (!/^\w+$/.test(body.table)) {
    return NextResponse.json({ success: false, error: 'Nama tabel tidak valid' }, { status: 400 });
  }

  try {
    const store = getStore(body.table);
    store.setTableData(body.table, body.data);
    return NextResponse.json({ success: true, table: body.table, total: body.data.length });
  } catch (err) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}

// DELETE /api/admin/db?table=xxx  → kosongkan tabel
export async function DELETE(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  const url   = new URL(request.url);
  const table = url.searchParams.get('table');
  if (!table || !/^\w+$/.test(table)) {
    return NextResponse.json({ success: false, error: 'table diperlukan' }, { status: 400 });
  }

  try {
    const store = getStore(table);
    store.setTableData(table, []);
    return NextResponse.json({ success: true, message: `Tabel ${table} dikosongkan` });
  } catch (err) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
