/**
 * GET /api/admin/db/export
 *
 * Query params:
 *   scope = all | db | users   (default: all)
 *   pretty = 1                 (indent JSON, default: minified)
 *
 * Response: application/json file download
 * Admin-only. Tidak ada batas ukuran.
 */

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';
// BUG-6 FIX: Timeout handling untuk operasi export yang bisa lama
// Set ke 60 detik (cukup untuk database biasa, bisa disesuaikan)
// export const maxDuration = 60; // Vercel-only: comment out untuk self-hosted
export { OPTIONS } from '../../../../../src/lib/corsOptions.js';
import { NextResponse } from 'next/server';
import { requireAdmin } from '../../../../../src/lib/adminAuth.js';
import { ensureInit }   from '../../../../../src/lib/init.js';
import { getDB, getUserDB } from '../../../../../src/lib/dongtube.js';

export async function GET(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  const url    = new URL(request.url);
  const scope  = url.searchParams.get('scope') || 'all';
  const pretty = url.searchParams.get('pretty') === '1';

  if (!['all', 'db', 'users'].includes(scope)) {
    return NextResponse.json(
      { success: false, error: 'scope harus: all | db | users' },
      { status: 400 }
    );
  }

  try {
    const payload = {
      meta: {
        version:    '2.0',
        exportedAt: new Date().toISOString(),
        scope,
        generator:  'DongtubeDB',
      },
    };

    if (scope === 'all' || scope === 'db') {
      payload.db = getDB().exportData();
    }

    if (scope === 'all' || scope === 'users') {
      payload.users = getUserDB().exportData();
    }

    // Hitung total rows untuk info
    let totalRows = 0;
    for (const section of ['db', 'users']) {
      if (payload[section]) {
        for (const rows of Object.values(payload[section])) {
          totalRows += Array.isArray(rows) ? rows.length : 0;
        }
      }
    }
    payload.meta.totalRows = totalRows;

    const ts       = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const filename = `dongtube-backup-${scope}-${ts}.json`;
    const body     = pretty
      ? JSON.stringify(payload, null, 2)
      : JSON.stringify(payload);

    return new Response(body, {
      status: 200,
      headers: {
        'Content-Type':        'application/json; charset=utf-8',
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Content-Length':      Buffer.byteLength(body, 'utf8').toString(),
        'X-Export-Scope':      scope,
        'X-Export-Rows':       totalRows.toString(),
      },
    });
  } catch (err) {
    // BUG-6 FIX: Tangkap timeout errors secara khusus
    const isTimeout = err.message?.includes('timeout') || err.code === 'ETIMEDOUT';
    console.error('[export] Error:', err.message);
    return NextResponse.json(
      {
        success: false,
        error: isTimeout
          ? 'Export timeout — database terlalu besar. Coba dengan scope lebih kecil.'
          : err.message
      },
      { status: isTimeout ? 504 : 500 }
    );
  }
}
