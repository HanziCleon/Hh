export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';
import { NextResponse } from 'next/server';
import { requireAdmin } from '../../../../src/lib/adminAuth.js';
import { ensureInit }   from '../../../../src/lib/init.js';
import { listUsers }    from '../../../../src/services/UserService.js';
import { getKey }       from '../../../../src/services/KeyManager.js';

export async function GET(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  const users = listUsers().map(u => ({
    ...u,
    keyInfo: u.keyId ? getKey(u.keyId) : null,
  }));

  return NextResponse.json({ success: true, data: users });
}
