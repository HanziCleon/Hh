export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../../../src/lib/corsOptions.js';
import { NextResponse }   from 'next/server';
import { requireAdmin }   from '../../../../../../src/lib/adminAuth.js';
import { ensureInit }     from '../../../../../../src/lib/init.js';
import { getUserById }    from '../../../../../../src/services/UserService.js';
import { adminSetPlan, getActivePlan, getPlan, getAllPlans } from '../../../../../../src/services/PlanService.js';

/**
 * POST /api/admin/users/[id]/plan
 *
 * Body:
 *   plan       : 'free' | 'premium' | 'max'
 *   expiresAt  : ISO string atau null (null = tidak ada expiry)
 *   durationDays: angka hari (alternatif dari expiresAt)
 *
 * Admin bisa:
 *   - Naikkan plan user secara manual (gratis, tanpa payment)
 *   - Turunkan plan ke FREE
 *   - Set custom expiry
 *   - Grant plan selamanya (expiresAt: null)
 */
export async function POST(request, { params }) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  // FIX: await params untuk Next.js 15 compatibility
  const { id } = await params;
  const user = getUserById(id);
  if (!user) return NextResponse.json({ success: false, error: 'User tidak ditemukan' }, { status: 404 });

  let body;
  try { body = await request.json(); }
  catch { return NextResponse.json({ success: false, error: 'Body JSON tidak valid' }, { status: 400 }); }

  const { plan, expiresAt, durationDays } = body;

  // FIX BUG 5: getPlan() baca dari plans-config.json — plan custom dari admin dikenali
  const allPlans = getAllPlans();
  const planObj  = getPlan(plan);
  if (!plan || !planObj?.id) {
    return NextResponse.json(
      { success: false, error: `Plan tidak valid. Pilih: ${allPlans.map(p => p.id).join(', ')}` },
      { status: 400 }
    );
  }

  // Hitung expiresAt dari durationDays kalau tidak ada expiresAt eksplisit
  let finalExpiry = expiresAt || null;
  if (!finalExpiry && durationDays && plan !== 'free') {
    const d = new Date();
    d.setDate(d.getDate() + parseInt(durationDays));
    finalExpiry = d.toISOString();
  }

  // Admin ID dari guard
  const adminId = guard.adminId || 'admin';

  const result = adminSetPlan(id, plan, finalExpiry, adminId);
  const updatedUser = getUserById(id);

  console.log(`[Admin] Plan user ${user.email} diubah ke '${plan}' oleh admin:${adminId}`);

  return NextResponse.json({
    success: true,
    message: `Plan ${user.email} berhasil diubah ke ${planObj.name}`,
    data: {
      userId:     id,
      email:      user.email,
      plan:       result.plan,
      expiresAt:  result.expiresAt,
      activePlan: getActivePlan(updatedUser),
    },
  });
}

// GET /api/admin/users/[id]/plan — lihat plan aktif user
export async function GET(request, { params }) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  // FIX: await params untuk Next.js 15 compatibility
  const { id } = await params;
  const user = getUserById(id);
  if (!user) return NextResponse.json({ success: false, error: 'User tidak ditemukan' }, { status: 404 });

  const activePlan = getActivePlan(user);
  return NextResponse.json({
    success: true,
    data: {
      userId:     id,
      email:      user.email,
      plan:       user.plan || 'free',
      activePlan,
      planInfo:   getPlan(activePlan),
      planExpiry: user.planExpiry || null,
      planActivatedAt: user.planActivatedAt || null,
      planGrantedBy:   user.planGrantedBy || null,
    },
  });
}
