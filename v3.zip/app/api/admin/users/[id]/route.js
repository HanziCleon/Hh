export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../../src/lib/corsOptions.js';
import { NextResponse } from 'next/server';
import { requireAdmin } from '../../../../../src/lib/adminAuth.js';
import { ensureInit }   from '../../../../../src/lib/init.js';
import { getUserById, deleteUser } from '../../../../../src/services/UserService.js';
import { getKey, updateKey }       from '../../../../../src/services/KeyManager.js';
import { q, esc }                  from '../../../../../src/lib/dongtube.js'; // BUG-FIX: q harus static import; qSelect dihapus (tidak dipakai langsung)
import { getActivePlan, adminSetPlan, getPlanDaysLeft, getPlan, getAllPlans } from '../../../../../src/services/PlanService.js';
import { getOwnerStats }           from '../../../../../src/services/DatabaseService.js';
import { formatBytes }             from '../../../../../src/services/StorageService.js';

export async function GET(request, { params }) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  // FIX: await params untuk Next.js 15 compatibility
  const { id } = await params;
  const user = getUserById(id);
  if (!user) return NextResponse.json({ success: false, error: 'User tidak ditemukan' }, { status: 404 });

  const keyInfo    = user.keyId ? getKey(user.keyId) : null;
  const activePlan = getActivePlan(user);
  const stats      = user.keyId ? getOwnerStats(user.keyId) : null;

  return NextResponse.json({
    success: true,
    data: {
      ...user,
      keyInfo,
      activePlan,
      planDaysLeft: getPlanDaysLeft(user),
      planInfo:     getPlan(activePlan),
      stats: stats ? {
        totalFiles: stats.totalFiles,
        totalSize:  stats.totalSize,
        totalSizeHuman: formatBytes(stats.totalSize),
      } : null,
    },
  });
}

export async function PUT(request, { params }) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  // FIX: await params untuk Next.js 15 compatibility
  const { id } = await params;
  const user = getUserById(id);
  if (!user) return NextResponse.json({ success: false, error: 'User tidak ditemukan' }, { status: 404 });

  const body = await request.json().catch(() => ({}));

  // ── Update field dasar user ─────────────────────────────────────────────────
  // BUG-FIX: q sekarang dipakai dari static import di atas (bukan dynamic import lagi)
  const allowed = ['name', 'email', 'picture'];
  const sets    = [];
  for (const k of allowed) {
    if (body[k] !== undefined) sets.push(`${k} = ${esc(body[k])}`);
  }
  if (sets.length > 0) {
    q(`UPDATE users SET ${sets.join(', ')} WHERE id = ${esc(id)}`);
  }

  // ── Plan manual override oleh admin ────────────────────────────────────────
  if (body.plan !== undefined) {
    const planId   = body.plan;
    const expiry   = body.planExpiry || null; // ISO string atau null
    // FIX BUG 5: getPlan() baca dari plans-config.json — plan custom dari admin dikenali
    if (!getPlan(planId)?.id) {
      return NextResponse.json({ success: false, error: `Plan '${planId}' tidak valid` }, { status: 400 });
    }
    const adminId = guard.adminId || 'admin';
    adminSetPlan(id, planId, expiry, adminId);
  }

  // ── Update key settings ────────────────────────────────────────────────────
  if (user.keyId && (body.rateLimit !== undefined || body.role !== undefined || body.enabled !== undefined)) {
    updateKey(user.keyId, {
      rateLimit: body.rateLimit,
      role:      body.role,
      enabled:   body.enabled,
    });
  }

  const updated = getUserById(id);
  return NextResponse.json({
    success: true,
    data: {
      ...updated,
      activePlan: getActivePlan(updated),
    },
  });
}

export async function DELETE(request, { params }) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  // FIX: await params untuk Next.js 15 compatibility
  const { id } = await params;
  const ok = deleteUser(id);
  if (!ok) return NextResponse.json({ success: false, error: 'User tidak ditemukan' }, { status: 404 });
  return NextResponse.json({ success: true, message: `User ${id} berhasil dihapus` });
}
