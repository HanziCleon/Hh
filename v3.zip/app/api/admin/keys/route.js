export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';
import { NextResponse } from 'next/server';
import { requireAdmin } from '../../../../src/lib/adminAuth.js';
import { ensureInit }   from '../../../../src/lib/init.js';
import { listKeys, createKey } from '../../../../src/services/KeyManager.js';

export async function GET(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();
  return NextResponse.json({ success: true, data: listKeys() });
}

export async function POST(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  // FIX BUG-3: request.json() tanpa try/catch → crash 500 saat body malformed.
  // Semua route lain sudah pakai .catch() atau try/catch, route ini terlewat.
  let body;
  try { body = await request.json(); }
  catch { return NextResponse.json({ success: false, error: 'Body JSON tidak valid' }, { status: 400 }); }
  if (!body.label) return NextResponse.json({ success: false, error: 'label diperlukan' }, { status: 400 });

  const { record, rawKey } = createKey({
    label:      body.label,
    role:       body.role || 'user',
    maxStorage: body.maxStorage || 0,
    rateLimit:  body.rateLimit  || 60,
  });

  return NextResponse.json({ success: true, data: record, rawKey });
}
