export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../../src/lib/corsOptions.js';
import { NextResponse } from 'next/server';
import { requireAdmin } from '../../../../../src/lib/adminAuth.js';
import { ensureInit }   from '../../../../../src/lib/init.js';
import {
  getKey, updateKey, revokeKey, enableKey, deleteKey, rotateKey
} from '../../../../../src/services/KeyManager.js';

export async function GET(request, { params }) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  // FIX: await params untuk Next.js 15 compatibility
  const { id } = await params;
  const key = getKey(id);
  if (!key) return NextResponse.json({ success: false, error: 'Key tidak ditemukan' }, { status: 404 });
  return NextResponse.json({ success: true, data: key });
}

export async function PUT(request, { params }) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  // FIX: await params untuk Next.js 15 compatibility
  const { id } = await params;

  // FIX BUG-4a: cek eksistensi key SEBELUM parse body.
  // Sebelumnya action enable/disable/rotate langsung dijalankan tanpa cek,
  // return { success: true, data: null } yang menyesatkan jika key tidak ada.
  const existingKey = getKey(id);
  if (!existingKey) return NextResponse.json({ success: false, error: 'Key tidak ditemukan' }, { status: 404 });

  // FIX BUG-4b: tambah try/catch untuk request.json() → 400 bukan 500 saat body malformed
  let body;
  try { body = await request.json(); }
  catch { return NextResponse.json({ success: false, error: 'Body JSON tidak valid' }, { status: 400 }); }
  const action = body.action; // enable | disable | rotate

  if (action === 'enable')  { enableKey(id);  return NextResponse.json({ success: true, data: getKey(id) }); }
  if (action === 'disable') { revokeKey(id);  return NextResponse.json({ success: true, data: getKey(id) }); }
  if (action === 'rotate')  {
    const rawKey = rotateKey(id);
    return NextResponse.json({ success: true, data: getKey(id), rawKey });
  }

  // Normal update
  updateKey(id, body);
  return NextResponse.json({ success: true, data: getKey(id) });
}

export async function DELETE(request, { params }) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  // FIX: await params untuk Next.js 15 compatibility
  const { id } = await params;
  const ok = deleteKey(id);
  if (!ok) return NextResponse.json({ success: false, error: 'Key tidak ditemukan' }, { status: 404 });
  return NextResponse.json({ success: true, message: `Key ${id} dihapus` });
}
