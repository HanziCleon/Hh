export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';
import { NextResponse } from 'next/server';
import { requireAdmin } from '../../../../src/lib/adminAuth.js';
import { ensureInit }   from '../../../../src/lib/init.js';
import crypto from 'crypto';
import fs   from 'fs';
import path from 'path';

const DATA_DIR      = process.env.DATA_DIR || './data';
const SETTINGS_PATH = path.join(DATA_DIR, 'admin-settings.json');

// ─── FIX BUG #4: Enkripsi secrets sebelum simpan ke disk ─────────────────────
//
// Sebelumnya: adminSecret, pakasirApiKey, googleClientSecret disimpan plaintext
// di admin-settings.json → bisa dibaca proses lain, ikut ter-backup, atau
// ter-ekspos via /api/admin/fs.
//
// Solusi: enkripsi dengan AES-256-GCM menggunakan SETTINGS_ENCRYPTION_KEY dari env.
// Jika key tidak di-set → field sensitif TIDAK disimpan ke disk sama sekali
// (hanya env var yang berlaku). Ini behavior aman by default.
//
// Setup: tambahkan SETTINGS_ENCRYPTION_KEY=<hex-64-char> di .env.local
// Generate: node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
//
// Field yang dienkripsi: pakasirApiKey, googleClientId, googleClientSecret, adminSecret
// Field yang TIDAK dienkripsi (bukan credentials): domain, debug, maxFileSizeMB, dll.

const SENSITIVE_FIELDS = new Set(['pakasirApiKey', 'googleClientId', 'googleClientSecret', 'adminSecret']);
const ENC_PREFIX = 'enc:v1:'; // marker agar bisa detect field yang sudah terenkripsi

function _getEncKey() {
  const hex = process.env.SETTINGS_ENCRYPTION_KEY;
  if (!hex || hex.length < 64) return null;
  return Buffer.from(hex.slice(0, 64), 'hex');
}

function _encrypt(plaintext) {
  const key = _getEncKey();
  if (!key) return null; // tidak bisa enkripsi → jangan simpan
  const iv  = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const enc  = Buffer.concat([cipher.update(String(plaintext), 'utf8'), cipher.final()]);
  const tag  = cipher.getAuthTag();
  return ENC_PREFIX + Buffer.concat([iv, tag, enc]).toString('base64');
}

function _decrypt(ciphertext) {
  if (!ciphertext || !ciphertext.startsWith(ENC_PREFIX)) return null;
  const key = _getEncKey();
  if (!key) return null;
  try {
    const buf    = Buffer.from(ciphertext.slice(ENC_PREFIX.length), 'base64');
    const iv     = buf.subarray(0, 12);
    const tag    = buf.subarray(12, 28);
    const enc    = buf.subarray(28);
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
    decipher.setAuthTag(tag);
    return decipher.update(enc) + decipher.final('utf8');
  } catch {
    return null; // korup atau key salah
  }
}

// Baca overrides dari disk, dekripsi field sensitif
function _loadOverrides() {
  try {
    const raw = JSON.parse(fs.readFileSync(SETTINGS_PATH, 'utf-8'));
    const out  = { ...raw };
    for (const k of SENSITIVE_FIELDS) {
      if (out[k]) {
        const dec = _decrypt(out[k]);
        out[k] = dec; // null jika gagal dekripsi
      }
    }
    return out;
  } catch {
    return {};
  }
}

// Field yang aman untuk dibaca/ditulis (tidak ekspos credentials sensitif secara penuh)
function readSettings() {
  const overrides = _loadOverrides();

  return {
    // ── Server ────────────────────────────────────────────────────────────
    domain:         overrides.domain        ?? process.env.DOMAIN            ?? '',
    nodeEnv:        process.env.NODE_ENV    ?? 'production',
    debug:          overrides.debug         ?? (process.env.DEBUG === 'true'),

    // ── Storage ───────────────────────────────────────────────────────────
    dataDir:        process.env.DATA_DIR    ?? './data',
    storageDir:     process.env.STORAGE_DIR ?? './storage',
    logDir:         process.env.LOG_DIR     ?? './logs',
    maxFileSizeMB:  overrides.maxFileSizeMB ?? parseInt(process.env.MAX_FILE_SIZE_MB ?? '500'),

    // ── Plan Storage Limits (bytes) ────────────────────────────────────────
    freeStorageBytes:    overrides.freeStorageBytes    ?? parseInt(process.env.FREE_STORAGE_BYTES    ?? '10485760'),
    premiumStorageBytes: overrides.premiumStorageBytes ?? parseInt(process.env.PREMIUM_STORAGE_BYTES ?? '524288000'),
    maxStorageBytes:     overrides.maxStorageBytes     ?? parseInt(process.env.MAX_STORAGE_BYTES     ?? '1073741824'),

    // ── Rate Limits (req/menit) ────────────────────────────────────────────
    // FIX #2: Fallback wajib identik dengan PlanService.js (100/1000/5000).
    // Sebelumnya 10000/50000/1000000 — admin panel menampilkan nilai 100x lebih besar
    // dari yang benar-benar di-enforce, menyesatkan konfigurasi.
    freeRateLimit:    overrides.freeRateLimit    ?? parseInt(process.env.FREE_RATE_LIMIT    ?? '100'),
    premiumRateLimit: overrides.premiumRateLimit ?? parseInt(process.env.PREMIUM_RATE_LIMIT ?? '1000'),
    maxRateLimit:     overrides.maxRateLimit     ?? parseInt(process.env.MAX_RATE_LIMIT     ?? '5000'),

    // ── Payment ────────────────────────────────────────────────────────────
    pakasirSlug:      overrides.pakasirSlug ?? process.env.PAKASIR_SLUG   ?? '',
    // Secrets: TIDAK dikembalikan sebagai plaintext — hanya flag apakah sudah di-set
    pakasirApiKeySet: !!(overrides.pakasirApiKey ?? process.env.PAKASIR_APIKEY),
    orderTtlMin:      overrides.orderTtlMin  ?? parseInt(process.env.ORDER_TTL_MIN ?? '15'),

    // ── Google OAuth — HANYA flag, nilai asli tidak pernah dikembalikan ───
    googleClientIdSet:     !!(overrides.googleClientId     ?? process.env.GOOGLE_CLIENT_ID),
    googleClientSecretSet: !!(overrides.googleClientSecret ?? process.env.GOOGLE_CLIENT_SECRET),

    // ── Admin ──────────────────────────────────────────────────────────────
    adminSecretSet: !!(overrides.adminSecret ?? process.env.ADMIN_SECRET),

    // ── Info enkripsi ──────────────────────────────────────────────────────
    encryptionEnabled: !!_getEncKey(),

    updatedAt: overrides.updatedAt ?? null,
  };
}

// BUG-4 FIX: Gunakan atomic write (tmp → rename) untuk mencegah korupsi file
// jika proses crash di tengah penulisan settings.
function atomicWriteJSON(filePath, data) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const tmp = filePath + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf-8');
  fs.renameSync(tmp, filePath);
}

function writeSettings(updates) {
  let existing = {};
  try { existing = JSON.parse(fs.readFileSync(SETTINGS_PATH, 'utf-8')); } catch {}

  const allowedNonSensitive = [
    'domain', 'debug', 'maxFileSizeMB',
    'freeStorageBytes', 'premiumStorageBytes', 'maxStorageBytes',
    'freeRateLimit',    'premiumRateLimit',    'maxRateLimit',
    'pakasirSlug', 'orderTtlMin',
  ];
  const allowedSensitive = [...SENSITIVE_FIELDS];

  const merged = { ...existing };

  // BUG-8 FIX: Type coercion untuk numeric dan boolean fields
  const numericFields = new Set([
    'maxFileSizeMB', 'freeStorageBytes', 'premiumStorageBytes', 'maxStorageBytes',
    'freeRateLimit', 'premiumRateLimit', 'maxRateLimit', 'orderTtlMin'
  ]);
  const booleanFields = new Set(['debug']);

  // Non-sensitive: simpan dengan type coercion
  for (const k of allowedNonSensitive) {
    if (updates[k] !== undefined && updates[k] !== '') {
      let value = updates[k];

      // Type coercion berdasarkan field type
      if (numericFields.has(k)) {
        const num = Number(value);
        if (!isNaN(num) && num >= 0) {
          merged[k] = num;
        } else {
          console.warn(`[settings] ⚠️  Field '${k}' harus numeric, skip: ${value}`);
        }
      } else if (booleanFields.has(k)) {
        merged[k] = value === true || value === 'true' || value === '1';
      } else {
        merged[k] = String(value).trim();
      }
    }
  }

  // FIX BUG #4: Sensitive fields — enkripsi sebelum simpan ke disk.
  // Jika SETTINGS_ENCRYPTION_KEY tidak di-set → _encrypt() return null
  // → field tidak disimpan (hanya env var yang berlaku, lebih aman).
  for (const k of allowedSensitive) {
    if (updates[k] !== undefined && updates[k] !== '') {
      const encrypted = _encrypt(updates[k]);
      if (encrypted) {
        merged[k] = encrypted; // simpan ciphertext
      } else {
        // Enkripsi key tidak tersedia — jangan simpan plaintext, log peringatan
        console.warn(
          `[settings] ⚠️  SETTINGS_ENCRYPTION_KEY tidak dikonfigurasi. ` +
          `Field '${k}' TIDAK disimpan ke disk untuk keamanan. ` +
          `Tambahkan SETTINGS_ENCRYPTION_KEY di .env.local agar field ini bisa disimpan secara enkripsi.`
        );
        // Hapus dari merged jika sebelumnya ada (legacy plaintext)
        delete merged[k];
      }
    }
  }

  merged.updatedAt = new Date().toISOString();

  atomicWriteJSON(SETTINGS_PATH, merged);
  return merged;
}

// ─── GET /api/admin/settings ──────────────────────────────────────────────────
export async function GET(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  return NextResponse.json({ success: true, settings: readSettings() });
}

// ─── PUT /api/admin/settings ──────────────────────────────────────────────────
export async function PUT(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  const body = await request.json().catch(() => ({}));

  // Validasi tipe data
  const intFields = [
    'maxFileSizeMB', 'freeStorageBytes', 'premiumStorageBytes', 'maxStorageBytes',
    'freeRateLimit', 'premiumRateLimit', 'maxRateLimit', 'orderTtlMin',
  ];
  for (const k of intFields) {
    if (body[k] !== undefined) {
      const n = parseInt(body[k]);
      if (isNaN(n) || n < 0) {
        return NextResponse.json({ success: false, error: `${k} harus berupa angka positif` }, { status: 400 });
      }
      body[k] = n;
    }
  }

  writeSettings(body);

  return NextResponse.json({
    success: true,
    settings: readSettings(),
    message: 'Pengaturan berhasil disimpan. Beberapa perubahan (rate limit, storage) memerlukan restart server agar aktif di semua layanan.',
  });
}
