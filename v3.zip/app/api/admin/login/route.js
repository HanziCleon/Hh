export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';
import { NextResponse } from 'next/server';
import {
  createSession,
  destroySession,
  getSessionToken,
  checkAdminSecret,
  checkBruteForce,
  resetBruteForce,
} from '../../../../src/lib/adminAuth.js';

function getClientIp(request) {
  // BUG-IP-FIX: Implementasi lama mengambil IP paling KANAN dari X-Forwarded-For,
  // yang merupakan IP proxy terakhir (nginx/LB Anda sendiri) — bukan IP client.
  // Akibatnya brute-force counter menghitung per-proxy, bukan per-user.
  //
  // Perbaikan: gunakan TRUSTED_PROXY_COUNT (env var) untuk menentukan berapa
  // proxy yang trusted (default: 1). IP client yang sesungguhnya adalah IP
  // tepat di sebelah kiri proxy-proxy trusted tersebut.
  //
  // Contoh dengan TRUSTED_PROXY_COUNT=1 (1 nginx trusted):
  //   X-Forwarded-For: 1.2.3.4, 10.0.0.1
  //                    ^client   ^nginx (trusted)
  //   → ambil 1.2.3.4 (index ips.length - 1 - 1 = 0)
  //
  // Contoh dengan TRUSTED_PROXY_COUNT=2 (CDN + nginx):
  //   X-Forwarded-For: 1.2.3.4, 5.6.7.8, 10.0.0.1
  //                    ^client   ^CDN      ^nginx
  //   → ambil 1.2.3.4 (index ips.length - 1 - 2 = 0)
  //
  // Konfigurasi: tambahkan TRUSTED_PROXY_COUNT=<angka> di .env.local
  // Default 1 (cocok untuk setup dengan satu reverse proxy seperti nginx/Caddy).
  // Jika server langsung ke internet tanpa proxy: set TRUSTED_PROXY_COUNT=0.
  const xff = request.headers.get('x-forwarded-for');
  if (xff) {
    const ips     = xff.split(',').map(s => s.trim()).filter(Boolean);
    const trusted = Math.max(0, parseInt(process.env.TRUSTED_PROXY_COUNT || '1') || 1);
    const idx     = Math.max(0, ips.length - 1 - trusted);
    return ips[idx] || 'unknown';
  }
  return request.headers.get('x-real-ip') || 'unknown';
}

export async function POST(request) {
  const ip = getClientIp(request);

  // FIX: Brute force protection
  const bf = checkBruteForce(ip);
  if (bf.blocked) {
    return NextResponse.json(
      { success: false, error: `Terlalu banyak percobaan. Coba lagi dalam ${bf.retryAfterSec} detik.` },
      { status: 429, headers: { 'Retry-After': String(bf.retryAfterSec) } }
    );
  }

  let body;
  try {
    body = await request.json();
  } catch {
    // Percobaan dengan body malformed tetap terhitung — counter sudah dinaikkan
    // oleh checkBruteForce() di atas sebelum sampai ke sini.
    // Jangan reset counter di sini; biarkan attempt ini terhitung.
    return NextResponse.json({ success: false, error: 'Request tidak valid.' }, { status: 400 });
  }

  if (!checkAdminSecret(body.secret)) {
    // Gagal login — counter TIDAK direset, attempt terhitung
    return NextResponse.json({ success: false, error: 'Secret salah.' }, { status: 401 });
  }

  // Login berhasil — reset counter
  resetBruteForce(ip);
  const token = createSession();
  const res = NextResponse.json({ success: true });

  // FIX: secure:true di production
  res.cookies.set('admin_session', token, {
    httpOnly: true,
    secure:   process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge:   86400,
    path:     '/',
  });
  return res;
}

export async function DELETE(request) {
  const token = getSessionToken(request);
  if (token) destroySession(token);
  const res = NextResponse.json({ success: true });
  res.cookies.set('admin_session', '', { maxAge: 0, path: '/' });
  return res;
}
