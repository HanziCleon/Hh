export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';
import { NextResponse } from 'next/server';
import { requireAdmin } from '../../../../src/lib/adminAuth.js';
import { ensureInit }   from '../../../../src/lib/init.js';
import { listUsers } from '../../../../src/services/UserService.js';
import { listKeys }             from '../../../../src/services/KeyManager.js';
import { getGlobalStats }       from '../../../../src/services/DatabaseService.js';
import { kvListAll }            from '../../../../src/services/KVService.js';
import { getStorageStats }      from '../../../../src/services/StorageService.js';

export async function GET(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  try {
    const users      = listUsers();
    const keys       = listKeys();
    const dbStats    = getGlobalStats();
    const kvEntries  = kvListAll('');
    const storStats  = getStorageStats();

    return NextResponse.json({
      success: true,
      data: {
        users:      { total: users.length, list: users.slice(0, 5) },
        keys:       { total: keys.length, active: keys.filter(k => k.enabled).length },
        files:      dbStats,
        kv:         { total: kvEntries.length },
        storage:    storStats,
        server:     { uptime: Math.floor(process.uptime()), memory: process.memoryUsage() },
      },
    });
  } catch (err) {
    return NextResponse.json({ success: false, error: err.message }, { status: 500 });
  }
}
