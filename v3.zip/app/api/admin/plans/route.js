export const dynamic = 'force-dynamic';
export { OPTIONS } from '../../../../src/lib/corsOptions.js';
import { NextResponse }  from 'next/server';
import { requireAdmin }  from '../../../../src/lib/adminAuth.js';
import { ensureInit }    from '../../../../src/lib/init.js';
import { getAllSubscriptions } from '../../../../src/services/SubscriptionService.js';
import { listUsers }     from '../../../../src/services/UserService.js';
import { invalidatePlansCache } from '../../../../src/services/PlanService.js';
import fs   from 'fs';
import path from 'path';

// ─── Plans config persisted as JSON ──────────────────────────────────────────

const DATA_DIR        = process.env.DATA_DIR || './data';
const PLANS_CFG_PATH  = path.join(DATA_DIR, 'plans-config.json');

function toBytes(mb) { return Math.round(mb * 1024 * 1024); }
function toMB(bytes)  { return Math.round(bytes / 1024 / 1024); }

function defaultPlans() {
  // FIX BUG D: nilai default sinkron dengan PLANS_DEFAULT di PlanService.js.
  // Sebelumnya FREE rateLimit 10000 vs 100, PREMIUM 50000 vs 1000, MAX 1000000 vs 5000 — tidak konsisten.
  return [
    {
      id: 'free',
      name: 'Free',
      price: 0,
      storageBytes: parseInt(process.env.FREE_STORAGE_BYTES    || '10485760'),   // 10 MB
      rateLimit:    parseInt(process.env.FREE_RATE_LIMIT       || '100'),
      color: 'zinc',
      description: 'Untuk pengguna umum yang baru memulai.',
      features: ['10 MB Storage', 'KV Store + File Upload', 'API Key otomatis', 'Rate limit: 100 req/menit'],
      maxFileSizeMB: 10,
      active: true,
    },
    {
      id: 'premium',
      name: 'Premium',
      price: 10000,
      storageBytes: parseInt(process.env.PREMIUM_STORAGE_BYTES || '524288000'),  // 500 MB
      rateLimit:    parseInt(process.env.PREMIUM_RATE_LIMIT    || '1000'),
      color: 'blue',
      description: 'Untuk pengguna aktif yang butuh lebih banyak ruang.',
      features: ['500 MB Storage', 'KV Store + File Upload', 'Custom API Key', 'Rate limit: 1.000 req/menit', 'Priority support'],
      maxFileSizeMB: 100,
      active: true,
    },
    {
      id: 'max',
      name: 'Max',
      price: 15000,
      storageBytes: parseInt(process.env.MAX_STORAGE_BYTES     || '1073741824'), // 1 GB
      rateLimit:    parseInt(process.env.MAX_RATE_LIMIT        || '5000'),
      color: 'amber',
      description: 'Untuk power user tanpa kompromi.',
      features: ['1 GB Storage', 'KV Store + File Upload', 'Custom API Key', 'Rate limit: 5.000 req/menit', 'Priority support', 'Advanced stats'],
      maxFileSizeMB: 500,
      active: true,
    },
  ];
}

function readPlans() {
  try {
    const raw = fs.readFileSync(PLANS_CFG_PATH, 'utf-8');
    return JSON.parse(raw);
  } catch {
    return defaultPlans();
  }
}

// BUG-4 FIX: Gunakan atomic write (tmp → rename) untuk mencegah korupsi file
// jika proses crash di tengah penulisan. Pola ini sudah digunakan di SecurityManager.js
// dan JsonDB._saveSync() — sekarang konsisten di seluruh codebase.
function atomicWriteJSON(filePath, data) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const tmp = filePath + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf-8');
  fs.renameSync(tmp, filePath);
}

function writePlans(plans) {
  atomicWriteJSON(PLANS_CFG_PATH, plans);
}

// ─── GET /api/admin/plans — daftar plan + statistik ──────────────────────────
export async function GET(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  const users         = listUsers();
  const subscriptions = getAllSubscriptions(500);
  const plans         = readPlans();

  const planStats = {};
  for (const p of plans) {
    planStats[p.id] = {
      ...p,
      storageMB: toMB(p.storageBytes),
      userCount: 0,
      revenue: 0,
    };
  }
  for (const u of users) {
    const pid = u.plan || 'free';
    if (planStats[pid]) planStats[pid].userCount++;
  }
  for (const s of subscriptions) {
    if (s.status === 'paid' && planStats[s.plan]) {
      planStats[s.plan].revenue += s.amount || 0;
    }
  }

  const revenue = {
    total:   subscriptions.filter(s => s.status === 'paid').reduce((a, s) => a + (s.amount || 0), 0),
    pending: subscriptions.filter(s => s.status === 'pending').length,
    paid:    subscriptions.filter(s => s.status === 'paid').length,
    expired: subscriptions.filter(s => s.status === 'expired').length,
  };

  return NextResponse.json({
    success: true,
    plans: Object.values(planStats),
    revenue,
    recentSubscriptions: subscriptions.slice(0, 50),
  });
}

// ─── POST /api/admin/plans — buat plan baru ───────────────────────────────────
export async function POST(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  const body = await request.json().catch(() => ({}));
  // FIX BUG-2: destructure customApiKey agar bisa disimpan ke plan custom
  const { id, name, price, storageMB, rateLimit, color, description, features, maxFileSizeMB, active, customApiKey } = body;

  if (!id || !name) {
    return NextResponse.json({ success: false, error: 'id dan name wajib diisi' }, { status: 400 });
  }
  if (!/^[a-z0-9_-]+$/.test(id)) {
    return NextResponse.json({ success: false, error: 'id hanya boleh huruf kecil, angka, - dan _' }, { status: 400 });
  }

  const plans = readPlans();
  if (plans.find(p => p.id === id)) {
    return NextResponse.json({ success: false, error: `Plan id '${id}' sudah ada` }, { status: 409 });
  }

  const newPlan = {
    id,
    name,
    price:         parseInt(price)          || 0,
    storageBytes:  toBytes(parseFloat(storageMB) || 10),
    rateLimit:     parseInt(rateLimit)      || 60,
    color:         color                    || 'zinc',
    description:   description              || '',
    features:      Array.isArray(features)  ? features : [],
    maxFileSizeMB: parseInt(maxFileSizeMB)  || 10,
    active:        active !== false,
    // FIX BUG-2: simpan customApiKey untuk plan custom.
    // Tanpa ini, user plan custom tidak bisa pakai Custom API Key meski admin mengizinkan.
    // PlanService fallback ke {} untuk ID yang tidak ada di PLANS_DEFAULT → field ini hilang.
    ...(customApiKey !== undefined ? { customApiKey: Boolean(customApiKey) } : {}),
    createdAt:     new Date().toISOString(),
  };

  plans.push(newPlan);
  writePlans(plans);
  invalidatePlansCache();

  return NextResponse.json({
    success: true,
    plan: { ...newPlan, storageMB: toMB(newPlan.storageBytes) },
  });
}

// ─── PUT /api/admin/plans — update plan yang ada ─────────────────────────────
export async function PUT(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  const body         = await request.json().catch(() => ({}));
  const { id, ...updates } = body;

  if (!id) {
    return NextResponse.json({ success: false, error: 'id plan wajib diisi' }, { status: 400 });
  }

  const plans = readPlans();
  const idx   = plans.findIndex(p => p.id === id);
  if (idx === -1) {
    return NextResponse.json({ success: false, error: `Plan '${id}' tidak ditemukan` }, { status: 404 });
  }

  const patch = {};
  if (updates.name        !== undefined) patch.name         = updates.name;
  if (updates.price       !== undefined) patch.price        = parseInt(updates.price)        || 0;
  if (updates.storageMB   !== undefined) patch.storageBytes = toBytes(parseFloat(updates.storageMB) || 0);
  if (updates.rateLimit   !== undefined) patch.rateLimit    = parseInt(updates.rateLimit)    || 0;
  if (updates.maxFileSizeMB !== undefined) patch.maxFileSizeMB = parseInt(updates.maxFileSizeMB) || 0;
  if (updates.color       !== undefined) patch.color        = updates.color;
  if (updates.description !== undefined) patch.description  = updates.description;
  if (updates.features    !== undefined) patch.features     = Array.isArray(updates.features) ? updates.features : [];
  if (updates.active      !== undefined) patch.active       = updates.active;
  // FIX BUG-2: izinkan customApiKey diupdate via PUT
  if (updates.customApiKey !== undefined) patch.customApiKey = Boolean(updates.customApiKey);
  patch.updatedAt = new Date().toISOString();

  plans[idx] = { ...plans[idx], ...patch };
  writePlans(plans);
  invalidatePlansCache();

  const updated = plans[idx];
  return NextResponse.json({
    success: true,
    plan: { ...updated, storageMB: toMB(updated.storageBytes) },
  });
}

// ─── DELETE /api/admin/plans?id=xxx — hapus plan ─────────────────────────────
export async function DELETE(request) {
  const guard = requireAdmin(request);
  if (guard.error) return guard.error;
  await ensureInit();

  const { searchParams } = new URL(request.url);
  const id = searchParams.get('id');

  if (!id) {
    return NextResponse.json({ success: false, error: 'query ?id= wajib ada' }, { status: 400 });
  }
  if (id === 'free') {
    return NextResponse.json({ success: false, error: "Plan 'free' tidak bisa dihapus karena merupakan plan default" }, { status: 400 });
  }

  const plans = readPlans();
  const idx   = plans.findIndex(p => p.id === id);
  if (idx === -1) {
    return NextResponse.json({ success: false, error: `Plan '${id}' tidak ditemukan` }, { status: 404 });
  }

  const users  = listUsers();
  const inUse  = users.filter(u => (u.plan || 'free') === id);
  if (inUse.length > 0) {
    return NextResponse.json({
      success: false,
      error: `Plan '${id}' masih digunakan oleh ${inUse.length} user. Pindahkan user ke plan lain terlebih dahulu.`,
    }, { status: 409 });
  }

  const [removed] = plans.splice(idx, 1);
  writePlans(plans);
  invalidatePlansCache();

  return NextResponse.json({ success: true, message: `Plan '${removed.name}' berhasil dihapus` });
}
