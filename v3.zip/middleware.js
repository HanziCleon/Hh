/**
 * middleware.js — CORS headers untuk semua actual API response
 *
 * GLOBAL CDN MODE: Selalu pakai wildcard '*' agar CDN bisa dipakai
 * sebagai database global dari website manapun.
 *
 * OPTIONS preflight ditangani per-route via corsOptions.js (OPTIONS handler).
 * Middleware hanya menambah header CORS ke actual response (GET/POST/PUT/DELETE).
 */

import { NextResponse } from 'next/server';

export function middleware(request) {
  // OPTIONS: biarkan route handler masing-masing yang merespons (via corsOptions.js)
  // agar tidak terjadi duplikasi header pada preflight response.
  if (request.method === 'OPTIONS') {
    return NextResponse.next();
  }

  const response = NextResponse.next();

  // GLOBAL CDN: selalu wildcard — tidak perlu DOMAIN-based restriction
  response.headers.set('Access-Control-Allow-Origin',   '*');
  response.headers.set('Access-Control-Allow-Methods',  'GET, POST, PUT, DELETE, PATCH, OPTIONS, HEAD');
  response.headers.set('Access-Control-Allow-Headers',  'Content-Type, x-api-key, Authorization, X-API-Key, Range, Accept');
  response.headers.set('Access-Control-Expose-Headers', 'Content-Length, Content-Range, X-File-ID, X-File-Category, Accept-Ranges');

  return response;
}

export const config = {
  matcher: '/api/:path*',
};
