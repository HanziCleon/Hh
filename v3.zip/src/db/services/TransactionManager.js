/**
 * TransactionManager - Manages ACID transactions for DongtubeDB
 *
 * FIXES v4 → v5:
 *  BUG-2-KRITIS: bufferOperation() hanya snapshot startPage + lastPage.
 *                Tabel besar punya banyak page (linked-list), page di tengah
 *                tidak di-snapshot → rollback tidak restore page tengah → data korup.
 *                FIX: traverse seluruh linked-list page dan snapshot semua page.
 *  BUG-FIX: Math.random() untuk transactionId diganti crypto.randomBytes() (CSPRNG).
 *
 * FIXES v3 → v4:
 *  FIX-A: Snapshot sekarang BENAR-BENAR diisi saat BEGIN — clone seluruh data
 *          tabel yang terlibat ke dalam this.snapshot.
 *  FIX-B: Rollback sekarang BENAR-BENAR restore data dari snapshot ke pager
 *          — bukan sekadar buang buffer.
 *  FIX-C: Commit partial failure → auto rollback jika ada operasi yang gagal
 *          di tengah-tengah (atomicity).
 *  FIX-D: Nested transaction guard — tidak bisa BEGIN di dalam BEGIN aktif.
 *  FIX-E: savepoint support sederhana (SAVEPOINT name / ROLLBACK TO name).
 */
/**
 * ⚠️  DEAD CODE / LEGACY — JANGAN DIGUNAKAN
 *
 * Bagian dari engine lama (DongtubeEngine). Sudah digantikan oleh JsonDB.js.
 * Menggunakan CommonJS (require/module.exports) — tidak kompatibel dengan ESM project ini.
 * Tidak diimport di manapun dalam codebase aktif.
 */
const crypto = require('crypto');
class TransactionManager {
    constructor(engine) {
        this.engine = engine;
        this.state = 'IDLE'; // IDLE | ACTIVE
        this.transactionId = null;
        this.buffer = []; // Buffered operations during transaction
        this.snapshot = new Map(); // FIX-A: Table data snapshots untuk UNDO
        this.savepoints = new Map(); // FIX-E: named savepoints
    }

    /**
     * FIX-A: BEGIN sekarang capture snapshot seluruh page catalog (page 0)
     * untuk keperluan rollback yang akurat.
     */
    begin() {
        if (this.state === 'ACTIVE') {
            // FIX-D: jangan biarkan nested transaction — lempar error jelas
            throw new Error('Transaksi sudah aktif. SAHKAN atau BATALKAN dulu sebelum mulai baru.');
        }

        this.state = 'ACTIVE';
        // FIX: Ganti Math.random() dengan crypto.randomBytes() (CSPRNG) untuk ID transaksi.
        this.transactionId = `txn_${Date.now()}_${crypto.randomBytes(5).toString('hex')}`;
        this.buffer = [];
        this.snapshot.clear();
        this.savepoints.clear();

        // FIX-A: Simpan snapshot page 0 (catalog tabel) — paling penting untuk rollback
        try {
            const page0 = this.engine.pager.readPage(0);
            this.snapshot.set(0, Buffer.from(page0)); // clone buffer
        } catch (e) {
            console.error('[TX] Gagal ambil snapshot page 0:', e.message);
        }

        return `Transaksi dimulai: ${this.transactionId}`;
    }

    /**
     * FIX-C: Commit atomik — jika ada operasi yang gagal di tengah,
     * langsung rollback semua operasi yang sudah terjadi.
     * FIX-TRIGGER: Panggil triggerManager.handleEvent dan searchManager.indexRow
     *   setelah setiap operasi berhasil, sama seperti path non-transaksi di engine.query().
     */
    commit() {
        if (this.state !== 'ACTIVE') {
            throw new Error('Tidak ada transaksi aktif untuk di-commit.');
        }

        const executedOps = []; // Track operasi yang sudah berhasil

        try {
            for (const op of this.buffer) {
                let result;
                switch (op.type) {
                    case 'INSERT':
                        result = this.engine.insertExecutor.execute(op.command);
                        this.engine.triggerManager.handleEvent('INSERT', op.command.table);
                        if (op.command.values) {
                            this.engine.searchManager.indexRow(
                                op.command.table,
                                op.command.values.id || Date.now(),
                                op.command.values
                            );
                        }
                        break;
                    case 'UPDATE':
                        result = this.engine.updateExecutor.execute(op.command);
                        this.engine.triggerManager.handleEvent('UPDATE', op.command.table);
                        break;
                    case 'DELETE':
                        result = this.engine.deleteExecutor.execute(op.command);
                        this.engine.triggerManager.handleEvent('DELETE', op.command.table);
                        break;
                    default:
                        throw new Error(`Tipe operasi tidak dikenal: ${op.type}`);
                }
                executedOps.push({ op, result });
            }

            const opCount = this.buffer.length;
            this._cleanup();

            // Flush ke disk setelah commit berhasil
            try {
                this.engine.pager.flush();
            } catch (e) {
                console.error('[TX]   Flush setelah commit gagal:', e.message);
            }

            return `Transaksi berhasil: ${opCount} operasi dieksekusi. [${this.transactionId || 'done'}]`;
        } catch (error) {
            // FIX-C: Ada kegagalan → rollback untuk jaga atomicity
            console.error(`[TX]  Commit gagal di operasi ke-${executedOps.length + 1}: ${error.message}`);
            console.error('[TX]  Auto-rollback dimulai...');
            this._performRollback();
            throw new Error(`Commit gagal (sudah di-rollback): ${error.message}`);
        }
    }

    /**
     * FIX-B: Rollback sekarang restore data dari snapshot ke pager.
     * Tidak lagi sekadar buang buffer — data yang terlanjur ditulis di-undo.
     */
    rollback() {
        if (this.state !== 'ACTIVE') {
            throw new Error('Tidak ada transaksi aktif untuk di-rollback.');
        }

        const opCount = this.buffer.length;
        this._performRollback();

        return `Transaksi dibatalkan: ${opCount} operasi dibuang.`;
    }

    /**
     * FIX-B: Eksekusi rollback yang sesungguhnya.
     * Restore snapshot pages ke pager cache + flush ke disk.
     */
    _performRollback() {
        // Restore semua snapshot pages ke pager
        let restoredCount = 0;
        for (const [pageId, pageSnapshot] of this.snapshot) {
            try {
                // Tulis kembali snapshot ke pager (bypass WAL untuk undo)
                this.engine.pager.cache.set(pageId, Buffer.from(pageSnapshot));
                this.engine.pager.dirtyPages.add(pageId);
                this.engine.pager.objectCache.delete(pageId); // invalidate
                restoredCount++;
            } catch (e) {
                console.error(`[TX]  Gagal restore snapshot page=${pageId}: ${e.message}`);
            }
        }

        if (restoredCount > 0) {
            try {
                this.engine.pager.flush();
                console.log(`[TX]  Rollback: ${restoredCount} page direstorasi ke disk.`);
            } catch (e) {
                console.error('[TX]  Flush setelah rollback gagal:', e.message);
            }
        }

        this._cleanup();
    }

    /**
     * FIX-A: Saat operasi di-buffer, capture snapshot page yang terlibat
     * agar rollback bisa undo ke state sebelum transaksi.
     */
    bufferOperation(type, command) {
        if (this.state !== 'ACTIVE') {
            return null;
        }

        // FIX-A: Snapshot SEMUA halaman tabel yang terlibat (bukan hanya startPage+lastPage).
        // BUG-2 FIX: Tabel besar punya banyak page yang membentuk linked-list:
        //   startPage → next → next → ... → lastPage → 0 (end)
        // Sebelumnya hanya startPage dan lastPage yang di-snapshot, sehingga
        // page di tengah tidak di-restore saat rollback → data korup pada tabel besar.
        try {
            const tableName = command.table;
            if (tableName) {
                const entry = this.engine.tableManager
                    ? this.engine.tableManager.findTableEntry(tableName)
                    : null;

                if (entry) {
                    // Traverse seluruh linked-list page dan snapshot semua yang belum ada
                    let currentPageId = entry.startPage;
                    let safety = 0;
                    const MAX_PAGES = 100000; // guard infinite loop

                    while (currentPageId !== 0 && safety++ < MAX_PAGES) {
                        if (!this.snapshot.has(currentPageId)) {
                            try {
                                const page = this.engine.pager.readPage(currentPageId);
                                this.snapshot.set(currentPageId, Buffer.from(page));
                            } catch (pageErr) {
                                console.warn(`[TX] Gagal snapshot page=${currentPageId}:`, pageErr.message);
                                break;
                            }
                        }
                        // Baca pointer 'next' dari header page (offset 0, 4 bytes LE)
                        const pageData = this.engine.pager.readPageObjects(currentPageId);
                        currentPageId = pageData.next;
                    }
                }
            }
        } catch (e) {
            console.warn('[TX] Gagal snapshot page untuk operasi:', e.message);
        }

        this.buffer.push({ type, command });
        return `Operasi di-buffer (${this.buffer.length} total).`;
    }

    /**
     * FIX-E: Savepoint — simpan state buffer saat ini dengan nama
     */
    savepoint(name) {
        if (this.state !== 'ACTIVE') {
            throw new Error('Tidak ada transaksi aktif untuk savepoint.');
        }
        // Simpan index buffer saat ini + snapshot pages saat ini
        const snapshotCopy = new Map();
        for (const [k, v] of this.snapshot) snapshotCopy.set(k, Buffer.from(v));

        this.savepoints.set(name, {
            bufferLength: this.buffer.length,
            snapshot: snapshotCopy,
        });
        return `Savepoint '${name}' tersimpan (${this.buffer.length} operasi).`;
    }

    /**
     * FIX-E: Rollback ke savepoint — buang operasi setelah savepoint
     */
    rollbackToSavepoint(name) {
        if (this.state !== 'ACTIVE') {
            throw new Error('Tidak ada transaksi aktif.');
        }
        const sp = this.savepoints.get(name);
        if (!sp) throw new Error(`Savepoint '${name}' tidak ditemukan.`);

        // Buang operasi setelah savepoint
        const discarded = this.buffer.length - sp.bufferLength;
        this.buffer = this.buffer.slice(0, sp.bufferLength);

        // Restore snapshot ke state savepoint
        this.snapshot.clear();
        for (const [k, v] of sp.snapshot) this.snapshot.set(k, Buffer.from(v));

        return `Rollback ke savepoint '${name}': ${discarded} operasi dibuang.`;
    }

    isActive() {
        return this.state === 'ACTIVE';
    }

    _cleanup() {
        this.state = 'IDLE';
        this.transactionId = null;
        this.buffer = [];
        this.snapshot.clear();
        this.savepoints.clear();
    }
}

module.exports = TransactionManager;
