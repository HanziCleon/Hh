const fs   = require('fs');
const path = require('path');

/**
 * SecurityManager - Permission management for DongtubeDB
 *
 * FIXES v4 → v5:
 *  BUG-6: check() — `if (!user) return true` membypass semua permission
 *          jika user null/undefined/''. Fix: normalisasi ke 'anonymous' dan
 *          tetap cek permission. Hanya 'admin' yang boleh bypass.
 *
 * FIXES v3 → v4:
 *  FIX-A: Internal tables (prefix _) sekarang tetap di-check permission
 *          tapi dengan whitelist: hanya 'admin' atau user dengan perm '*' yang boleh
 *  FIX-B: init() dijadikan sync (tidak async) agar bisa dipanggil dari constructor
 *          tanpa await yang sering dilupa
 *  FIX-C: save() menggunakan atomic write (tulis ke tmp dulu lalu rename)
 *          agar file permissions tidak corrupt jika proses mati saat write
 */
class SecurityManager {
    constructor(engine) {
        this.engine = engine;
        this.permissions = [];
        this.permissionsPath = null;
    }

    // FIX-B: sync init agar tidak perlu await
    init() {
        this.permissionsPath = path.join(this.engine.dbPath, '_permissions.json');

        if (fs.existsSync(this.permissionsPath)) {
            try {
                const raw = fs.readFileSync(this.permissionsPath, 'utf8');
                this.permissions = JSON.parse(raw);
            } catch (e) {
                console.error('[Security] Gagal load permissions (file corrupt?), reset ke kosong:', e.message);
                this.permissions = [];
                this.save(); // Tulis ulang file yang corrupt
            }
        } else {
            this.permissions = [];
            this.save();
        }
    }

    /**
     * FIX-C: Atomic write — tulis ke file .tmp dulu, lalu rename.
     * Jika proses mati saat write, file asli tidak akan corrupt.
     */
    save() {
        if (!this.permissionsPath) return;
        const tmpPath = this.permissionsPath + '.tmp';
        try {
            fs.writeFileSync(tmpPath, JSON.stringify(this.permissions, null, 2), 'utf8');
            fs.renameSync(tmpPath, this.permissionsPath);
        } catch (e) {
            console.error('[Security] Gagal simpan permissions:', e.message);
            try { fs.unlinkSync(tmpPath); } catch (_) {}
        }
    }

    grant(user, table, action) {
        // Hapus entri duplikat dulu
        this.permissions = this.permissions.filter(
            p => !(p.user === user && p.table === table && p.action === action)
        );
        this.permissions.push({ user, table, action });
        this.save();
        return `Izin '${action}' diberikan kepada '${user}' untuk tabel '${table}'.`;
    }

    revoke(user, table, action) {
        const before = this.permissions.length;
        this.permissions = this.permissions.filter(
            p => !(p.user === user && p.table === table && p.action === action)
        );
        this.save();
        return this.permissions.length < before
            ? `Izin '${action}' dicabut dari '${user}' untuk tabel '${table}'.`
            : `Izin tidak ditemukan.`;
    }

    /**
     * FIX-A: Internal tables (nama mulai _) sekarang tetap di-check:
     * Hanya admin atau user dengan wildcard '*' yang boleh akses.
     * Ini menutup celah keamanan di mana tabel _indexes bisa diakses
     * oleh sembarang user tanpa permission.
     */
    check(user, table, action) {
        // BUG-6 FIX: Sebelumnya `if (!user) return true` — artinya null/undefined/''
        // langsung bypass semua permission check. Ini sangat berbahaya jika ada code
        // path yang lupa set user. Sekarang null/undefined dinormalisasi ke 'anonymous',
        // dan harus punya permission eksplisit seperti user biasa.
        const effectiveUser = user || 'anonymous';
        if (effectiveUser === 'admin') return true; // Superuser selalu boleh

        // FIX-A: Tabel internal — hanya superuser/wildcard yang boleh
        if (table && table.startsWith('_')) {
            const hasWildcard = this.permissions.some(
                p => p.user === effectiveUser && p.table === '*' && (p.action === action || p.action === 'all')
            );
            if (!hasWildcard) {
                throw new Error(`Akses Ditolak: User '${effectiveUser}' tidak punya izin akses tabel sistem '${table}'.`);
            }
            return true;
        }

        // Tabel biasa: cek permission normal
        const hasPerm = this.permissions.some(p =>
            p.user === effectiveUser &&
            (p.table === table || p.table === '*') &&
            (p.action === action || p.action === 'all')
        );

        if (!hasPerm) {
            throw new Error(`Akses Ditolak: User '${effectiveUser}' tidak punya izin '${action}' di tabel '${table}'.`);
        }
        return true;
    }
}

module.exports = SecurityManager;
