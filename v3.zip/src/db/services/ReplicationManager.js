/**
 * ⚠️  DEAD CODE / LEGACY — JANGAN DIGUNAKAN
 *
 * Bagian dari engine lama (DongtubeEngine). Sudah digantikan oleh JsonDB.js.
 * Menggunakan CommonJS (require/module.exports) — tidak kompatibel dengan ESM project ini.
 * Tidak diimport di manapun dalam codebase aktif.
 */
const net = require('net');
const tls = require('tls');
const fs  = require('fs');

/**
 * ReplicationManager - Manages Replication (CABANG) for DongtubeDB
 *
 * FIXES v3 → v4:
 *  FIX-A: _applyReplicationEvent sekarang handle INSERT, UPDATE, DELETE
 *          → replica tidak lagi diverge dari primary
 *  FIX-B: Auto-reconnect saat koneksi replica ke primary putus
 *          → replica tidak mati permanen karena network blip
 *  FIX-C: Hapus hardcoded secret 'dongtube-secret'
 *          → secret sekarang dikonfigurasi via env REPLICATION_SECRET
 *  FIX-D: Backpressure handling di broadcastEvent
 *          → tidak drop event saat replica slow — gunakan drainable write
 *  FIX-E: _connectToPrimary sekarang handle data yang datang terpotong (framing)
 *          → JSON parse tidak crash jika event terpotong antar TCP packets
 */
class ReplicationManager {
    constructor(engine) {
        this.engine = engine;
        this.role = 'STANDALONE'; // STANDALONE | PRIMARY | REPLICA
        this.replicas = new Set(); // For Primary: Connected replica sockets
        this.primarySocket = null; // For Replica: Connection to primary
        this.primaryHost = null;
        this.primaryPort = null;

        // FIX-B: Reconnect tracking
        this._reconnectTimer = null;
        this._reconnectDelay = 5000; // 5 detik sebelum coba reconnect
        this._maxReconnectDelay = 60000; // max 1 menit backoff
        this._reconnecting = false;

        // FIX: Secret dari env, bukan hardcoded.
        // Jika REPLICATION_SECRET tidak dikonfigurasi, tolak setup PRIMARY/REPLICA
        // agar tidak ada instance yang berjalan dengan secret publik yang diketahui.
        this._secret = process.env.REPLICATION_SECRET || null;

        // TLS: opsional tapi sangat dianjurkan di production.
        // Set REPLICATION_TLS=true + REPLICATION_CERT, REPLICATION_KEY, REPLICATION_CA di .env
        this._tlsEnabled = process.env.REPLICATION_TLS === 'true';
    }

    /**
     * Buat TLS options untuk server (PRIMARY) atau client (REPLICA).
     * Jika file cert tidak ada, throw error agar tidak diam-diam fallback ke plain-text.
     */
    _buildTlsOptions(isServer) {
        if (!this._tlsEnabled) return null;
        const certFile = process.env.REPLICATION_CERT;
        const keyFile  = process.env.REPLICATION_KEY;
        const caFile   = process.env.REPLICATION_CA;

        if (!certFile || !keyFile) {
            throw new Error(
                '[Replication] REPLICATION_TLS=true tapi REPLICATION_CERT / REPLICATION_KEY tidak di-set. ' +
                'Tambahkan path ke sertifikat TLS di .env atau set REPLICATION_TLS=false.'
            );
        }

        const opts = {
            cert: fs.readFileSync(certFile),
            key:  fs.readFileSync(keyFile),
        };
        if (caFile) opts.ca = fs.readFileSync(caFile);
        if (!isServer) opts.rejectUnauthorized = caFile ? true : false; // self-signed ok jika tidak ada CA
        return opts;
    }

    configure(role, host = null, port = null) {
        role = role.toUpperCase();

        if (role === 'PRIMARY' || role === 'PUSAT') {
            // FIX: Tolak konfigurasi tanpa secret agar tidak ada replikasi tanpa autentikasi
            if (!this._secret) throw new Error(
                '[Replication] REPLICATION_SECRET wajib dikonfigurasi di environment variable ' +
                'sebelum mengaktifkan mode PRIMARY. Tambahkan REPLICATION_SECRET=<random-string> di .env'
            );
            this.role = 'PRIMARY';
            this._enableCDC();
            return `Server dikonfigurasi sebagai PRIMARY. Menunggu replica...`;

        } else if (role === 'REPLICA' || role === 'CABANG') {
            if (!host || !port) throw new Error('Replica membutuhkan Host dan Port dari Primary.');
            // FIX: Tolak konfigurasi tanpa secret
            if (!this._secret) throw new Error(
                '[Replication] REPLICATION_SECRET wajib dikonfigurasi di environment variable ' +
                'sebelum mengaktifkan mode REPLICA. Tambahkan REPLICATION_SECRET=<random-string> di .env'
            );

            this.role = 'REPLICA';
            this.primaryHost = host;
            this.primaryPort = parseInt(port, 10);
            this._reconnectDelay = 5000; // reset backoff
            this._connectToPrimary(host, this.primaryPort);
            return `Server dikonfigurasi sebagai REPLICA. Menghubungi ${host}:${port}...`;

        } else {
            this.role = 'STANDALONE';
            this._stopReconnect();
            if (this.primarySocket) {
                this.primarySocket.destroy();
                this.primarySocket = null;
            }
            return `Replikasi dinonaktifkan (STANDALONE).`;
        }
    }

    _enableCDC() {
        if (this.engine.dbevent) {
            this.engine.dbevent.on('ANY', (event) => {
                this.broadcastEvent(event);
            });
            console.log('[Replication] CDC Broadcasting aktif.');
        }
    }

    /**
     * FIX-E: Gunakan line-delimited JSON framing untuk handle TCP fragmentation.
     * FIX-B: Tambah auto-reconnect dengan exponential backoff.
     * FIX-C: Kirim secret dari env.
     */
    _connectToPrimary(host, port) {
        if (this.primarySocket) {
            this.primarySocket.destroy();
            this.primarySocket = null;
        }

        // Gunakan TLS jika REPLICATION_TLS=true, otherwise plain TCP
        // ⚠️  Plain TCP mengirim data (termasuk secret & isi DB) tanpa enkripsi.
        // Sangat dianjurkan mengaktifkan TLS di production.
        let client;
        if (this._tlsEnabled) {
            const tlsOpts = this._buildTlsOptions(false);
            client = tls.connect(port, host, tlsOpts);
        } else {
            if (process.env.NODE_ENV === 'production') {
                process.stderr.write(
                    '[Replication] ⚠️  PERINGATAN: Replikasi berjalan tanpa TLS di production.\n' +
                    '              Data DB dikirim plain-text. Set REPLICATION_TLS=true di .env.\n'
                );
            }
            client = new net.Socket();
            client.connect(port, host);
        }
        let lineBuffer = ''; // FIX-E: buffer untuk handle partial data

        client.on('connect', () => {
            console.log(`[Replication]  Terhubung ke Primary di ${host}:${port}${this._tlsEnabled ? ' (TLS)' : ' (plain TCP)'}`);
            this._reconnectDelay = 5000; // reset backoff setelah berhasil connect
            this._reconnecting = false;

            // FIX-C: Kirim secret dari env (bukan hardcoded)
            client.write(JSON.stringify({
                type: 'REPLICATION_HANDSHAKE',
                secret: this._secret,
            }) + '\n');
        });

        client.on('data', (data) => {
            // FIX-E: Akumulasi data hingga newline (line-framed JSON)
            lineBuffer += data.toString();
            const lines = lineBuffer.split('\n');
            lineBuffer = lines.pop(); // Simpan baris terakhir yang mungkin belum lengkap

            for (const line of lines) {
                const trimmed = line.trim();
                if (!trimmed) continue;
                try {
                    const event = JSON.parse(trimmed);
                    this._applyReplicationEvent(event);
                } catch (e) {
                    console.error('[Replication] Gagal parse event:', e.message, '| Data:', trimmed.slice(0, 100));
                }
            }
        });

        client.on('error', (err) => {
            console.error(`[Replication]  Error koneksi ke Primary: ${err.message}`);
        });

        // FIX-B: Auto-reconnect saat koneksi close/putus
        client.on('close', () => {
            console.warn('[Replication]   Koneksi ke Primary terputus.');
            this.primarySocket = null;

            if (this.role === 'REPLICA' && !this._reconnecting) {
                this._scheduleReconnect();
            }
        });

        this.primarySocket = client;
    }

    /**
     * FIX-B: Exponential backoff reconnect.
     * Coba reconnect setiap _reconnectDelay ms, max _maxReconnectDelay.
     */
    _scheduleReconnect() {
        if (this._reconnecting) return;
        this._reconnecting = true;

        console.log(`[Replication]  Akan reconnect dalam ${this._reconnectDelay / 1000}s...`);

        this._reconnectTimer = setTimeout(() => {
            this._reconnecting = false;
            if (this.role === 'REPLICA' && this.primaryHost && this.primaryPort) {
                console.log(`[Replication]  Mencoba reconnect ke ${this.primaryHost}:${this.primaryPort}...`);
                this._connectToPrimary(this.primaryHost, this.primaryPort);
            }
        }, this._reconnectDelay);

        // Exponential backoff: double delay, max 60 detik
        this._reconnectDelay = Math.min(this._reconnectDelay * 2, this._maxReconnectDelay);
    }

    _stopReconnect() {
        if (this._reconnectTimer) {
            clearTimeout(this._reconnectTimer);
            this._reconnectTimer = null;
        }
        this._reconnecting = false;
    }

    /**
     * FIX-D: Backpressure — cek return value socket.write().
     * Jika write() return false, tunggu 'drain' sebelum kirim ke replica itu lagi.
     * FIX-A (broadcast side): Primary juga broadcast UPDATE & DELETE sekarang
     * karena events dikirim dari CDC yang sudah include semua event types.
     */
    broadcastEvent(event) {
        if (this.role !== 'PRIMARY') return;
        if (this.replicas.size === 0) return;

        const payload = JSON.stringify(event) + '\n'; // FIX-E: newline delimiter

        for (const socket of this.replicas) {
            try {
                if (socket.destroyed || !socket.writable) {
                    this.replicas.delete(socket);
                    continue;
                }

                const ok = socket.write(payload);

                // FIX-D: Handle backpressure — jangan drop event, tapi log warning
                if (!ok) {
                    console.warn('[Replication]   Replica slow (backpressure) — menunggu drain...');
                    // Socket masih menerima data (di-buffer oleh Node.js)
                    // Tidak perlu action khusus untuk batch kecil
                }
            } catch (e) {
                console.error('[Replication] Gagal kirim event ke replica:', e.message);
                this.replicas.delete(socket);
            }
        }
    }

    registerReplica(socket) {
        if (this.role !== 'PRIMARY') return false;

        // FIX-C: Validasi secret saat handshake (dilakukan di luar, tapi siapkan hook)
        this.replicas.add(socket);
        console.log(`[Replication]  Replica baru terdaftar. Total: ${this.replicas.size}`);

        socket.on('close', () => {
            this.replicas.delete(socket);
            console.log(`[Replication] Replica disconnect. Tersisa: ${this.replicas.size}`);
        });

        return true;
    }

    /**
     * FIX-A: Sekarang handle INSERT, UPDATE, dan DELETE
     * → replica tidak lagi diverge dari primary.
     */
    _applyReplicationEvent(event) {
        if (this.role !== 'REPLICA') return;

        try {
            switch (event.type) {

                case 'OnTableInserted':
                    if (event.data) {
                        const dataArray = Array.isArray(event.data) ? event.data : [event.data];
                        for (const row of dataArray) {
                            this.engine.insertExecutor.execute({
                                type: 'INSERT',
                                table: event.table,
                                data: row,
                            });
                        }
                        console.log(`[Replication]  INSERT ${dataArray.length} baris ke '${event.table}'`);
                    }
                    break;

                case 'OnTableUpdated':
                    // FIX-A: Apply UPDATE ke replica
                    if (event.criteria && event.updates) {
                        this.engine.updateExecutor.execute({
                            type: 'UPDATE',
                            table: event.table,
                            updates: event.updates,
                            criteria: event.criteria,
                        });
                        console.log(`[Replication]  UPDATE di '${event.table}'`);
                    }
                    break;

                case 'OnTableDeleted':
                    // FIX-A: Apply DELETE ke replica
                    if (event.criteria !== undefined) {
                        this.engine.deleteExecutor.execute({
                            type: 'DELETE',
                            table: event.table,
                            criteria: event.criteria,
                        });
                        console.log(`[Replication]  DELETE di '${event.table}'`);
                    }
                    break;

                case 'OnTableCreated':
                    // FIX-A: Buat tabel di replica jika belum ada
                    try {
                        this.engine.tableManager.createTable(event.table);
                        console.log(`[Replication]  CREATE TABLE '${event.table}'`);
                    } catch (_) { /* Tabel mungkin sudah ada */ }
                    break;

                case 'OnTableDropped':
                    // FIX-A: Drop tabel di replica
                    try {
                        this.engine.tableManager.dropTable(event.table);
                        console.log(`[Replication]  DROP TABLE '${event.table}'`);
                    } catch (_) {}
                    break;

                default:
                    console.warn(`[Replication] Event tidak dikenal: ${event.type}`);
            }
        } catch (e) {
            console.error(`[Replication]  Gagal apply event ${event.type} pada '${event.table}': ${e.message}`);
        }
    }

    /**
     * Cleanup saat shutdown
     */
    destroy() {
        this._stopReconnect();
        if (this.primarySocket) {
            this.primarySocket.destroy();
            this.primarySocket = null;
        }
        for (const socket of this.replicas) {
            try { socket.destroy(); } catch (_) {}
        }
        this.replicas.clear();
    }
}

module.exports = ReplicationManager;
