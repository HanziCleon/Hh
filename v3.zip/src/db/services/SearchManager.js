const fs = require('fs');
const path = require('path');

class SearchManager {
    constructor(engine) {
        this.engine = engine;
        this.indexPath = null;
        this.index = {}; // In-memory inverted index
        this.stopWords = new Set(['dan', 'atau', 'yang', 'di', 'ke', 'dari', 'ini', 'itu', 'the', 'and', 'or', 'of', 'to', 'in']);
    }

    /**
     * Initialize FTS Index
     */
    async init() {
        this.indexPath = path.join(this.engine.dbPath, '_fts_index.json');

        if (fs.existsSync(this.indexPath)) {
            try {
                const data = fs.readFileSync(this.indexPath, 'utf8');
                this.index = JSON.parse(data);
            } catch (e) {
                console.error("Failed to load FTS index:", e);
                this.index = {};
            }
        }
    }

    /**
     * Save index to disk
     */
    save() {
        if (!this.indexPath) return;
        fs.writeFileSync(this.indexPath, JSON.stringify(this.index));
    }

    /**
     * Tokenize text into words
     */
    tokenize(text) {
        if (!text || typeof text !== 'string') return [];
        return text.toLowerCase()
            .replace(/[^\w\s]/g, '') // Remove punctuation
            .split(/\s+/)
            .filter(w => w.length > 2 && !this.stopWords.has(w));
    }

    /**
     * Index a row's data
     * Called on INSERT/UPDATE
     */
    indexRow(table, id, data) {
        for (const [col, val] of Object.entries(data)) {
            const tokens = this.tokenize(val);
            for (const token of tokens) {
                if (!this.index[token]) this.index[token] = [];

                const exists = this.index[token].find(entry => entry.t === table && entry.id === id);
                if (!exists) {
                    this.index[token].push({ t: table, id: id });
                }
            }
        }
        this.save(); // Simple persistence
    }

    /**
     * Remove tokens for a row
     * Called on UPDATE (before re-index) / DELETE
     */
    deindexRow(table, id) {
        for (const token in this.index) {
            this.index[token] = this.index[token].filter(entry => !(entry.t === table && entry.id === id));
            if (this.index[token].length === 0) {
                delete this.index[token];
            }
        }
        this.save();
    }

    /**
     * Perform Search
     * Query: BLUSUKAN KE [table] CARI "term"
     */
    search(table, term) {
        const tokens = this.tokenize(term);
        if (tokens.length === 0) return [];

        let candidateIds = null;

        for (const token of tokens) {
            const entries = this.index[token] || [];
            const ids = entries.filter(e => e.t === table).map(e => e.id);

            if (candidateIds === null) {
                candidateIds = new Set(ids);
            } else {
                const currentSet = new Set(ids);
                candidateIds = new Set([...candidateIds].filter(x => currentSet.has(x)));
            }

            if (candidateIds.size === 0) break;
        }

        if (!candidateIds) return [];

        const manager = this.engine.tableManagers[table];
        if (!manager) return [];

        const results = [];
        for (const id of candidateIds) {
            const row = manager.pager.getRow(id); // direct access if supported or via scan

            if (row) results.push(row);
        }

        const allRows = manager.getAllRows(); // Expensive but safe fallback
        return allRows.filter(r => candidateIds.has(r._id) || candidateIds.has(r.id));
    }
}

module.exports = SearchManager;
