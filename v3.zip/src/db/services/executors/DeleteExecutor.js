const termObj = require('../QueryExecutor');
const QueryExecutor = require('../QueryExecutor');
const ConditionEvaluator = require('../logic/ConditionEvaluator');

class DeleteExecutor extends QueryExecutor {
    constructor(db) {
        super(db);
        this.conditionEvaluator = new ConditionEvaluator();
    }

    execute(cmd) {
        return this.delete(cmd.table, cmd.criteria);
    }

    delete(table, criteria, forceFullScan = false) {
        const entry = this.db.tableManager
            ? this.db.tableManager.findTableEntry(table)
            : this.db._findTableEntry(table);

        if (!entry) throw new Error(`Kebun '${table}' tidak ditemukan.`);

        let hintPageId = -1;
        if (!forceFullScan && criteria && criteria.op === '=' && criteria.key) {
            const indexKey = `${table}.${criteria.key}`;
            if (this.db.indexes.has(indexKey)) {
                const index = this.db.indexes.get(indexKey);
                const searchRes = index.search(criteria.val);
                if (searchRes.length > 0 && searchRes[0]._pageId !== undefined) {
                    hintPageId = searchRes[0]._pageId;
                }
            }
        }

        let currentPageId = (hintPageId !== -1) ? hintPageId : entry.startPage;
        let deletedCount = 0;
        let deletedData = [];

        while (currentPageId !== 0) {
            let pData = this.db.pager.readPage(currentPageId);
            const count = pData.readUInt16LE(4);
            let offset = 8;
            const recordsToKeep = [];
            let pageModified = false;

            for (let i = 0; i < count; i++) {
                const len = pData.readUInt16LE(offset);
                const jsonStr = pData.toString('utf8', offset + 2, offset + 2 + len);
                let shouldDelete = false;
                let parsedObj = null;

                try {
                    parsedObj = JSON.parse(jsonStr);
                    if (this.conditionEvaluator.checkMatch(parsedObj, criteria)) shouldDelete = true;
                } catch (e) {
                }

                if (shouldDelete) {
                    deletedCount++;
                    if (table !== '_indexes' && parsedObj) {
                        if (this.db.indexManager) {
                            this.db.indexManager.removeFromIndexes(table, parsedObj);
                        } else {
                            this.db._removeFromIndexes(table, parsedObj);
                        }
                    }
                    deletedData.push(parsedObj);
                    pageModified = true;
                } else {
                    recordsToKeep.push({ len, data: pData.slice(offset + 2, offset + 2 + len) });
                }
                offset += 2 + len;
            }

            if (pageModified) {
                let writeOffset = 8;
                pData.writeUInt16LE(recordsToKeep.length, 4);

                for (let rec of recordsToKeep) {
                    pData.writeUInt16LE(rec.len, writeOffset);
                    rec.data.copy(pData, writeOffset + 2);
                    writeOffset += 2 + rec.len;
                }
                pData.writeUInt16LE(writeOffset, 6); // New free offset
                pData.fill(0, writeOffset); // Zero out rest

                this.db.pager.writePage(currentPageId, pData);
            }

            if (hintPageId !== -1) {
                break; // Optimized single page scan done
            }
            currentPageId = pData.readUInt32LE(0);
        }

        if (hintPageId !== -1 && deletedCount === 0) {
            return this.delete(table, criteria, true);
        }

        // BUG-3 FIX: DELETE harus memanggil OnTableDeleted, bukan OnTableInserted.
        // Memanggil OnTableInserted untuk DELETE menyebabkan CDC/trigger/replication
        // menerima data yang salah dan tidak bisa membedakan INSERT vs DELETE.
        if (this.db.dbevent && this.db.dbevent.OnTableDeleted) {
            this.db.dbevent.OnTableDeleted(table, deletedData, this.db.queryString);
        }

        return `Berhasil menggusur ${deletedCount} bibit.`;
    }
}

module.exports = DeleteExecutor;
