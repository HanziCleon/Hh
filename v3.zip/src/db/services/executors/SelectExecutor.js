const QueryExecutor = require('../QueryExecutor');
const JoinProcessor = require('../logic/JoinProcessor');
const ConditionEvaluator = require('../logic/ConditionEvaluator');

class SelectExecutor extends QueryExecutor {
    constructor(db) {
        super(db);
        this.joinProcessor = new JoinProcessor(db);
        this.conditionEvaluator = new ConditionEvaluator();
    }

    execute(cmd) {

        let rows = this._getRows(cmd);

        if (cmd.cols && !(cmd.cols.length === 1 && cmd.cols[0] === '*')) {
            rows = rows.map(r => {
                const newRow = {};
                cmd.cols.forEach(c => newRow[c] = r[c] !== undefined ? r[c] : null);
                return newRow;
            });
        }

        if (cmd.distinct) {
            const seen = new Set();
            rows = rows.filter(row => {
                const key = JSON.stringify(row);
                if (seen.has(key)) return false;
                seen.add(key);
                return true;
            });
        }

        if (this.db.dbevent && this.db.dbevent.OnTableSelected) {
            this.db.dbevent.OnTableSelected(cmd.table, rows, this.db.queryString);
        }

        return rows;
    }

    _getRows(cmd) {
        const { table, criteria, sort, limit, offset, joins } = cmd;

        let results = [];

        if (joins && joins.length > 0) {
            const entry = this.db.tableManager
                ? this.db.tableManager.findTableEntry(table)
                : this.db._findTableEntry(table);

            if (!entry) throw new Error(`Kebun '${table}' tidak ditemukan.`);

            const initialRows = this.db._scanTable ? this.db._scanTable(entry, null) : [];

            results = this.joinProcessor.process(table, initialRows, joins);

            if (criteria) {
                results = results.filter(r => this.conditionEvaluator.checkMatch(r, criteria));
            }

        } else {
            const entry = this.db.tableManager
                ? this.db.tableManager.findTableEntry(table)
                : this.db._findTableEntry(table);

            if (!entry) throw new Error(`Kebun '${table}' tidak ditemukan.`);

            if (criteria && criteria.op === '=' && !sort) {
                const indexKey = `${table}.${criteria.key}`;
                if (this.db.indexes.has(indexKey)) {
                    const index = this.db.indexes.get(indexKey);
                    results = index.search(criteria.val);
                } else {
                    const scanLimit = sort ? null : limit;
                    results = this.db._scanTable(entry, criteria, scanLimit);
                }
            } else {
                const scanLimit = sort ? null : limit;
                results = this.db._scanTable(entry, criteria, scanLimit);
            }
        }

        if (sort) {
            results.sort((a, b) => {
                const valA = a[sort.key];
                const valB = b[sort.key];
                if (valA < valB) return sort.dir === 'asc' ? -1 : 1;
                if (valA > valB) return sort.dir === 'asc' ? 1 : -1;
                return 0;
            });
        }

        let start = 0;
        let end = results.length;
        const offsetCount = offset; // cmd.offset might be undefined

        if (offsetCount) start = offsetCount;
        if (limit) end = start + limit;
        if (end > results.length) end = results.length;
        if (start > results.length) start = results.length;

        if (start !== 0 || end !== results.length) {
            results = results.slice(start, end);
        }

        return results;
    }
}

module.exports = SelectExecutor;
