const termObj = require('../QueryExecutor');
const QueryExecutor = require('../QueryExecutor');
const ConditionEvaluator = require('../logic/ConditionEvaluator');
const InsertExecutor = require('./InsertExecutor');
const DeleteExecutor = require('./DeleteExecutor');

class UpdateExecutor extends QueryExecutor {
    constructor(db) {
        super(db);
        this.conditionEvaluator = new ConditionEvaluator();
        this.insertExecutor = new InsertExecutor(db);
        this.deleteExecutor = new DeleteExecutor(db);
    }

    execute(cmd) {
        return this.update(cmd.table, cmd.updates, cmd.criteria);
    }

    update(table, updates, criteria) {
        const entry = this.db.tableManager
            ? this.db.tableManager.findTableEntry(table)
            : this.db._findTableEntry(table);

        if (!entry) throw new Error(`Kebun '${table}' tidak ditemukan.`);

        let hintPageId = -1;
        if (criteria && criteria.op === '=' && criteria.key) {
            const indexKey = `${table}.${criteria.key}`;
            if (this.db.indexes.has(indexKey)) {
                const index = this.db.indexes.get(indexKey);
                const searchRes = index.search(criteria.val);
                if (searchRes.length > 0 && searchRes[0]._pageId !== undefined) {
                    hintPageId = searchRes[0]._pageId;
                }
            }
        }

        let currentPageId = (hintPageId !== -1) ? hintPageId : entry.startPage;
        let updatedCount = 0;
        let updatedData = [];

        while (currentPageId !== 0) {
            let pData = this.db.pager.readPage(currentPageId);
            const count = pData.readUInt16LE(4);
            let offset = 8;
            let modified = false;

            for (let i = 0; i < count; i++) {
                const len = pData.readUInt16LE(offset);
                const jsonStr = pData.toString('utf8', offset + 2, offset + 2 + len);

                try {
                    const obj = JSON.parse(jsonStr);

                    if (this.conditionEvaluator.checkMatch(obj, criteria)) {
                        const originalObj = { ...obj };

                        for (const k in updates) {
                            obj[k] = updates[k];
                        }

                        Object.defineProperty(obj, '_pageId', {
                            value: currentPageId,
                            enumerable: false,
                            writable: true
                        });

                        if (this.db.indexManager) {
                            this.db.indexManager.updateIndexes(table, obj, originalObj);
                        } else {
                            this.db._updateIndexes(table, obj, originalObj);
                        }

                        const newJsonStr = JSON.stringify(obj);
                        const newLen = Buffer.byteLength(newJsonStr, 'utf8');

                        if (newLen <= len) {
                            pData.writeUInt16LE(newLen, offset);
                            pData.write(newJsonStr, offset + 2, newLen, 'utf8');
                            if (newLen < len) {
                                pData.fill(0, offset + 2 + newLen, offset + 2 + len);
                            }
                            modified = true;
                            updatedCount++;
                        } else {
                            this.deleteExecutor.delete(table, criteria);

                            this.insertExecutor.insertMany(table, [obj]);
                            updatedCount++;
                            break; // Exit loop as page structure changed
                        }

                        updatedData.push(obj);
                    }
                } catch (err) {
                }

                offset += 2 + len;
            }

            if (modified) {
                this.db.pager.writePage(currentPageId, pData);
            }

            if (hintPageId !== -1) break; // Scan only one page

            currentPageId = pData.readUInt32LE(0);
        }

        if (this.db.dbevent && this.db.dbevent.OnTableUpdated) {
            this.db.dbevent.OnTableUpdated(table, updatedData, this.db.queryString);
        }

        return `Berhasil memupuk ${updatedCount} bibit.`;
    }
}

module.exports = UpdateExecutor;
