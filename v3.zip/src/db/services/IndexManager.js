const BTreeIndex = require('../modules/BTreeIndex');

class IndexManager {
    constructor(db) {
        this.db = db;
    }

    get indexes() {
        return this.db.indexes;
    }

    createIndex(table, field) {
        const entry = this.db.tableManager
            ? this.db.tableManager.findTableEntry(table)
            : this.db._findTableEntry(table);

        if (!entry) throw new Error(`Kebun '${table}' tidak ditemukan.`);

        const indexKey = `${table}.${field}`;
        if (this.indexes.has(indexKey)) {
            return `Indeks pada '${table}.${field}' sudah ada.`;
        }

        const index = new BTreeIndex();
        index.name = indexKey;
        index.keyField = field;

        let allRecords = [];
        if (this.db._scanTable) {
            allRecords = this.db._scanTable(entry, null, null, true);
        } else if (this.db.query) {
            allRecords = this.db._scanTable(entry, null, null, true);
        }

        for (const record of allRecords) {
            if (record.hasOwnProperty(field)) {
                index.insert(record[field], record);
            }
        }

        this.indexes.set(indexKey, index);

        try {
            this.db._insert('_indexes', { table, field });
        } catch (e) {
            console.error("Failed to persist index definition", e);
        }

        return `Indeks dibuat pada '${table}.${field}' (${allRecords.length} records indexed)`;
    }

    updateIndexes(table, newObj, oldObj) {

        for (const [indexKey, index] of this.indexes) {
            const [tbl, field] = indexKey.split('.');
            if (tbl !== table) continue; // Wrong table

            if (oldObj && oldObj.hasOwnProperty(field)) {
                if (!newObj || newObj[field] !== oldObj[field]) {
                    index.delete(oldObj[field]);
                }
            }

            if (newObj && newObj.hasOwnProperty(field)) {
                if (!oldObj || newObj[field] !== oldObj[field]) {
                    index.insert(newObj[field], newObj);
                }
            }
        }
    }

    removeFromIndexes(table, data) {
        for (const [indexKey, index] of this.indexes) {
            const [tbl, field] = indexKey.split('.');
            if (tbl === table && data.hasOwnProperty(field)) {
                index.delete(data[field]); // Basic deletion from B-Tree
            }
        }
    }

    showIndexes(table) {
        if (table) {
            const indexes = [];
            for (const [key, index] of this.indexes) {
                if (key.startsWith(table + '.')) {
                    indexes.push(index.stats());
                }
            }
            return indexes.length > 0 ? indexes : `Tidak ada indeks pada '${table}'`;
        } else {
            const allIndexes = [];
            for (const index of this.indexes.values()) {
                allIndexes.push(index.stats());
            }
            return allIndexes;
        }
    }

    loadIndexes() {
        if (!this.db._select) return; // Wait until ready?

        let indexRecords = [];
        try {
            const entry = this.db.tableManager
                ? this.db.tableManager.findTableEntry('_indexes')
                : this.db._findTableEntry('_indexes');

            if (entry && this.db._scanTable) {
                indexRecords = this.db._scanTable(entry, null);
            }
        } catch (e) { return; }

        for (const rec of indexRecords) {
            const table = rec.table;
            const field = rec.field;
            const indexKey = `${table}.${field}`;

            if (!this.indexes.has(indexKey)) {
                const index = new BTreeIndex();
                index.name = indexKey;
                index.keyField = field;

                try {
                    const entry = this.db.tableManager
                        ? this.db.tableManager.findTableEntry(table)
                        : this.db._findTableEntry(table);

                    if (entry && this.db._scanTable) {
                        const allRecords = this.db._scanTable(entry, null, null, true); // true for Hints
                        for (const record of allRecords) {
                            if (record.hasOwnProperty(field)) {
                                index.insert(record[field], record);
                            }
                        }
                        this.indexes.set(indexKey, index);
                    }
                } catch (e) {
                    console.error(`Failed to rebuild index ${indexKey}: ${e.message}`);
                }
            }
        }
    }
}

module.exports = IndexManager;
