
/**
 * QueryParser handles tokenizing and parsing SQL-like commands
 * Returns a Command Object: { type, table, data, criteria, ... }
 */
class QueryParser {
    constructor() { }

    tokenize(sql) {
        const tokenRegex = /\s*(=>|!=|>=|<=|<>|[a-zA-Z_]\w*(?:\.[a-zA-Z_]\w*)?|@\w+|-?\d+(?:\.\d+)?|'(?:[^'\\]|\\.)*'|"(?:[^"\\]|\\.)*"|[(),=*.<>?])\s*/g;
        const tokens = [];
        let match;
        while ((match = tokenRegex.exec(sql)) !== null) {
            tokens.push(match[1]);
        }
        return tokens;
    }

    parse(queryString, params) {
        const tokens = this.tokenize(queryString);
        if (tokens.length === 0) return { type: 'EMPTY' };

        const cmd = tokens[0].toUpperCase();
        let command;

        try {
            switch (cmd) {
                case 'LAHAN':
                case 'CREATE':
                    if (tokens[1] && tokens[1].toUpperCase() === 'INDEX') {
                        command = this.parseCreateIndex(tokens);
                    } else if (tokens[1] && tokens[1].toUpperCase() === 'TRIGGER') {
                        command = this.parseCreateTrigger(tokens);
                    } else if (tokens[1] && tokens[1].toUpperCase() === 'PROCEDURE') {
                        command = this.parseSaveProcedure(tokens);
                    } else if (tokens[1] && tokens[1].toUpperCase() === 'VIEW') {
                        command = this.parseCreateView(tokens);
                    } else {
                        command = this.parseCreate(tokens);
                    }
                    break;
                case 'LIHAT':
                case 'SHOW':
                    command = this.parseShow(tokens);
                    break;
                case 'TANAM':
                case 'INSERT':
                    command = this.parseInsert(tokens);
                    break;
                case 'PANEN':
                case 'SELECT':
                    command = this.parseSelect(tokens);
                    break;
                case 'GUSUR':
                case 'DELETE':
                    command = this.parseDelete(tokens);
                    break;
                case 'PUPUK':
                case 'UPDATE':
                    command = this.parseUpdate(tokens);
                    break;
                case 'BAKAR':
                case 'DROP':
                    if (tokens[1] && tokens[1].toUpperCase() === 'TRIGGER') {
                        command = this.parseDropTrigger(tokens);
                    } else if (tokens[1] && tokens[1].toUpperCase() === 'PROCEDURE') {
                        command = this.parseDropProcedure(tokens);
                    } else if (tokens[1] && tokens[1].toUpperCase() === 'VIEW') {
                        command = this.parseDropView(tokens);
                    } else {
                        command = this.parseDrop(tokens);
                    }
                    break;
                case 'INDEKS':
                    command = this.parseCreateIndex(tokens);
                    break;
                case 'HITUNG':
                    command = this.parseAggregate(tokens);
                    break;
                case 'EXPLAIN':
                case 'JELASKAN':
                    command = this.parseExplain(tokens);
                    break;
                case 'MULAI':
                    command = this.parseBeginTransaction(tokens);
                    break;
                case 'BEGIN':
                    command = { type: 'BEGIN_TRANSACTION' };
                    break;
                case 'SAHKAN':
                case 'COMMIT':
                    command = { type: 'COMMIT' };
                    break;
                case 'BATALKAN':
                case 'ROLLBACK':
                    command = { type: 'ROLLBACK' };
                    break;
                case 'PASANG':
                    if (tokens[1] && tokens[1].toUpperCase() === 'KENTONGAN') {
                        command = this.parseCreateTrigger(tokens);
                    } else {
                        command = this.parseCreateView(tokens);
                    }
                    break;
                case 'BUANG':
                    if (tokens[1] && tokens[1].toUpperCase() === 'KENTONGAN') {
                        command = this.parseDropTrigger(tokens);
                    } else if (tokens[1] && tokens[1].toUpperCase() === 'SOP') {
                        command = this.parseDropProcedure(tokens);
                    } else {
                        command = this.parseDropView(tokens);
                    }
                    break;
                case 'SIMPAN':
                    command = this.parseSaveProcedure(tokens);
                    break;
                case 'JALANKAN':
                    command = this.parseExecuteProcedure(tokens);
                    break;
                case 'SETEL':
                case 'CONFIGURE':
                    command = this.parseReplication(tokens);
                    break;
                case 'EXECUTE':
                    command = this.parseExecuteProcedure(tokens);
                    break;
                case 'BLUSUKAN':
                case 'FULLTEXT':
                case 'SEARCH':
                    command = this.parseSearch(tokens);
                    break;
                case 'BERI':
                case 'GRANT':
                    command = this.parseGrant(tokens);
                    break;
                case 'CABUT':
                case 'REVOKE':
                    command = this.parseRevoke(tokens);
                    break;
                default:
                    throw new Error(`Perintah tidak dikenal: ${cmd}`);
            }

            if (params) {
                this._bindParameters(command, params);
            }
            return command;
        } catch (e) {
            return { type: 'ERROR', message: e.message };
        }
    }

    parseSearch(tokens) {

        let i = 1;
        let table;

        if (tokens[0].toUpperCase() === 'BLUSUKAN') {
            if (tokens[1].toUpperCase() === 'KE') i++;
        }

        table = tokens[i];
        i++;

        if (tokens[i] === '(') {
            while (tokens[i] !== ')') i++; // Skip columns def
            i++;
        }

        if (tokens[i] && tokens[i].toUpperCase() === 'CARI') i++;

        const term = tokens[i];
        if (!term) throw new Error("Syntax: BLUSUKAN KE [table] CARI \"term\" | SEARCH [table] \"term\"");

        let cleanTerm = term;
        if ((term.startsWith('"') && term.endsWith('"')) || (term.startsWith("'") && term.endsWith("'"))) {
            cleanTerm = term.slice(1, -1);
        }

        return { type: 'FULLTEXT_SEARCH', table, term: cleanTerm };
    }

    parseGrant(tokens) {

        let i = 1;
        if (tokens[0].toUpperCase() === 'BERI' && tokens[1].toUpperCase() === 'IZIN') i = 2;

        const action = tokens[i]; // read, write, all
        i++;

        let user;
        let table;

        while (i < tokens.length) {
            const token = tokens[i].toUpperCase();
            if (token === 'ON' || token === 'DI') {
                i++;
                table = tokens[i];
            } else if (token === 'TO' || token === 'KEPADA') {
                i++;
                user = tokens[i];
            }
            i++;
        }

        if (!user || !table) throw new Error("Syntax: GRANT [action] ON [table] TO [user] | BERI IZIN ... KEPADA ... DI ...");

        return { type: 'GRANT_PERMISSION', user, table, action };
    }

    parseRevoke(tokens) {

        let i = 1;
        if (tokens[0].toUpperCase() === 'CABUT' && tokens[1].toUpperCase() === 'IZIN') i = 2;

        const action = tokens[i];
        i++;

        let user;
        let table;

        while (i < tokens.length) {
            const token = tokens[i].toUpperCase();
            if (token === 'ON' || token === 'DI') {
                i++;
                table = tokens[i];
            } else if (token === 'FROM' || token === 'DARI') {
                i++;
                user = tokens[i];
            }
            i++;
        }

        if (!user || !table) throw new Error("Syntax: REVOKE [action] ON [table] FROM [user]");

        return { type: 'REVOKE_PERMISSION', user, table, action };
    }

    parseCreate(tokens) {
        let name;
        if (tokens[0].toUpperCase() === 'CREATE') {
            if (tokens[1].toUpperCase() !== 'TABLE') throw new Error("Syntax: CREATE TABLE [name]");
            name = tokens[2];
        } else {
            if (tokens.length < 2) throw new Error("Syntax: LAHAN [nama_kebun]");
            name = tokens[1];
        }
        return { type: 'CREATE_TABLE', table: name };
    }

    parseShow(tokens) {
        const cmd = tokens[0].toUpperCase();
        const sub = tokens[1] ? tokens[1].toUpperCase() : '';

        if (cmd === 'LIHAT') {
            if (sub === 'LAHAN') return { type: 'SHOW_TABLES' };
            if (sub === 'INDEKS') return { type: 'SHOW_INDEXES', table: tokens[2] || null };
        } else if (cmd === 'SHOW') {
            if (sub === 'TABLES') return { type: 'SHOW_TABLES' };
            if (sub === 'INDEXES') return { type: 'SHOW_INDEXES', table: tokens[2] || null };
        }

        throw new Error("Syntax: LIHAT LAHAN | SHOW TABLES | LIHAT INDEKS [table] | SHOW INDEXES");
    }

    parseDrop(tokens) {
        if (tokens[0].toUpperCase() === 'DROP') {
            if (tokens[1] && tokens[1].toUpperCase() === 'TABLE') {
                return { type: 'DROP_TABLE', table: tokens[2] };
            }
        } else if (tokens[0].toUpperCase() === 'BAKAR') {
            if (tokens[1] && tokens[1].toUpperCase() === 'LAHAN') {
                return { type: 'DROP_TABLE', table: tokens[2] };
            }
        }
        throw new Error("Syntax: BAKAR LAHAN [nama] | DROP TABLE [nama]");
    }

    parseInsert(tokens) {
        let i = 1;
        let table;

        if (tokens[0].toUpperCase() === 'INSERT') {
            if (tokens[1].toUpperCase() !== 'INTO') throw new Error("Syntax: INSERT INTO [table] ...");
            i = 2;
        } else {
            if (tokens[1].toUpperCase() !== 'KE') throw new Error("Syntax: TANAM KE [kebun] ...");
            i = 2;
        }

        table = tokens[i];
        i++;

        const cols = [];
        if (tokens[i] === '(') {
            i++;
            while (tokens[i] !== ')') {
                if (tokens[i] !== ',') cols.push(tokens[i]);
                i++;
                if (i >= tokens.length) throw new Error("Unclosed parenthesis in columns");
            }
            i++;
        } else {
            throw new Error("Syntax: ... [table] (col1, ...) ...");
        }

        const valueKeyword = tokens[i].toUpperCase();
        if (valueKeyword !== 'BIBIT' && valueKeyword !== 'VALUES') throw new Error("Expected BIBIT or VALUES");
        i++;

        const vals = [];
        if (tokens[i] === '(') {
            i++;
            while (tokens[i] !== ')') {
                if (tokens[i] !== ',') {
                    let val = tokens[i];
                    if (val.startsWith("'") || val.startsWith('"')) val = val.slice(1, -1);
                    else if (val.toUpperCase() === 'NULL') val = null;
                    else if (val.toUpperCase() === 'TRUE') val = true;
                    else if (val.toUpperCase() === 'FALSE') val = false;
                    else if (!isNaN(val)) val = Number(val);
                    vals.push(val);
                }
                i++;
            }
        } else {
            throw new Error("Syntax: ... VALUES (val1, ...)");
        }

        if (cols.length !== vals.length) throw new Error("Columns and Values count mismatch");

        const data = {};
        for (let k = 0; k < cols.length; k++) {
            data[cols[k]] = vals[k];
        }

        return { type: 'INSERT', table, data };
    }

    parseSelect(tokens) {
        let i = 1;

        let distinct = false;
        if (tokens[i] && tokens[i].toUpperCase() === 'DISTINCT') {
            distinct = true;
            i++;
        }

        const cols = [];
        while (i < tokens.length && !['DARI', 'FROM'].includes(tokens[i].toUpperCase())) {
            if (tokens[i] !== ',') cols.push(tokens[i]);
            i++;
        }

        if (i >= tokens.length) throw new Error("Expected DARI or FROM");
        i++;

        const table = tokens[i];
        i++;

        const joins = [];
        while (i < tokens.length) {
            const token = tokens[i].toUpperCase();

            let joinType = null;

            if (token === 'JOIN' || token === 'GABUNG') {
                if (token === 'GABUNG') {
                    const next = tokens[i + 1] ? tokens[i + 1].toUpperCase() : '';
                    if (['KIRI', 'KANAN', 'SILANG', 'PENUH'].includes(next)) {
                        i++; // Skip GABUNG, let next iteration handle direction
                        continue;
                    }
                }
                joinType = 'INNER';
                i++;
            } else if (token === 'INNER') {
                i++;
                if (tokens[i] && ['JOIN', 'GABUNG'].includes(tokens[i].toUpperCase())) {
                    joinType = 'INNER';
                    i++;
                }
            } else if (token === 'LEFT' || token === 'KIRI') {
                joinType = 'LEFT'; // Set default
                i++;
                if (tokens[i] && tokens[i].toUpperCase() === 'OUTER') i++;
                if (tokens[i] && ['JOIN', 'GABUNG'].includes(tokens[i].toUpperCase())) {
                    i++;
                }
            } else if (token === 'RIGHT' || token === 'KANAN') {
                joinType = 'RIGHT'; // Set default
                i++;
                if (tokens[i] && tokens[i].toUpperCase() === 'OUTER') i++;
                if (tokens[i] && ['JOIN', 'GABUNG'].includes(tokens[i].toUpperCase())) {
                    i++;
                }
            } else if (token === 'FULL' || token === 'PENUH') {
                joinType = 'FULL'; // Set default
                i++;
                if (tokens[i] && tokens[i].toUpperCase() === 'OUTER') i++;
                if (tokens[i] && ['JOIN', 'GABUNG'].includes(tokens[i].toUpperCase())) {
                    i++;
                }
            } else if (token === 'CROSS' || token === 'SILANG') {
                joinType = 'CROSS'; // Set default
                i++;
                if (tokens[i] && ['JOIN', 'GABUNG'].includes(tokens[i].toUpperCase())) {
                    i++;
                }
            } else {
                break;
            }

            if (!joinType) break;

            const joinTable = tokens[i];
            i++;

            if (joinType === 'CROSS') {
                joins.push({ table: joinTable, type: joinType, on: null });
                continue;
            }

            if (i >= tokens.length || !['ON', 'PADA'].includes(tokens[i].toUpperCase())) {
                throw new Error(`Syntax: ${joinType} JOIN [table] ON [condition]`);
            }
            i++; // Skip ON/PADA

            const left = tokens[i];
            i++;
            const op = tokens[i];
            i++;
            const right = tokens[i];
            i++;

            joins.push({ table: joinTable, type: joinType, on: { left, op, right } });
        }

        let criteria = null;
        if (i < tokens.length && ['DIMANA', 'WHERE'].includes(tokens[i].toUpperCase())) {
            i++;
            criteria = this.parseWhere(tokens, i);
            while (i < tokens.length &&
                !['ORDER', 'URUTKAN', 'LIMIT', 'HANYA', 'OFFSET', 'MULAI'].includes(tokens[i].toUpperCase())) {
                i++;
            }
        }

        let sort = null;
        if (i < tokens.length) {
            const token = tokens[i].toUpperCase();
            if (token === 'ORDER') {
                i++;
                if (tokens[i].toUpperCase() === 'BY') i++;
            } else if (token === 'URUTKAN') {
                i++;
                if (tokens[i].toUpperCase() === 'BERDASARKAN') i++;
            }

            if (i < tokens.length && (tokens[i - 1].toUpperCase() === 'BY' || tokens[i - 1].toUpperCase() === 'BERDASARKAN')) {
                const key = tokens[i];
                i++;
                let dir = 'asc';
                if (i < tokens.length && ['ASC', 'DESC', 'NAIK', 'TURUN'].includes(tokens[i].toUpperCase())) {
                    const d = tokens[i].toUpperCase();
                    dir = (d === 'DESC' || d === 'TURUN') ? 'desc' : 'asc';
                    i++;
                }
                sort = { key, dir };
            }
        }

        let limit = null;
        let offset = null;

        if (i < tokens.length && ['LIMIT', 'HANYA'].includes(tokens[i].toUpperCase())) {
            i++;
            limit = parseInt(tokens[i], 10);
            i++;
        }

        if (i < tokens.length) {
            const token = tokens[i].toUpperCase();
            if (token === 'OFFSET' || token === 'LANGKAHI') {
                i++;
                offset = parseInt(tokens[i], 10);
                i++;
            } else if (token === 'MULAI') {
                i++;
                if (tokens[i] && tokens[i].toUpperCase() === 'DARI') i++;
                offset = parseInt(tokens[i], 10);
                i++;
            }
        }

        return { type: 'SELECT', table, cols, joins, criteria, sort, limit, offset, distinct };
    }

    parseWhere(tokens, startIndex) {
        const simpleConditions = [];
        let i = startIndex;

        while (i < tokens.length) {
            const token = tokens[i];
            const upper = token ? token.toUpperCase() : '';

            if (['AND', 'OR', 'DAN', 'ATAU'].includes(upper)) {
                const op = (upper === 'DAN') ? 'AND' : (upper === 'ATAU') ? 'OR' : upper;
                simpleConditions.push({ type: 'logic', op });
                i++;
                continue;
            }

            if (['DENGAN', 'ORDER', 'URUTKAN', 'LIMIT', 'HANYA', 'OFFSET', 'MULAI', 'LANGKAHI', 'GROUP', 'KELOMPOK', ')', ';'].includes(upper)) {
                break;
            }

            if (i < tokens.length - 1) {
                const key = tokens[i];
                const rawOp = tokens[i + 1].toUpperCase();
                let op = rawOp;

                if (rawOp === 'SEPERTI') op = 'LIKE';

                let val = null;
                let consumed = 2;

                if (op === 'BETWEEN' || op === 'ANTARA') {
                    op = 'BETWEEN'; // Standardize
                    let v1 = tokens[i + 2];
                    let v2 = tokens[i + 4];
                    if (v1 && (v1.startsWith("'") || v1.startsWith('"'))) v1 = v1.slice(1, -1);
                    else if (!isNaN(v1)) v1 = Number(v1);

                    if (v2 && (v2.startsWith("'") || v2.startsWith('"'))) v2 = v2.slice(1, -1);
                    else if (!isNaN(v2)) v2 = Number(v2);

                    simpleConditions.push({ type: 'cond', key, op: 'BETWEEN', val: [v1, v2] });
                    consumed = 5;
                    const connector = tokens[i + 3].toUpperCase();
                    if (connector !== 'AND' && connector !== 'DAN') throw new Error("Syntax: ... BETWEEN val1 AND val2");

                } else if (op === 'IS') { // ADALAH?
                    const next = tokens[i + 2].toUpperCase();
                    if (next === 'NULL' || next === 'KOSONG') {
                        simpleConditions.push({ type: 'cond', key, op: 'IS NULL', val: null });
                        consumed = 3;
                    } else if (next === 'NOT' || next === 'TIDAK') {
                        const next2 = tokens[i + 3].toUpperCase();
                        if (next2 === 'NULL' || next2 === 'KOSONG') {
                            simpleConditions.push({ type: 'cond', key, op: 'IS NOT NULL', val: null });
                            consumed = 4;
                        } else { throw new Error("Syntax: IS NOT NULL"); }
                    } else { throw new Error("Syntax: IS NULL or IS NOT NULL"); }

                } else if (op === 'IN' || op === 'DALAM') {
                    const isNot = (rawOp === 'NOT' || rawOp === 'TIDAK'); // Wait, op is IN/DALAM here
                }

                if (key.toUpperCase() === 'NOT' || key.toUpperCase() === 'TIDAK') {
                }

                if (op === 'IN' || op === 'DALAM' || op === 'NOT' || op === 'TIDAK') {
                    if (op === 'NOT' || op === 'TIDAK') {
                        const next = tokens[i + 2].toUpperCase();
                        if (next !== 'IN' && next !== 'DALAM') break; // Not valid
                        consumed++;
                    }
                    let p = (op === 'NOT' || op === 'TIDAK') ? i + 3 : i + 2;
                    let values = [];
                    if (tokens[p] === '(') {
                        p++;
                        while (tokens[p] !== ')') {
                            if (tokens[p] !== ',') {
                                let v = tokens[p];
                                if (v.startsWith("'") || v.startsWith('"')) v = v.slice(1, -1);
                                else if (!isNaN(v)) v = Number(v);
                                values.push(v);
                            }
                            p++;
                            if (p >= tokens.length) break;
                        }
                        val = values;
                        consumed = (p - i) + 1;
                    }
                    const finalOp = (op === 'NOT' || op === 'TIDAK') ? 'NOT IN' : 'IN';
                    simpleConditions.push({ type: 'cond', key, op: finalOp, val });
                } else {
                    val = tokens[i + 2];
                    if (val && (val.startsWith("'") || val.startsWith('"'))) {
                        val = val.slice(1, -1);
                    } else if (val && !isNaN(val)) {
                        val = Number(val);
                    }
                    simpleConditions.push({ type: 'cond', key, op, val });
                    consumed = 3;
                }
                i += consumed;
            } else {
                break;
            }
        }

        if (simpleConditions.length === 0) return null;

        const pass1 = [];
        let current = simpleConditions[0];

        for (let k = 1; k < simpleConditions.length; k += 2) {
            const logic = simpleConditions[k]; // { type: 'logic', op: 'AND' }
            const nextCond = simpleConditions[k + 1];

            if (logic.op === 'AND') {
                if (current.type === 'compound' && current.logic === 'AND') {
                    current.conditions.push(nextCond);
                } else {
                    current = { type: 'compound', logic: 'AND', conditions: [current, nextCond] };
                }
            } else {
                pass1.push(current);
                pass1.push(logic);
                current = nextCond;
            }
        }
        pass1.push(current);

        if (pass1.length === 1) return pass1[0];

        const finalConditions = [];
        for (let k = 0; k < pass1.length; k += 2) {
            finalConditions.push(pass1[k]);
        }

        return { type: 'compound', logic: 'OR', conditions: finalConditions };
    }

    parseDelete(tokens) {
        let table;
        let i;

        if (tokens[0].toUpperCase() === 'DELETE') {
            if (tokens[1].toUpperCase() !== 'FROM') throw new Error("Syntax: DELETE FROM [table] ...");
            table = tokens[2];
            i = 3;
        } else {
            if (tokens[1].toUpperCase() !== 'DARI') throw new Error("Syntax: GUSUR DARI [kebun] ...");
            table = tokens[2];
            i = 3;
        }

        let criteria = null;
        if (i < tokens.length && ['DIMANA', 'WHERE'].includes(tokens[i].toUpperCase())) {
            i++;
            criteria = this.parseWhere(tokens, i);
        }

        return { type: 'DELETE', table, criteria };
    }

    parseUpdate(tokens) {
        let table;
        let i;

        if (tokens[0].toUpperCase() === 'UPDATE') {
            table = tokens[1];
            if (tokens[2].toUpperCase() !== 'SET') throw new Error("Expected SET");
            i = 3;
        } else {
            if (tokens.length < 3) throw new Error("Syntax: PUPUK [kebun] DENGAN ...");
            table = tokens[1];
            if (tokens[2].toUpperCase() !== 'DENGAN') throw new Error("Expected DENGAN");
            i = 3;
        }

        const updates = {};
        while (i < tokens.length && !['DIMANA', 'WHERE'].includes(tokens[i].toUpperCase())) {
            if (tokens[i] === ',') { i++; continue; }
            const key = tokens[i];
            if (tokens[i + 1] !== '=') throw new Error("Syntax: key=value in update list");
            let val = tokens[i + 2];
            if (val.startsWith("'") || val.startsWith('"')) val = val.slice(1, -1);
            else if (!isNaN(val)) val = Number(val);
            updates[key] = val;
            i += 3;
        }

        let criteria = null;
        if (i < tokens.length && ['DIMANA', 'WHERE'].includes(tokens[i].toUpperCase())) {
            i++;
            criteria = this.parseWhere(tokens, i);
        }
        return { type: 'UPDATE', table, updates, criteria };
    }

    parseCreateIndex(tokens) {

        if (tokens[0].toUpperCase() === 'CREATE' && tokens[1].toUpperCase() === 'INDEX') {
            let i = 2;

            if (tokens[i].toUpperCase() !== 'ON' && tokens[i + 1] && tokens[i + 1].toUpperCase() === 'ON') {
                i++; // Skip name
            }

            if (tokens[i].toUpperCase() !== 'ON') throw new Error("Syntax: CREATE INDEX ... ON [table] ...");
            i++;

            const table = tokens[i];
            i++;

            if (tokens[i] !== '(') throw new Error("Syntax: ... ON [table] ( [field] )");
            i++;

            const field = tokens[i];
            i++;

            if (tokens[i] !== ')') throw new Error("Unclosed parenthesis for index field");

            return { type: 'CREATE_INDEX', table, field };
        }

        if (tokens.length < 4) throw new Error("Syntax: INDEKS [table] PADA [field]");
        const table = tokens[1];
        if (tokens[2].toUpperCase() !== 'PADA') throw new Error("Expected PADA");
        const field = tokens[3];
        return { type: 'CREATE_INDEX', table, field };
    }

    parseAggregate(tokens) {
        let i = 1;

        const aggFunc = tokens[i].toUpperCase();
        i++;

        if (tokens[i] !== '(') throw new Error("Syntax: HITUNG FUNC(field) ...");
        i++;

        const aggField = tokens[i] === '*' ? null : tokens[i];
        i++;

        if (tokens[i] !== ')') throw new Error("Expected closing parenthesis");
        i++;

        if (!tokens[i] || (tokens[i].toUpperCase() !== 'DARI' && tokens[i].toUpperCase() !== 'FROM')) {
            throw new Error("Expected DARI or FROM");
        }
        i++;

        const table = tokens[i];
        i++;

        let criteria = null;
        if (i < tokens.length && ['DIMANA', 'WHERE'].includes(tokens[i].toUpperCase())) {
            i++;
            criteria = this.parseWhere(tokens, i);
            while (i < tokens.length && !['KELOMPOK', 'GROUP', 'DENGAN', 'HAVING'].includes(tokens[i].toUpperCase())) {
                i++;
            }
        }

        let groupField = null;
        if (i < tokens.length && ['KELOMPOK', 'GROUP'].includes(tokens[i].toUpperCase())) {
            if (tokens[i].toUpperCase() === 'GROUP' && tokens[i + 1].toUpperCase() === 'BY') {
                i += 2;
            } else {
                i++; // KELOMPOK
            }
            groupField = tokens[i];
            i++;
        }

        let having = null;
        if (i < tokens.length) {
            const token = tokens[i].toUpperCase();
            let isHaving = false;

            if (token === 'HAVING' || token === 'PUNYA') {
                isHaving = true;
                i++;
            } else if (token === 'DENGAN' && tokens[i + 1] && tokens[i + 1].toUpperCase() === 'SYARAT') {
                isHaving = true;
                i += 2;
            }

            if (isHaving) {
                const havingField = tokens[i];
                i++;
                const havingOp = tokens[i];
                i++;
                let havingVal = tokens[i];
                if (!isNaN(Number(havingVal))) {
                    havingVal = Number(havingVal);
                }
                having = { field: havingField, op: havingOp, val: havingVal };
            }
        }

        return { type: 'AGGREGATE', table, func: aggFunc, field: aggField, criteria, groupBy: groupField, having };
    }
    _bindParameters(command, params) {
        if (!command) return;

        const bindValue = (val) => {
            if (typeof val === 'string' && val.startsWith('@')) {
                const paramName = val.substring(1); // remove @
                if (params && params.hasOwnProperty(paramName)) {
                    return params[paramName];
                } else if (Array.isArray(params)) {
                    return val;
                }
            }
            return val;
        };

        if (command.criteria) {
            this._info_bindCriteria(command.criteria, bindValue);
        }

        if (command.data) {
            for (const key in command.data) {
                command.data[key] = bindValue(command.data[key]);
            }
        }

        if (command.updates) {
            for (const key in command.updates) {
                command.updates[key] = bindValue(command.updates[key]);
            }
        }
    }

    _info_bindCriteria(criteria, bindFunc) {
        if (criteria.type === 'compound') {
            for (const cond of criteria.conditions) {
                this._info_bindCriteria(cond, bindFunc);
            }
        } else {
            if (Array.isArray(criteria.val)) {
                criteria.val = criteria.val.map(v => bindFunc(v));
            } else {
                criteria.val = bindFunc(criteria.val);
            }
        }
    }

    parseCreateTrigger(tokens) {

        let i = 0;
        let name, event, table;

        if (tokens[0].toUpperCase() === 'PASANG') {
            i = 2; // PASANG KENTONGAN
            name = tokens[i]; i++;
            if (tokens[i].toUpperCase() !== 'PADA') throw new Error("Syntax: PASANG KENTONGAN [nama] PADA ...");
            i++;
        } else {
            i = 2; // CREATE TRIGGER
            name = tokens[i]; i++;
            if (tokens[i].toUpperCase() !== 'ON') throw new Error("Syntax: CREATE TRIGGER [name] ON ...");
            i++;
        }

        event = tokens[i].toUpperCase(); i++;
        table = tokens[i]; i++;

        if (tokens[i].toUpperCase() !== 'LAKUKAN' && tokens[i].toUpperCase() !== 'DO') {
            throw new Error("Syntax: ... LAKUKAN/DO [query]");
        }
        i++;

        const action = tokens.slice(i).join(' ');

        return { type: 'CREATE_TRIGGER', name, event, table, action };
    }

    parseDropTrigger(tokens) {
        return { type: 'DROP_TRIGGER', name: tokens[2] };
    }

    parseSaveProcedure(tokens) {
        let name;
        let i = 0;

        if (tokens[0].toUpperCase() === 'SIMPAN') {
            name = tokens[2];
            i = 3;
            if (tokens[i].toUpperCase() !== 'SEBAGAI') throw new Error("Syntax: SEBAGAI");
        } else {
            name = tokens[2];
            i = 3;
            if (tokens[i].toUpperCase() !== 'AS') throw new Error("Syntax: AS");
        }
        i++; // Skip SEBAGAI/AS

        const body = tokens.slice(i).join(' ');

        return { type: 'SAVE_PROCEDURE', name, body };
    }

    parseExecuteProcedure(tokens) {
        return { type: 'EXECUTE_PROCEDURE', name: tokens[2] };
    }

    parseDropProcedure(tokens) {
        return { type: 'DROP_PROCEDURE', name: tokens[2] };
    }

    parseReplication(tokens) {

        let i = 0;
        if (tokens[0].toUpperCase() === 'SETEL') {
            if (tokens[1].toUpperCase() !== 'CABANG') throw new Error("Check Syntax SETEL CABANG");
            i = 2;
        } else {
            if (tokens[1].toUpperCase() !== 'REPLICATION') throw new Error("Check Syntax CONFIGURE REPLICATION");
            i = 2;
        }

        if (tokens[i].toUpperCase() !== 'SEBAGAI' && tokens[i].toUpperCase() !== 'AS') {
            throw new Error("Expected SEBAGAI / AS");
        }
        i++;

        const role = tokens[i].toUpperCase();
        i++;
        const host = tokens[i] || null;
        i++;
        const port = tokens[i] || null;

        return { type: 'CONFIGURE_REPLICATION', role, host, port };
    }

    parseExplain(tokens) {
        const innerTokens = tokens.slice(1);
        if (innerTokens.length === 0) {
            throw new Error("EXPLAIN requires a query to analyze");
        }

        const innerCmd = innerTokens[0].toUpperCase();
        let innerCommand;

        switch (innerCmd) {
            case 'PANEN':
            case 'SELECT':
                innerCommand = this.parseSelect(innerTokens);
                break;
            case 'GUSUR':
            case 'DELETE':
                innerCommand = this.parseDelete(innerTokens);
                break;
            case 'PUPUK':
            case 'UPDATE':
                innerCommand = this.parseUpdate(innerTokens);
                break;
            case 'HITUNG':
                innerCommand = this.parseAggregate(innerTokens);
                break;
            default:
                throw new Error(`EXPLAIN not supported for: ${innerCmd}`);
        }

        return { type: 'EXPLAIN', innerCommand };
    }

    parseBeginTransaction(tokens) {
        if (tokens[0].toUpperCase() === 'MULAI') {
            if (tokens[1] && tokens[1].toUpperCase() === 'AKAD') {
                return { type: 'BEGIN_TRANSACTION' };
            }
            throw new Error("Syntax: MULAI AKAD");
        }
        return { type: 'BEGIN_TRANSACTION' };
    }

    parseCreateView(tokens) {
        if (tokens[0].toUpperCase() !== 'PASANG') {
            throw new Error("Syntax: PASANG TEROPONG [nama] SEBAGAI [query]");
        }

        if (tokens[1].toUpperCase() !== 'TEROPONG') {
            throw new Error("Expected TEROPONG after PASANG");
        }

        const viewName = tokens[2];
        if (!viewName) {
            throw new Error("View name required");
        }

        if (tokens[3].toUpperCase() !== 'SEBAGAI') {
            throw new Error("Expected SEBAGAI after view name");
        }

        const selectTokens = tokens.slice(4);
        const selectCommand = this.parseSelect(selectTokens);

        return { type: 'CREATE_VIEW', viewName, selectCommand };
    }

    parseDropView(tokens) {
        if (tokens[0].toUpperCase() !== 'BUANG') {
            throw new Error("Syntax: BUANG TEROPONG [nama]");
        }

        if (tokens[1].toUpperCase() !== 'TEROPONG') {
            throw new Error("Expected TEROPONG after BUANG");
        }

        const viewName = tokens[2];
        if (!viewName) {
            throw new Error("View name required");
        }

        return { type: 'DROP_VIEW', viewName };
    }
}

module.exports = QueryParser;
