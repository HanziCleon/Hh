/**
 * ⚠️  DEAD CODE / LEGACY — JANGAN DIGUNAKAN
 *
 * Bagian dari engine lama (DongtubeEngine). Sudah digantikan oleh JsonDB.js.
 * Menggunakan CommonJS (require/module.exports) — tidak kompatibel dengan ESM project ini.
 * Tidak diimport di manapun dalam codebase aktif.
 */
const fs = require('fs');

const PAGE_SIZE = 4096;
const MAGIC = 'DTDB';

/**
 * Pager handles 4KB page I/O
 * Includes LRU Cache + Object Cache
 *
 * FIXES v3 → v4:
 *  FIX-A: _flushPage() → flush() memanggil fsyncSync satu kali setelah semua
 *          dirty pages ditulis. Data benar-benar sampai ke disk fisik.
 *  FIX-B: LRU eviction sekarang cek JUGA dirtyObjects sebelum evict
 *          → data di objectCache tidak hilang diam-diam saat cache penuh.
 *  FIX-C: writePage() sekarang baca disk langsung jika page belum di cache
 *          → beforeImage untuk WAL selalu akurat (tidak pernah sama dengan afterImage).
 *  FIX-D: _readPageFromDisk() helper — baca page dari disk tanpa pollute cache.
 */
class Pager {
    constructor(filePath, wal = null) {
        this.filePath = filePath;
        this.fd = null;
        this.cache = new Map();
        this.cacheLimit = 15000;
        this.wal = wal;

        this.dirtyPages = new Set();
        this.lazyWrite = true;

        this.bufferPool = [];
        this.maxPoolSize = 1000;

        this.objectCache = new Map();
        this.dirtyObjects = new Set();

        this._open();
    }

    _open() {
        if (!fs.existsSync(this.filePath)) {
            this.fd = fs.openSync(this.filePath, 'w+');
            this._initNewFile();
        } else {
            this.fd = fs.openSync(this.filePath, 'r+');
        }
    }

    _initNewFile() {
        const buf = Buffer.alloc(PAGE_SIZE);
        buf.write(MAGIC, 0);
        buf.writeUInt32LE(1, 4); // Total Pages = 1
        buf.writeUInt32LE(0, 8); // Num Tables = 0
        fs.writeSync(this.fd, buf, 0, PAGE_SIZE, 0);
        try { fs.fsyncSync(this.fd); } catch (_) {}
    }

    _allocBuffer() {
        if (this.bufferPool.length > 0) {
            const buf = this.bufferPool.pop();
            buf.fill(0);
            return buf;
        }
        return Buffer.alloc(PAGE_SIZE);
    }

    _releaseBuffer(buf) {
        if (this.bufferPool.length < this.maxPoolSize) {
            this.bufferPool.push(buf);
        }
    }

    /**
     * FIX-D: Baca page langsung dari disk tanpa memasukkan ke cache.
     * Digunakan oleh writePage() untuk mendapatkan beforeImage yang akurat.
     * Jika page belum ada di disk (page baru), kembalikan buffer zeroed.
     */
    _readPageFromDisk(pageId) {
        const buf = Buffer.alloc(PAGE_SIZE);
        const offset = pageId * PAGE_SIZE;
        try {
            const stats = fs.fstatSync(this.fd);
            if (offset + PAGE_SIZE <= stats.size) {
                fs.readSync(this.fd, buf, 0, PAGE_SIZE, offset);
            }
        } catch (_) {
            // Gagal baca → anggap page baru → kembalikan zeroed buffer
        }
        return buf;
    }

    readPageObjects(pageId) {
        if (this.objectCache.has(pageId)) {
            const entry = this.objectCache.get(pageId);
            this.objectCache.delete(pageId);
            this.objectCache.set(pageId, entry);
            return entry;
        }

        const buffer = this.readPage(pageId);
        const next  = buffer.readUInt32LE(0);
        const count = buffer.readUInt16LE(4);

        const items = [];
        let offset = 8;

        for (let i = 0; i < count; i++) {
            if (offset + 2 > PAGE_SIZE) break;
            const len = buffer.readUInt16LE(offset);
            if (offset + 2 + len > PAGE_SIZE) {
                console.warn(`[Pager] readPageObjects page=${pageId} item=${i}: len=${len} melebihi batas page, berhenti`);
                break;
            }
            const jsonStr = buffer.toString('utf8', offset + 2, offset + 2 + len);
            try {
                const obj = JSON.parse(jsonStr);
                items.push(obj);
            } catch (e) {
                console.warn(`[Pager] readPageObjects page=${pageId} item=${i}: JSON parse gagal — skip`);
            }
            offset += 2 + len;
        }

        const entry = { next, items };
        this.objectCache.set(pageId, entry);
        return entry;
    }

    _serializeObjectsToBuffer(pageId) {
        if (!this.objectCache.has(pageId)) return;

        const entry  = this.objectCache.get(pageId);
        const buffer = Buffer.alloc(PAGE_SIZE);

        buffer.writeUInt32LE(entry.next, 0);

        let offset = 8;
        let written = 0;

        for (let i = 0; i < entry.items.length; i++) {
            const obj     = entry.items[i];
            const jsonStr = JSON.stringify(obj);
            const len     = Buffer.byteLength(jsonStr, 'utf8');

            if (offset + 2 + len > PAGE_SIZE) {
                // FIX: Jangan diam-diam hapus items — lempar error eksplisit.
                // Sebelumnya: entry.items = entry.items.slice(0, i) → data loss permanen
                // tanpa peringatan. Sekarang error jelas agar bug terdeteksi.
                // Solusi jangka panjang: overflow page allocation (roadmap).
                throw new Error(
                    `[Pager] Row terlalu besar untuk page ${pageId}: ` +
                    `item[${i}] butuh ${len + 2} bytes, sisa ${PAGE_SIZE - offset} bytes. ` +
                    `Kurangi ukuran row atau implementasi overflow page.`
                );
            }

            buffer.writeUInt16LE(len, offset);
            buffer.write(jsonStr, offset + 2, len, 'utf8');
            offset += 2 + len;
            written++;
        }

        buffer.writeUInt16LE(written, 4);
        buffer.writeUInt16LE(offset, 6);

        this.cache.set(pageId, buffer);
        this.dirtyObjects.delete(pageId);
    }

    readPage(pageId) {
        if (this.dirtyObjects.has(pageId)) {
            this._serializeObjectsToBuffer(pageId);
        }

        if (this.cache.has(pageId)) {
            const buf = this.cache.get(pageId);
            this.cache.delete(pageId);
            this.cache.set(pageId, buf);
            return buf;
        }

        const buf    = this._allocBuffer();
        const offset = pageId * PAGE_SIZE;
        try {
            fs.readSync(this.fd, buf, 0, PAGE_SIZE, offset);
        } catch (e) {
            // fs.readSync tidak throw saat EOF (return < PAGE_SIZE bytes saja),
            // hanya throw saat error nyata (EIO, EBADF, dll).
            this._releaseBuffer(buf);
            throw new Error(`[Pager] Gagal baca page ${pageId} di offset ${offset}: ${e.message}`);
        }

        this.cache.set(pageId, buf);

        // FIX-B: LRU eviction — cek dirtyPages DAN dirtyObjects sebelum evict
        while (this.cache.size > this.cacheLimit) {
            const firstKey = this.cache.keys().next().value;

            if (this.dirtyPages.has(firstKey) || this.dirtyObjects.has(firstKey)) {
                this._flushPage(firstKey);
            }

            const oldBuf = this.cache.get(firstKey);
            this.cache.delete(firstKey);
            this.objectCache.delete(firstKey);
            this._releaseBuffer(oldBuf);
        }

        return buf;
    }

    writePage(pageId, buf) {
        if (buf.length !== PAGE_SIZE) throw new Error('Buffer harus 4KB');

        if (this.wal && this.wal.enabled) {
            // FIX-C: beforeImage harus state SEBELUM operasi, bukan buf itu sendiri.
            // Baca dari cache (clone) atau langsung dari disk jika belum di cache.
            let beforeImage;
            if (this.cache.has(pageId)) {
                beforeImage = Buffer.from(this.cache.get(pageId)); // clone agar tidak berubah
            } else {
                beforeImage = this._readPageFromDisk(pageId); // baca disk langsung
            }
            this.wal.logOperation('UPDATE', 'page', pageId, beforeImage, buf);
        }

        this.cache.set(pageId, buf);
        this.objectCache.delete(pageId);

        if (this.lazyWrite) {
            this.dirtyPages.add(pageId);
        } else {
            this._flushPage(pageId);
        }
    }

    _flushPage(pageId) {
        if (this.dirtyObjects.has(pageId)) {
            this._serializeObjectsToBuffer(pageId);
        }
        const buf = this.cache.get(pageId);
        if (!buf) return;
        const offset = pageId * PAGE_SIZE;
        fs.writeSync(this.fd, buf, 0, PAGE_SIZE, offset);
        this.dirtyPages.delete(pageId);
        // Catatan: fsync TIDAK dipanggil di sini per-page (lambat).
        // fsync dipanggil satu kali di flush() setelah semua pages ditulis.
    }

    /**
     * FIX-A: flush() memanggil fsyncSync SATU KALI setelah semua dirty pages ditulis.
     * Ini menjamin seluruh batch write sampai ke storage fisik secara atomik,
     * dan jauh lebih efisien daripada fsync per-page.
     */
    flush() {
        if (this.dirtyPages.size === 0 && this.dirtyObjects.size === 0) return;

        const allDirty    = new Set([...this.dirtyPages, ...this.dirtyObjects]);
        const sortedPages = Array.from(allDirty).sort((a, b) => a - b);

        for (const pageId of sortedPages) {
            this._flushPage(pageId);
        }

        // FIX-A: Satu fsync setelah semua halaman masuk OS buffer
        if (this.fd !== null) {
            try {
                fs.fsyncSync(this.fd);
            } catch (e) {
                console.error('[Pager]  fsync gagal — data mungkin belum tersimpan ke disk:', e.message);
            }
        }
    }

    allocPage() {
        const page0      = this.readPage(0);
        const totalPages = page0.readUInt32LE(4);

        const newPageId = totalPages;
        page0.writeUInt32LE(totalPages + 1, 4);
        this.writePage(0, page0);

        const newPage = this._allocBuffer();
        newPage.writeUInt32LE(0, 0);
        newPage.writeUInt16LE(0, 4);
        newPage.writeUInt16LE(8, 6);
        this.writePage(newPageId, newPage);

        return newPageId;
    }

    close() {
        if (this.fd !== null) {
            this.flush(); // sudah include fsync
            fs.closeSync(this.fd);
            this.fd = null;
            this.cache.clear();
            this.objectCache.clear();
            this.dirtyPages.clear();
            this.dirtyObjects.clear();
        }
    }
}

Pager.PAGE_SIZE = PAGE_SIZE;

module.exports = Pager;
