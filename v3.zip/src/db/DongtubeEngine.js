const Pager = require('./modules/Pager');
const QueryParser = require('./modules/QueryParser');
const WAL = require('./modules/WAL');
const DBEventHandler = require("./services/event/DBEventHandler");
const DBEvent = require("./services/event/DBEvent");
const path = require('path');

const TableManager       = require('./services/TableManager');
const IndexManager       = require('./services/IndexManager');
const ConditionEvaluator = require('./services/logic/ConditionEvaluator');
const TransactionManager = require('./services/TransactionManager');
const ViewManager        = require('./services/ViewManager');
const TriggerManager     = require('./services/TriggerManager');
const ProcedureManager   = require('./services/ProcedureManager');
const ReplicationManager = require('./services/ReplicationManager');
const SearchManager      = require('./services/SearchManager');
const SecurityManager    = require('./services/SecurityManager');

const SelectExecutor    = require('./services/executors/SelectExecutor');
const InsertExecutor    = require('./services/executors/InsertExecutor');
const DeleteExecutor    = require('./services/executors/DeleteExecutor');
const UpdateExecutor    = require('./services/executors/UpdateExecutor');
const AggregateExecutor = require('./services/executors/AggregateExecutor');

/**
 * DongtubeEngine — Core database engine
 *
 * FIXES v3 → v4:
 *  FIX-1: WAL recovery benar-benar me-replay ke Pager (dari v3, dipertahankan)
 *  FIX-2: _initSystem() dipanggil SETELAH WAL recovery (dari v3, dipertahankan)
 *  FIX-3: query() sekarang support SAVEPOINT dan ROLLBACK TO [name]
 *  FIX-4: BLUSUKAN / SEARCH di-whitelist dari security check (bukan bypass penuh)
 *  FIX-5: close() memanggil replicationManager.destroy() untuk cleanup socket
 *  FIX-6: Error di constructor tidak biarkan engine setengah-init
 */
class DongtubeEngine {
    constructor(filePath, options = {}) {
        this.dbPath  = path.dirname(filePath);
        this.wal     = options.wal ? new WAL(filePath, options.wal) : null;
        this.dbevent = options.dbevent || new DBEventHandler();

        if (!(this.dbevent instanceof DBEvent)) {
            console.error('[Engine] dbevent bukan instance dari DBEvent');
        }

        // WAL recovery: collect pending operations sebelum Pager di-init
        if (this.wal && this.wal.enabled) {
            const recovered = this.wal.recover();
            if (recovered.length > 0) {
                console.log(`[WAL]  ${recovered.length} operasi dari crash ditemukan, akan di-replay...`);
                this._pendingReplay = recovered;
            } else {
                this._pendingReplay = null;
            }
        } else {
            this._pendingReplay = null;
        }

        this.pager   = new Pager(filePath, this.wal);
        this.indexes = new Map();
        this.parser  = new QueryParser();

        this.queryCache      = new Map();
        this.queryCacheLimit = 1000;

        this.tableManager       = new TableManager(this);
        this.indexManager       = new IndexManager(this);
        this.conditionEvaluator = new ConditionEvaluator();
        this.transactionManager = new TransactionManager(this);
        this.viewManager        = new ViewManager(this);
        this.triggerManager     = new TriggerManager(this);
        this.procedureManager   = new ProcedureManager(this);
        this.replicationManager = new ReplicationManager(this);
        this.searchManager      = new SearchManager(this);
        this.securityManager    = new SecurityManager(this);

        this.selectExecutor    = new SelectExecutor(this);
        this.insertExecutor    = new InsertExecutor(this);
        this.deleteExecutor    = new DeleteExecutor(this);
        this.updateExecutor    = new UpdateExecutor(this);
        this.aggregateExecutor = new AggregateExecutor(this);

        // _initSystem SETELAH semua service siap
        this._initSystem();

        // Replay WAL setelah semua service siap
        if (this._pendingReplay) {
            this._replayWAL(this._pendingReplay);
            this._pendingReplay = null;
        }
    }

    /**
     * Replay WAL operations ke Pager setelah crash recovery.
     * Invalidate objectCache setelah tiap page di-restore (cegah stale read).
     */
    _replayWAL(operations) {
        let replayed = 0;
        let skipped  = 0;

        // Sort berdasarkan LSN — replay harus oldest-first
        const sorted = [...operations].sort((a, b) => a.lsn - b.lsn);

        for (const op of sorted) {
            try {
                if (op.opCode === 0x06) continue; // Skip CHECKPOINT entries

                if (op.afterImage && op.afterImage.length === 4096) {
                    this.pager.cache.set(op.pageId, op.afterImage);
                    this.pager.dirtyPages.add(op.pageId);
                    this.pager.objectCache.delete(op.pageId); // invalidate stale cache
                    replayed++;
                } else {
                    skipped++;
                }
            } catch (e) {
                console.error(`[WAL]  Gagal replay LSN=${op.lsn}: ${e.message}`);
                skipped++;
            }
        }

        if (replayed > 0) {
            try {
                this.pager.flush();
                console.log(`[WAL]  Replay selesai: ${replayed} page direstorasi, ${skipped} dilewati`);
                this.wal.truncate();
            } catch (e) {
                console.error(`[WAL]  Flush setelah replay gagal: ${e.message}`);
            }
        } else {
            console.log(`[WAL] ℹ  Tidak ada page yang perlu direstorasi (${skipped} entry dilewati)`);
        }
    }

    _initSystem() {
        if (!this.tableManager.findTableEntry('_indexes')) {
            try { this.tableManager.createTable('_indexes', true); } catch (_) {}
        }

        this.indexManager.loadIndexes();
        this.viewManager.loadViews();
        this.triggerManager.loadTriggers();
        this.procedureManager.loadProcedures();
        this.searchManager.init();
        this.securityManager.init(); // FIX-B SecurityManager: sekarang sync
    }

    /**
     * FIX-5: Cleanup socket replication saat close
     */
    close() {
        if (this.replicationManager) {
            this.replicationManager.destroy();
        }
        if (this.wal) {
            this.wal.checkpoint();
            this.wal.close();
        }
        if (this.pager) {
            this.pager.close();
            this.pager = null;
        }
    }

    _shallowCloneCmd(cmd) {
        // FIX: Gunakan JSON deep clone untuk parse tree.
        // Shallow clone sebelumnya tidak aman untuk nested criteria (AND/OR complex),
        // inner objects ter-share by reference → mutasi clone bisa corrupt cache template.
        // Parse tree adalah plain object (no circular refs, no functions) → JSON aman.
        return JSON.parse(JSON.stringify(cmd));
    }

    query(queryString, params) {
        if (!this.pager) return 'Error: Database sudah ditutup.';

        let cmd;
        this.queryString = queryString;
        const cacheKey   = queryString;
        // FIX-CACHE: Hanya cache query read-only (SELECT, SHOW, EXPLAIN).
        // INSERT/UPDATE/DELETE TIDAK boleh di-cache karena itu mutasi.
        const CACHEABLE_TYPES = new Set(['SELECT','SHOW_TABLES','SHOW_INDEXES','EXPLAIN','AGGREGATE']);

        if (this.queryCache.has(cacheKey) && !params) {
            const cached = this.queryCache.get(cacheKey);
            cmd = this._shallowCloneCmd(cached);
            this.queryCache.delete(cacheKey);
            this.queryCache.set(cacheKey, cached);
        } else {
            const templateCmd = this.parser.parse(queryString);
            if (templateCmd.type !== 'ERROR') {
                // Hanya simpan ke cache jika read-only dan tidak pakai params
                if (!params && CACHEABLE_TYPES.has(templateCmd.type)) {
                    this.queryCache.set(cacheKey, templateCmd);
                    while (this.queryCache.size > this.queryCacheLimit) {
                        const firstKey = this.queryCache.keys().next().value;
                        this.queryCache.delete(firstKey);
                    }
                }
                cmd = templateCmd;
            } else {
                return `Error: ${templateCmd.message}`;
            }

            if (params) {
                this.parser._bindParameters(cmd, params);
            }
        }

        if (cmd.type === 'ERROR') return `Error: ${cmd.message}`;

        // Security check — termasuk tabel sistem (FIX-A SecurityManager)
        const isReadOp = ['SELECT', 'BLUSUKAN', 'SEARCH', 'SHOW_TABLES', 'SHOW_INDEXES', 'EXPLAIN'].includes(cmd.type);
        if (cmd.table) {
            const action = isReadOp ? 'read' : 'write';
            // FIX-SEC: Jangan default ke 'admin' — caller tanpa user tetap
            // diperiksa sebagai 'anonymous', bukan bypass security.
            const callerUser = (params && params.user) ? params.user : 'anonymous';
            try {
                this.securityManager.check(callerUser, cmd.table, action);
            } catch (e) {
                return e.message;
            }
        }

        try {
            switch (cmd.type) {
                case 'CREATE_TABLE':
                    return this.tableManager.createTable(cmd.table);

                case 'SHOW_TABLES':
                    return this.tableManager.showTables();

                case 'SHOW_INDEXES':
                    return this.indexManager.showIndexes(cmd.table);

                case 'INSERT': {
                    if (this.transactionManager.isActive()) {
                        return this.transactionManager.bufferOperation('INSERT', cmd);
                    }
                    const insertResult = this.insertExecutor.execute(cmd);
                    this.triggerManager.handleEvent('INSERT', cmd.table);
                    if (cmd.values) {
                        // FIX: Gunakan crypto random sebagai fallback ID jika row tidak punya field 'id',
                        // bukan Date.now() yang bisa collision jika 2 INSERT dalam 1ms.
                        const rowId = cmd.values.id != null
                            ? cmd.values.id
                            : require('crypto').randomBytes(8).toString('hex');
                        this.searchManager.indexRow(cmd.table, rowId, cmd.values);
                    }
                    return insertResult;
                }

                case 'SELECT':
                    if (this.viewManager.isView(cmd.table)) {
                        return this.viewManager.executeView(cmd.table, cmd.criteria);
                    }
                    return this.selectExecutor.execute(cmd);

                case 'DELETE': {
                    if (this.transactionManager.isActive()) {
                        return this.transactionManager.bufferOperation('DELETE', cmd);
                    }
                    // FIX-SEARCH: Deindex baris yang akan dihapus SEBELUM eksekusi delete
                    // agar full-text search tidak kembalikan hasil stale/deleted.
                    const delEntry = this.tableManager.findTableEntry(cmd.table);
                    if (delEntry) {
                        const toDelete = this._scanTable(delEntry, cmd.criteria || null);
                        for (const row of toDelete) {
                            if (row.id != null) this.searchManager.deindexRow(cmd.table, row.id);
                        }
                    }
                    const deleteResult = this.deleteExecutor.execute(cmd);
                    this.triggerManager.handleEvent('DELETE', cmd.table);
                    return deleteResult;
                }

                case 'UPDATE': {
                    if (this.transactionManager.isActive()) {
                        return this.transactionManager.bufferOperation('UPDATE', cmd);
                    }
                    // FIX-SEARCH: Deindex nilai lama, execute update, reindex nilai baru.
                    const updEntry = this.tableManager.findTableEntry(cmd.table);
                    let oldRows = [];
                    if (updEntry) {
                        oldRows = this._scanTable(updEntry, cmd.criteria || null);
                        for (const row of oldRows) {
                            if (row.id != null) this.searchManager.deindexRow(cmd.table, row.id);
                        }
                    }
                    const updateResult = this.updateExecutor.execute(cmd);
                    this.triggerManager.handleEvent('UPDATE', cmd.table);
                    // Reindex dengan data terbaru (merge old row + nilai SET baru)
                    if (updEntry && cmd.values) {
                        for (const row of oldRows) {
                            if (row.id != null) {
                                const merged = { ...row, ...cmd.values };
                                this.searchManager.indexRow(cmd.table, row.id, merged);
                            }
                        }
                    }
                    return updateResult;
                }

                case 'DROP_TABLE':
                    return this.tableManager.dropTable(cmd.table);

                case 'CREATE_INDEX':
                    return this.indexManager.createIndex(cmd.table, cmd.field);

                case 'AGGREGATE':
                    return this.aggregateExecutor.execute(cmd);

                case 'EXPLAIN':
                    return this._explain(cmd.innerCommand);

                case 'BEGIN_TRANSACTION':
                    return this.transactionManager.begin();

                case 'COMMIT':
                    return this.transactionManager.commit();

                case 'ROLLBACK':
                    // FIX-3: Support ROLLBACK TO [savepoint]
                    if (cmd.savepointName) {
                        return this.transactionManager.rollbackToSavepoint(cmd.savepointName);
                    }
                    return this.transactionManager.rollback();

                case 'SAVEPOINT':
                    // FIX-3: Support SAVEPOINT [name]
                    return this.transactionManager.savepoint(cmd.savepointName || cmd.name);

                case 'CREATE_VIEW':
                    return this.viewManager.createView(cmd.viewName, cmd.selectCommand);

                case 'DROP_VIEW':
                    return this.viewManager.dropView(cmd.viewName);

                case 'CREATE_TRIGGER':
                    return this.triggerManager.createTrigger(cmd.name, cmd.event, cmd.table, cmd.action);

                case 'DROP_TRIGGER':
                    return this.triggerManager.dropTrigger(cmd.name);

                case 'SAVE_PROCEDURE':
                    return this.procedureManager.saveProcedure(cmd.name, cmd.body);

                case 'EXECUTE_PROCEDURE':
                    return this.procedureManager.executeProcedure(cmd.name);

                case 'DROP_PROCEDURE':
                    return this.procedureManager.dropProcedure(cmd.name);

                case 'CONFIGURE_REPLICATION':
                    return this.replicationManager.configure(cmd.role, cmd.host, cmd.port);

                case 'FULLTEXT_SEARCH':
                    return this.searchManager.search(cmd.table, cmd.term);

                case 'GRANT_PERMISSION':
                    return this.securityManager.grant(cmd.user, cmd.table, cmd.action);

                case 'REVOKE_PERMISSION':
                    return this.securityManager.revoke(cmd.user, cmd.table, cmd.action);

                default:
                    return `Perintah tidak dikenal atau belum diimplementasikan: ${cmd.type}`;
            }
        } catch (e) {
            return `Error: ${e.message}`;
        }
    }

    _findTableEntry(name)       { return this.tableManager.findTableEntry(name); }
    _checkMatch(obj, criteria)  { return this.conditionEvaluator.checkMatch(obj, criteria); }
    _updateIndexes(t, n, o)     { this.indexManager.updateIndexes(t, n, o); }
    _removeFromIndexes(t, d)    { this.indexManager.removeFromIndexes(t, d); }
    _insert(t, d)               { return this.insertExecutor.insertMany(t, [d]); }
    _updateTableLastPage(t, p)  { this.tableManager.updateTableLastPage(t, p); }
    _delete(t, c, f)            { return this.deleteExecutor.delete(t, c, f); }

    _scanTable(entry, criteria, limit = null, returnRaw = false) {
        let currentPageId  = entry.startPage;
        const results      = [];
        const effectiveLimit = limit || Infinity;

        const hasSimpleCriteria = criteria && !criteria.type && criteria.key && criteria.op;
        const criteriaKey = hasSimpleCriteria ? criteria.key : null;
        const criteriaOp  = hasSimpleCriteria ? criteria.op  : null;
        const criteriaVal = hasSimpleCriteria ? criteria.val : null;

        // FIX-PERF: Compile LIKE regex SEKALI sebelum loop scan, bukan setiap row.
        // Untuk tabel besar (100k+ rows), ini hemat puluhan ms per query.
        let likeRegex = null;
        if (hasSimpleCriteria && criteriaOp === 'LIKE' && typeof criteriaVal === 'string') {
            const pattern = criteriaVal.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
                .replace(/%/g, '.*')
                .replace(/_/g, '.');
            likeRegex = new RegExp('^' + pattern + '$', 'i');
        }

        while (currentPageId !== 0 && results.length < effectiveLimit) {
            const pageData = this.pager.readPageObjects(currentPageId);

            for (const obj of pageData.items) {
                if (results.length >= effectiveLimit) break;

                let matches = true;
                if (hasSimpleCriteria) {
                    const val = obj[criteriaKey];
                    switch (criteriaOp) {
                        case '=':  matches = (val == criteriaVal); break;
                        case '>':  matches = (val >  criteriaVal); break;
                        case '<':  matches = (val <  criteriaVal); break;
                        case '>=': matches = (val >= criteriaVal); break;
                        case '<=': matches = (val <= criteriaVal); break;
                        case '!=': matches = (val != criteriaVal); break;
                        case 'LIKE':
                            matches = likeRegex ? likeRegex.test(String(val ?? '')) : false;
                            break;
                        default:
                            matches = this.conditionEvaluator.checkSingleCondition(obj, criteria);
                    }
                } else if (criteria) {
                    matches = this.conditionEvaluator.checkMatch(obj, criteria);
                }

                if (matches) {
                    if (returnRaw) {
                        Object.defineProperty(obj, '_pageId', {
                            value: currentPageId,
                            enumerable: false,
                            writable: true,
                        });
                    }
                    results.push(obj);
                }
            }

            currentPageId = pageData.next;
        }
        return results;
    }

    _explain(cmd) {
        const plan = { type: cmd.type, table: cmd.table, steps: [] };

        switch (cmd.type) {
            case 'SELECT': {
                const entry = this.tableManager.findTableEntry(cmd.table);
                if (!entry) { plan.error = `Table '${cmd.table}' not found`; return plan; }

                if (cmd.joins && cmd.joins.length > 0) {
                    plan.steps.push({ operation: 'SCAN', table: cmd.table, method: 'Full Table Scan', reason: 'Base table for JOIN' });
                    for (const join of cmd.joins) {
                        const joinType = join.type || 'INNER';
                        plan.steps.push({
                            operation: `${joinType} JOIN`, table: join.table,
                            method: join.on && join.on.op === '=' ? 'Hash Join' : 'Nested Loop Join',
                            condition: join.on ? `${join.on.left} ${join.on.op} ${join.on.right}` : 'CROSS',
                        });
                    }
                } else if (cmd.criteria) {
                    const indexKey = `${cmd.table}.${cmd.criteria.key}`;
                    const hasIndex = this.indexes.has(indexKey);
                    plan.steps.push({
                        operation: hasIndex && cmd.criteria.op === '=' ? 'INDEX SCAN' : 'TABLE SCAN',
                        table: cmd.table,
                        method: hasIndex && cmd.criteria.op === '=' ? 'B-Tree Index Lookup' : 'Full Table Scan',
                        condition: `${cmd.criteria.key} ${cmd.criteria.op} ${JSON.stringify(cmd.criteria.val)}`,
                    });
                } else {
                    plan.steps.push({ operation: 'TABLE SCAN', table: cmd.table, method: 'Full Table Scan', reason: 'No WHERE clause' });
                }

                if (cmd.distinct) plan.steps.push({ operation: 'DISTINCT', method: 'Hash-based deduplication' });
                if (cmd.sort)     plan.steps.push({ operation: 'SORT', field: cmd.sort.by, direction: cmd.sort.order || 'ASC' });
                if (cmd.limit || cmd.offset) plan.steps.push({ operation: 'LIMIT/OFFSET', limit: cmd.limit || 'none', offset: cmd.offset || 0 });
                if (cmd.cols && !(cmd.cols.length === 1 && cmd.cols[0] === '*')) plan.steps.push({ operation: 'PROJECT', columns: cmd.cols });
                break;
            }

            case 'DELETE':
            case 'UPDATE': {
                const entry = this.tableManager.findTableEntry(cmd.table);
                if (!entry) { plan.error = `Table '${cmd.table}' not found`; return plan; }
                if (cmd.criteria) {
                    const indexKey = `${cmd.table}.${cmd.criteria.key}`;
                    const hasIndex = this.indexes.has(indexKey);
                    plan.steps.push({
                        operation: 'SCAN', table: cmd.table,
                        method: hasIndex && cmd.criteria.op === '=' ? 'Index-assisted scan' : 'Full Table Scan',
                        condition: `${cmd.criteria.key} ${cmd.criteria.op} ${JSON.stringify(cmd.criteria.val)}`,
                    });
                } else {
                    plan.steps.push({ operation: 'SCAN', table: cmd.table, method: 'Full Table Scan', reason: 'No WHERE clause - affects all rows' });
                }
                plan.steps.push({ operation: cmd.type, table: cmd.table, method: 'In-place modification' });
                break;
            }

            case 'AGGREGATE': {
                plan.steps.push({ operation: 'SCAN', table: cmd.table, method: cmd.criteria ? 'Filtered Scan' : 'Full Table Scan' });
                if (cmd.groupBy) plan.steps.push({ operation: 'GROUP', field: cmd.groupBy, method: 'Hash-based grouping' });
                plan.steps.push({ operation: 'AGGREGATE', function: cmd.func, field: cmd.field || '*' });
                if (cmd.having) plan.steps.push({ operation: 'HAVING', condition: `${cmd.having.field} ${cmd.having.op} ${cmd.having.val}` });
                break;
            }
        }

        const tableIndexes = [];
        for (const [key] of this.indexes) {
            if (key.startsWith(cmd.table + '.')) tableIndexes.push(key);
        }
        if (tableIndexes.length > 0) plan.availableIndexes = tableIndexes;

        return plan;
    }
}

module.exports = DongtubeEngine;
