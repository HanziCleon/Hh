/**
 * DongtubeDB — File Type Utilities
 * Maps extensions → categories & MIME types
 */

export const FILE_CATEGORIES = {
  video: [
    'mp4', 'mov', 'mkv', 'avi', 'webm', 'flv', 'wmv', 'm4v',
    'mts', 'ogv', '3gp', 'mpg', 'mpeg', 'm2ts', 'ts', 'vob',
    'divx', 'xvid', 'rmvb', 'rm', 'asf', 'f4v', 'mxf'
  ],
  audio: [
    'mp3', 'wav', 'aac', 'flac', 'opus', 'ogg', 'm4a', 'wma',
    'aiff', 'alac', 'mid', 'midi', 'weba', 'amr', 'ape', 'mka',
    'ra', 'au', 'ac3', 'dts', 'mp2', 'spx', 'caf', 'voc'
  ],
  image: [
    'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg', 'ico',
    'tiff', 'tif', 'heic', 'heif', 'avif', 'psd', 'ai', 'eps',
    'raw', 'cr2', 'nef', 'dng', 'xcf', 'jxl', 'apng'
  ],
  document: [
    'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx',
    'odt', 'ods', 'odp', 'rtf', 'epub', 'mobi', 'fb2',
    'pages', 'numbers', 'key', 'djvu', 'oxps', 'xps'
  ],
  text: [
    'txt', 'md', 'markdown', 'rst', 'org', 'adoc', 'tex',
    'csv', 'tsv', 'log', 'nfo', 'srt', 'vtt', 'sub', 'ass',
    'ssa', 'lrc', 'ics', 'vcf', 'plist'
  ],
  code: [
    'js', 'jsx', 'mjs', 'cjs', 'ts', 'tsx', 'html', 'htm',
    'css', 'scss', 'sass', 'less', 'json', 'jsonc', 'xml',
    'yaml', 'yml', 'toml', 'ini', 'cfg', 'conf', 'env',
    'py', 'pyw', 'rb', 'java', 'kt', 'kts', 'groovy',
    'cpp', 'c', 'h', 'hpp', 'cc', 'cs', 'go', 'rs',
    'swift', 'dart', 'php', 'sh', 'bash', 'zsh', 'fish',
    'bat', 'cmd', 'ps1', 'lua', 'r', 'sql', 'graphql',
    'vue', 'svelte', 'astro', 'ex', 'exs', 'erl', 'hs',
    'clj', 'cljs', 'scala', 'pl', 'pm', 'el', 'vim'
  ],
  archive: [
    'zip', 'rar', '7z', 'tar', 'gz', 'bz2', 'xz', 'tgz',
    'tbz2', 'txz', 'lz', 'lzma', 'zst', 'br', 'lz4',
    'cab', 'iso', 'dmg', 'img', 'pkg', 'deb', 'rpm',
    'appimage', 'msi', 'exe', 'apk', 'ipa', 'aab'
  ],
  font: [
    'ttf', 'otf', 'woff', 'woff2', 'eot', 'fon', 'fnt',
    'sfd', 'ufo', 'pfb', 'pfm', 'afm', 'bdf', 'pcf'
  ],
  data: [
    'db', 'sqlite', 'sqlite3', 'sql', 'dump',
    'parquet', 'avro', 'orc', 'feather', 'hdf5', 'h5',
    'nc', 'mat', 'npz', 'pkl', 'pickle', 'msgpack'
  ]
};

const ALL_EXTENSIONS = new Set(Object.values(FILE_CATEGORIES).flat());

export const MIME_TYPES = {
  mp4: 'video/mp4', mov: 'video/quicktime', mkv: 'video/x-matroska',
  avi: 'video/x-msvideo', webm: 'video/webm', flv: 'video/x-flv',
  wmv: 'video/x-ms-wmv', m4v: 'video/x-m4v', ogv: 'video/ogg',
  '3gp': 'video/3gpp', mpg: 'video/mpeg', mpeg: 'video/mpeg',
  mts: 'video/mp2t', m2ts: 'video/mp2t', ts: 'video/mp2t',
  mp3: 'audio/mpeg', wav: 'audio/wav', aac: 'audio/aac',
  flac: 'audio/flac', opus: 'audio/opus', ogg: 'audio/ogg',
  m4a: 'audio/mp4', wma: 'audio/x-ms-wma', aiff: 'audio/aiff',
  mid: 'audio/midi', midi: 'audio/midi', weba: 'audio/webm',
  amr: 'audio/amr', ape: 'audio/x-ape',
  jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png',
  gif: 'image/gif', webp: 'image/webp', bmp: 'image/bmp',
  svg: 'image/svg+xml', ico: 'image/x-icon', tiff: 'image/tiff',
  tif: 'image/tiff', heic: 'image/heic', heif: 'image/heif',
  avif: 'image/avif', psd: 'image/vnd.adobe.photoshop',
  jxl: 'image/jxl', apng: 'image/apng',
  pdf: 'application/pdf',
  doc: 'application/msword',
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  xls: 'application/vnd.ms-excel',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  ppt: 'application/vnd.ms-powerpoint',
  pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  odt: 'application/vnd.oasis.opendocument.text',
  ods: 'application/vnd.oasis.opendocument.spreadsheet',
  odp: 'application/vnd.oasis.opendocument.presentation',
  rtf: 'application/rtf', epub: 'application/epub+zip',
  txt: 'text/plain', md: 'text/markdown', csv: 'text/csv',
  html: 'text/html', htm: 'text/html', css: 'text/css',
  xml: 'application/xml', json: 'application/json',
  yaml: 'text/yaml', yml: 'text/yaml',
  srt: 'text/plain', vtt: 'text/vtt', log: 'text/plain',
  js: 'text/javascript', jsx: 'text/javascript', mjs: 'text/javascript',
  ts: 'text/plain', tsx: 'text/plain',
  py: 'text/x-python', rb: 'text/x-ruby', php: 'text/x-php',
  java: 'text/x-java', go: 'text/x-go', rs: 'text/x-rust',
  cpp: 'text/x-c++', c: 'text/x-c', sh: 'text/x-shellscript',
  sql: 'text/x-sql', scss: 'text/x-scss', graphql: 'text/plain',
  vue: 'text/plain', svelte: 'text/plain',
  zip: 'application/zip', rar: 'application/x-rar-compressed',
  '7z': 'application/x-7z-compressed', tar: 'application/x-tar',
  gz: 'application/gzip', bz2: 'application/x-bzip2',
  xz: 'application/x-xz', tgz: 'application/gzip',
  iso: 'application/x-iso9660-image', dmg: 'application/x-apple-diskimage',
  deb: 'application/x-debian-package', apk: 'application/vnd.android.package-archive',
  exe: 'application/vnd.microsoft.portable-executable',
  msi: 'application/x-msi',
  ttf: 'font/ttf', otf: 'font/otf', woff: 'font/woff',
  woff2: 'font/woff2', eot: 'application/vnd.ms-fontobject',
  db: 'application/octet-stream', sqlite: 'application/octet-stream',
  sqlite3: 'application/octet-stream', parquet: 'application/octet-stream'
};

const TEXT_EXTENSIONS = new Set([
  'txt', 'md', 'markdown', 'csv', 'html', 'htm', 'css', 'scss', 'json',
  'jsonc', 'xml', 'yaml', 'yml', 'toml', 'ini', 'cfg', 'conf', 'env',
  'js', 'jsx', 'mjs', 'cjs', 'ts', 'tsx', 'py', 'pyw', 'rb', 'php',
  'java', 'kt', 'go', 'rs', 'cpp', 'c', 'h', 'cs', 'sh', 'bash',
  'sql', 'graphql', 'lua', 'r', 'vue', 'svelte', 'astro', 'log',
  'srt', 'vtt', 'bat', 'cmd', 'ps1'
]);

/**
 * Get category for a given file extension
 * @param {string} ext - lowercase extension without dot
 * @returns {string} category name
 */
export function getCategory(ext) {
  for (const [cat, exts] of Object.entries(FILE_CATEGORIES)) {
    if (exts.includes(ext)) return cat;
  }
  return 'other';
}

/**
 * Get MIME type for a given extension
 * @param {string} ext - lowercase extension without dot
 * @returns {string} MIME type
 */
export function getMimeType(ext) {
  let mime = MIME_TYPES[ext] || 'application/octet-stream';
  if (TEXT_EXTENSIONS.has(ext)) {
    mime += '; charset=utf-8';
  }
  return mime;
}

/**
 * Extract and normalize extension from filename
 * @param {string} filename
 * @returns {string} lowercase extension without dot
 */
export function getExtension(filename) {
  const parts = filename.split('.');
  if (parts.length < 2) return '';
  return parts[parts.length - 1].toLowerCase();
}

/**
 * Check if an extension is recognized/allowed.
 * File executable web (html, php, dll) diblokir untuk mencegah XSS/RCE
 * jika file diakses langsung dari domain yang sama.
 * @param {string} ext - lowercase extension without dot
 * @returns {boolean}
 */
export function isAllowedExtension(ext) {
  // Blokir ekstensi yang bisa dieksekusi oleh browser/server jika diakses langsung
  // FIX BUG-5b: tambah svgz (compressed SVG, bisa di-decompress browser dan eksekusi script),
  // xml/xhtml/xht (bisa mengandung script tag) ke blocklist — layer pertahanan kedua
  // setelah Content-Disposition: attachment yang difix di files/[id]/route.js.
  const BLOCKED = new Set([
    'html', 'htm', 'php', 'asp', 'aspx', 'jsp', 'cgi', 'shtml', 'phtml',
    'svg', 'svgz', 'xml', 'xhtml', 'xht',
  ]);
  return !BLOCKED.has(ext?.toLowerCase());
}
