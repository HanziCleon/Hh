import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);

const LOG_DIR = process.env.LOG_DIR || path.join(__dirname, '../../logs');

if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });

function getLogFile() {
  const date = new Date().toISOString().split('T')[0];
  return path.join(LOG_DIR, `dongtubedb-${date}.log`);
}

function write(level, message) {
  const timestamp = new Date().toISOString();
  const line      = `[${timestamp}] [${level.toUpperCase().padEnd(5)}] ${message}`;

  const colors = { INFO: '\x1b[32m', WARN: '\x1b[33m', ERROR: '\x1b[31m', DEBUG: '\x1b[36m' };
  const reset  = '\x1b[0m';
  console.log(`${colors[level.toUpperCase()] || ''}${line}${reset}`);

  fs.appendFile(getLogFile(), line + '\n', () => {});
}

export const logger = {
  info:    (msg) => write('INFO',  msg),
  warn:    (msg) => write('WARN',  msg),
  error:   (msg) => write('ERROR', msg),
  debug:   (msg) => { if (process.env.DEBUG === 'true') write('DEBUG', msg); },
  divider: ()    => write('INFO',  '='.repeat(60)),
};
