import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { FILE_CATEGORIES } from '../utils/fileTypes.js';
import { logger } from '../utils/logger.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);

export const STORAGE_ROOT = process.env.STORAGE_DIR || path.join(__dirname, '../../storage');

const ALL_CATEGORIES = [...Object.keys(FILE_CATEGORIES), 'other'];

export async function initStorage() {
  fs.mkdirSync(STORAGE_ROOT, { recursive: true });
  for (const cat of ALL_CATEGORIES) {
    fs.mkdirSync(path.join(STORAGE_ROOT, cat), { recursive: true });
  }
  logger.info(` Storage root: ${STORAGE_ROOT}`);
}

export function getFilePath(category, filename) {
  return path.join(STORAGE_ROOT, path.basename(category), path.basename(filename));
}

export function fileExists(category, filename) {
  return fs.existsSync(getFilePath(category, filename));
}

export function deleteFile(category, filename) {
  const fullPath = getFilePath(category, filename);
  if (fs.existsSync(fullPath)) {
    fs.unlinkSync(fullPath);
    return true;
  }
  return false;
}

export function getStorageStats() {
  const stats = {};
  let totalSize  = 0;
  let totalFiles = 0;

  for (const cat of ALL_CATEGORIES) {
    const catPath = path.join(STORAGE_ROOT, cat);
    if (!fs.existsSync(catPath)) { stats[cat] = { files: 0, size: 0 }; continue; }

    const files  = fs.readdirSync(catPath);
    let catSize  = 0;
    for (const f of files) {
      try { catSize += fs.statSync(path.join(catPath, f)).size; } catch (_) {}
    }
    stats[cat] = { files: files.length, size: catSize };
    totalSize  += catSize;
    totalFiles += files.length;
  }

  return { categories: stats, totalFiles, totalSize };
}

export function formatBytes(bytes) {
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0, val = bytes;
  while (val >= 1024 && i < units.length - 1) { val /= 1024; i++; }
  return `${val.toFixed(2)} ${units[i]}`;
}
