import { q, esc, qSelect, ensureTable, ensureIndex } from '../lib/dongtube.js';
import { logger } from '../utils/logger.js';

const TABLE = 'files';

function mapRow(row) {
  if (!row) return null;
  return {
    id:           row.id,
    originalName: row.originalName,
    storedName:   row.storedName,
    category:     row.category,
    mimeType:     row.mimeType,
    size:         Number(row.size || 0),
    apiKeyId:     row.apiKeyId,
    owner:        row.owner,
    uploadedAt:   row.uploadedAt,
    downloads:    Number(row.downloads || 0),
    lastAccessed: row.lastAccessed || null,
    public:       row.public === 1 || row.public === '1' || row.public === true,
    tags:         _parseJSON(row.tags, []),
    metadata:     _parseJSON(row.metadata, {}),
  };
}

function _parseJSON(val, fallback) {
  if (!val) return fallback;
  if (typeof val !== 'string') return val;
  try { return JSON.parse(val); } catch (_) { return fallback; }
}

export async function initDatabase() {
  ensureTable(TABLE);
  ensureIndex(TABLE, 'id');
  ensureIndex(TABLE, 'apiKeyId');
  ensureIndex(TABLE, 'category');
  logger.info(` DatabaseService: tabel '${TABLE}' siap`);
}

export function insertFile(record) {
  // FIX #6: JsonDB tidak enforce constraint unik — cek duplikat secara eksplisit.
  // Collision 8-char base-62 sangat jarang tapi tidak mustahil; lebih baik error
  // dengan pesan jelas daripada diam-diam menyimpan dua record dengan ID sama.
  if (getFile(record.id)) {
    throw new Error(`ID collision: file '${record.id}' sudah ada di database`);
  }

  const tags     = JSON.stringify(record.tags || []);
  const metadata = JSON.stringify(record.metadata || {});

  // FIX BUG A: INSERT harus pakai q(), bukan qSelect()
  q(`
    INSERT INTO ${TABLE}
      (id, originalName, storedName, category, mimeType, size,
       apiKeyId, owner, uploadedAt, downloads, lastAccessed,
       public, tags, metadata)
    VALUES
      (${esc(record.id)}, ${esc(record.originalName)}, ${esc(record.storedName)},
       ${esc(record.category)}, ${esc(record.mimeType)}, ${esc(record.size)},
       ${esc(record.apiKeyId)}, ${esc(record.owner)}, ${esc(record.uploadedAt)},
       0, NULL,
       ${record.public ? 1 : 0}, ${esc(tags)}, ${esc(metadata)})
  `);
}

export function getFile(id) {
  const rows = qSelect(`SELECT * FROM ${TABLE} WHERE id = ${esc(id)}`);
  return rows.length > 0 ? mapRow(rows[0]) : null;
}

export function updateFile(id, updates) {
  if (!getFile(id)) return false;

  const sets = [];
  for (const [k, v] of Object.entries(updates)) {
    if (k === 'tags' || k === 'metadata') {
      sets.push(`${k} = ${esc(JSON.stringify(v))}`);
    } else if (k === 'public') {
      sets.push(`public = ${v ? 1 : 0}`);
    } else {
      sets.push(`${k} = ${esc(v)}`);
    }
  }
  if (sets.length === 0) return true;

  // FIX BUG A: UPDATE harus pakai q(), bukan qSelect()
  q(`UPDATE ${TABLE} SET ${sets.join(', ')} WHERE id = ${esc(id)}`);
  return true;
}

export function recordDownload(id) {
  // JsonDB tidak mendukung ekspresi aritmatika (downloads = downloads + 1).
  // Node.js bersifat single-threaded sehingga read-modify-write ini AMAN selama
  // tidak ada `await` di antara getFile() dan q() — keduanya sinkron.
  //
  // CATATAN: Ini TIDAK aman di lingkungan multi-process (cluster, PM2 fork mode).
  // Untuk multi-process, increment harus dilakukan via IPC atau storage terpusat.
  // Untuk single-process (deployment normal), ini sudah benar.
  const rec = getFile(id);
  if (!rec) return;
  q(`
    UPDATE ${TABLE}
    SET downloads = ${(rec.downloads || 0) + 1}, lastAccessed = ${esc(new Date().toISOString())}
    WHERE id = ${esc(id)}
  `);
}

export function deleteRecord(id) {
  const existed = getFile(id) !== null;
  // FIX BUG A: DELETE harus pakai q(), bukan qSelect()
  q(`DELETE FROM ${TABLE} WHERE id = ${esc(id)}`);
  return existed;
}

/**
 * @param {object} opts  apiKeyId?, category?, search?, sort?, order?, page?, limit?, tags?
 */
export function listFiles(opts = {}) {
  const {
    apiKeyId, category, search,
    sort = 'uploadedAt', order = 'desc',
    page = 1, limit = 50, tags,
    noLimit = false, // BUG-1 FIX: bypass pagination untuk backup
  } = opts;

  // FIX: Whitelist sort fields — cegah prototype pollution via sort=__proto__
  const ALLOWED_SORT = new Set(['uploadedAt', 'originalName', 'size', 'downloads', 'lastAccessed', 'mimeType', 'category']);
  const safeSortField = ALLOWED_SORT.has(sort) ? sort : 'uploadedAt';
  const safeOrder = order === 'asc' ? 'asc' : 'desc';

  const wheres = [];
  if (apiKeyId) wheres.push(`apiKeyId = ${esc(apiKeyId)}`);
  if (category) wheres.push(`category = ${esc(category)}`);

  const sql = wheres.length > 0
    ? `SELECT * FROM ${TABLE} WHERE ${wheres.join(' AND ')}`
    : `SELECT * FROM ${TABLE}`;

  let records = qSelect(sql).map(mapRow);

  if (search) {
    // Gunakan .includes() langsung — sudah case-insensitive via .toLowerCase().
    // Tidak perlu LIKE pattern karena filtering dilakukan in-memory setelah SELECT.
    const ql = search.toLowerCase();
    records = records.filter(r => (r.originalName || '').toLowerCase().includes(ql));
  }
  if (tags && tags.length > 0) {
    // BUG FIX: tags dari query bisa berupa string (single tag dari URL param).
    // Pastikan selalu array sebelum .every() agar tidak throw "tags.every is not a function".
    const tagArr = Array.isArray(tags) ? tags : [tags];
    records = records.filter(r => r.tags && tagArr.every(t => r.tags.includes(t)));
  }

  records.sort((a, b) => {
    let av = a[safeSortField] ?? '';
    let bv = b[safeSortField] ?? '';
    if (typeof av === 'string') av = av.toLowerCase();
    if (typeof bv === 'string') bv = bv.toLowerCase();
    if (av < bv) return safeOrder === 'asc' ? -1 : 1;
    if (av > bv) return safeOrder === 'asc' ?  1 : -1;
    return 0;
  });

  const total = records.length;

  // BUG-1 FIX: noLimit=true melewati paginasi — digunakan khusus untuk backup
  if (noLimit) {
    return { total, page: 1, limit: total, pages: 1, items: records };
  }

  // FIX #3: parseInt(page) bisa return NaN jika page bukan angka.
  // Math.max(1, NaN) = NaN → menyebabkan slice(NaN) return [] secara diam-diam.
  // Tambahkan fallback: parseInt(page) || 1
  const pageNum  = Math.max(1, parseInt(page)  || 1);
  const limitNum = Math.min(200, Math.max(1, parseInt(limit) || 50));
  const start    = (pageNum - 1) * limitNum;

  return {
    total, page: pageNum, limit: limitNum,
    pages: Math.ceil(total / limitNum),
    items: records.slice(start, start + limitNum),
  };
}

export function getOwnerStats(apiKeyId) {
  const records = qSelect(`SELECT * FROM ${TABLE} WHERE apiKeyId = ${esc(apiKeyId)}`).map(mapRow);
  return _buildStats(records);
}

export function getGlobalStats() {
  const records = qSelect(`SELECT * FROM ${TABLE}`).map(mapRow);
  return _buildStats(records);
}

function _buildStats(records) {
  const totalSize      = records.reduce((s, r) => s + (r.size || 0), 0);
  const totalDownloads = records.reduce((s, r) => s + (r.downloads || 0), 0);
  const byCategory     = {};
  for (const r of records) {
    byCategory[r.category] = (byCategory[r.category] || 0) + 1;
  }
  return { totalFiles: records.length, totalSize, totalDownloads, byCategory };
}
