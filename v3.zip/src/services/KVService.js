import crypto from 'crypto';
import { q, esc, qSelect, ensureTable, ensureIndex } from '../lib/dongtube.js';
import { logger } from '../utils/logger.js';

const TABLE = 'kv_store';

function hashValue(value) {
  return crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex').slice(0, 40);
}

function _parseValue(raw) {
  if (raw === null || raw === undefined) return null;
  if (typeof raw !== 'string') return raw;
  try { return JSON.parse(raw); } catch (_) { return raw; }
}

export async function initKVStore() {
  ensureTable(TABLE);
  ensureIndex(TABLE, 'kvKey');
  logger.info(`  KVStore: tabel '${TABLE}' siap`);
}

/** @returns {{ data, sha } | { data: null, sha: null }} */
export function kvRead(key) {
  const rows = qSelect(`SELECT * FROM ${TABLE} WHERE kvKey = ${esc(key)}`);
  if (rows.length === 0) return { data: null, sha: null };
  const rec = rows[0];
  return { data: _parseValue(rec.value), sha: rec.sha };
}

/**
 * Tulis nilai ke key dengan optional optimistic locking.
 * @throws {status: 409} jika SHA mismatch
 */
export function kvWrite(key, value, sha = null) {
  if (sha !== null) {
    const { sha: existingSha } = kvRead(key);
    // BUG FIX: Sebelumnya `existingSha && existingSha !== sha` — jika key belum ada
    // (existingSha = null), kondisi menjadi false dan lock di-bypass diam-diam.
    // Caller yang menyediakan sha mengharapkan conflict detection SELALU aktif.
    // Fix: jika sha disediakan tapi key tidak ada (existingSha null), itu juga conflict.
    if (existingSha !== sha) {
      throw Object.assign(
        new Error('SHA conflict — data sudah diubah oleh proses lain'),
        { status: 409 },
      );
    }
  }

  const newSha     = hashValue(value);
  const serialized = JSON.stringify(value);
  const now        = new Date().toISOString();
  const { data: existing } = kvRead(key);

  if (existing !== null) {
    // FIX BUG 4: UPDATE/INSERT/DELETE harus pakai q(), bukan qSelect().
    // qSelect() return [] untuk mutasi — menyesatkan debug dan tidak semantik.
    q(`
      UPDATE ${TABLE}
      SET value = ${esc(serialized)}, sha = ${esc(newSha)}, updatedAt = ${esc(now)}
      WHERE kvKey = ${esc(key)}
    `);
  } else {
    q(`
      INSERT INTO ${TABLE} (kvKey, value, sha, updatedAt)
      VALUES (${esc(key)}, ${esc(serialized)}, ${esc(newSha)}, ${esc(now)})
    `);
  }

  return newSha;
}

/** @returns {boolean} true jika key ada dan berhasil dihapus */
export function kvDelete(key) {
  const { data } = kvRead(key);
  const existed = data !== null;
  // FIX BUG 4: DELETE harus pakai q(), bukan qSelect()
  if (existed) q(`DELETE FROM ${TABLE} WHERE kvKey = ${esc(key)}`);
  return existed;
}

/** List key langsung di bawah prefix (tidak rekursif) */
export function kvListDir(prefix) {
  const normalPrefix = prefix.endsWith('/') ? prefix : prefix + '/';
  const likePrefix   = normalPrefix.replace(/[%_\\]/g, '\\$&') + '%';

  const rows = qSelect(`SELECT * FROM ${TABLE} WHERE kvKey LIKE ${esc(likePrefix)}`);

  // FIX #6: Sort sebelumnya O(n²) karena rows.find() di dalam comparator.
  // Bangun Map lookup terlebih dahulu → sort menjadi O(n log n).
  const updatedAtMap = new Map(rows.map(r => [r.kvKey, r.updatedAt]));

  return rows
    .filter(row => {
      const rest = (row.kvKey || '').slice(normalPrefix.length);
      return rest && !rest.includes('/');
    })
    .map(row => ({
      name: (row.kvKey || '').slice(normalPrefix.length),
      sha:  row.sha,
      type: 'file',
    }))
    .sort((a, b) => {
      const ta = new Date(updatedAtMap.get(normalPrefix + a.name) || 0);
      const tb = new Date(updatedAtMap.get(normalPrefix + b.name) || 0);
      return tb - ta;
    });
}

/** List semua key yang dimulai dengan prefix (termasuk nested) */
export function kvListAll(prefix) {
  const sql = prefix
    ? `SELECT kvKey, sha, updatedAt FROM ${TABLE} WHERE kvKey LIKE ${esc(prefix.replace(/[%_\\]/g, '\\$&') + '%')}`
    : `SELECT kvKey, sha, updatedAt FROM ${TABLE}`;

  return qSelect(sql).map(r => ({ key: r.kvKey, sha: r.sha, updatedAt: r.updatedAt }));
}

// Rate limiter — in-memory (ephemeral by design)
const _rlMap = new Map();

// FIX BUG-3: Tambahkan global HMR guard agar Next.js hot-reload di dev tidak
// spawn interval cleanup baru setiap kali module di-reload. Semua interval lain
// di codebase sudah pakai pola global.__dtdb_xxx — _rlMap lupa diproteksi.
if (!global.__dtdb_rl_cleanup) {
  global.__dtdb_rl_cleanup = true;
  setInterval(() => {
    const cutoff = Date.now() - 60 * 60 * 1000; // 1 jam
    for (const [key, entry] of _rlMap) {
      if (!entry.hits.some(ts => ts > cutoff)) _rlMap.delete(key);
    }
  }, 10 * 60 * 1000).unref(); // .unref() agar tidak mencegah Node.js shutdown
}

export function kvRateLimit(key, maxHits, windowMs) {
  const now   = Date.now();
  const entry = _rlMap.get(key) || { hits: [] };
  entry.hits  = entry.hits.filter(ts => ts > now - windowMs);
  entry.hits.push(now);
  _rlMap.set(key, entry);
  return entry.hits.length <= maxHits;
}

// OTP lock — in-memory mutex (ephemeral by design)
const _otpLocks  = new Map();
const OTP_LOCK_TTL = 7000;

export function kvAcquireOtpLock(username) {
  const now      = Date.now();
  const existing = _otpLocks.get(username);
  if (existing && existing.expiresAt > now) {
    throw Object.assign(
      new Error('User sedang memproses order lain. Tunggu sebentar.'),
      { status: 429 },
    );
  }
  _otpLocks.set(username, { lockedAt: now, expiresAt: now + OTP_LOCK_TTL });
  return username;
}

export function kvReleaseOtpLock(username) {
  if (username) _otpLocks.delete(username);
}

// Catatan: kvMap dihapus — tidak pernah digunakan di mana pun dalam codebase.
