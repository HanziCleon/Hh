import crypto from 'crypto';
import { q, esc, qSelect, ensureTable, ensureIndex } from '../lib/dongtube.js'; // FIX-8: q() untuk mutasi, qSelect() hanya untuk SELECT
import { logger } from '../utils/logger.js';

const TABLE = 'api_keys';

function hashKey(rawKey) {
  return crypto.createHash('sha256').update(rawKey).digest('hex');
}

function generateRawKey() {
  return `dtdb_${crypto.randomBytes(32).toString('hex')}`;
}

function generateId() {
  return crypto.randomBytes(6).toString('hex');
}

function mapRow(row) {
  if (!row) return null;
  return {
    id:         row.id,
    keyHash:    row.keyHash,
    label:      row.label,
    role:       row.role,
    userId:     row.userId || null,   // FIX BUG-1: field ini wajib ada agar backup/route.js
                                      // bisa filter "semua key milik user yang sama"
    createdAt:  row.createdAt,
    lastUsed:   row.lastUsed || null,
    enabled:    row.enabled === 1 || row.enabled === '1' || row.enabled === true,
    maxStorage: Number(row.maxStorage || 0),
    rateLimit:  Number(row.rateLimit  || 0),
  };
}

function safeRow(row) {
  if (!row) return null;
  const { keyHash, ...safe } = row;
  return safe;
}

export async function initKeyManager() {
  ensureTable(TABLE);
  ensureIndex(TABLE, 'id');
  ensureIndex(TABLE, 'keyHash');

  const all = qSelect(`SELECT * FROM ${TABLE}`);
  if (all.length === 0) {
    const { rawKey } = _createInternal({ label: 'master', role: 'admin', maxStorage: 0, rateLimit: 0 });
    logger.info('='.repeat(60));
    logger.warn('  FIRST RUN — Master API Key dibuat:');
    logger.warn(` MASTER KEY: ${rawKey}`);
    logger.warn('  Simpan key ini — TIDAK akan ditampilkan lagi!');
    logger.info('='.repeat(60));
  }

  logger.info(` KeyManager: tabel '${TABLE}' siap`);
}

function _createInternal({ label, role = 'user', maxStorage = 0, rateLimit = 0, userId = null }) {
  const rawKey  = generateRawKey();
  const keyHash = hashKey(rawKey);
  const id      = generateId();
  const now     = new Date().toISOString();

  q(`
    INSERT INTO ${TABLE}
      (id, keyHash, label, role, userId, createdAt, lastUsed, enabled, maxStorage, rateLimit)
    VALUES
      (${esc(id)}, ${esc(keyHash)}, ${esc(label)}, ${esc(role)},
       ${esc(userId)}, ${esc(now)}, NULL, 1, ${esc(maxStorage)}, ${esc(rateLimit)})
  `);

  const record = mapRow({ id, keyHash, label, role, userId, createdAt: now, lastUsed: null, enabled: 1, maxStorage, rateLimit });
  return { record, rawKey };
}

/** @returns {{ record, rawKey }} — rawKey ditampilkan hanya sekali! */
export function createKey({ label, role = 'user', maxStorage = 0, rateLimit = 0, userId = null }) {
  const { record, rawKey } = _createInternal({ label, role, maxStorage, rateLimit, userId });
  logger.info(` API key dibuat: "${label}" (${role}) id=${record.id}`);
  return { record, rawKey };
}

export function verifyKey(rawKey) {
  if (!rawKey || typeof rawKey !== 'string') return null;
  const keyHash = hashKey(rawKey.trim());
  const rows    = qSelect(`SELECT * FROM ${TABLE} WHERE keyHash = ${esc(keyHash)}`);
  if (rows.length === 0) return null;
  const record  = mapRow(rows[0]);
  if (!record || !record.enabled) return null;
  // FIX: gunakan safeRow() agar keyHash tidak bocor ke caller (konsisten dengan getKey())
  return safeRow(record);
}

export function touchKey(id) {
  q(`UPDATE ${TABLE} SET lastUsed = ${esc(new Date().toISOString())} WHERE id = ${esc(id)}`);
}

export function listKeys() {
  return qSelect(`SELECT * FROM ${TABLE}`).map(r => safeRow(mapRow(r)));
}

export function getKey(id) {
  const rows = qSelect(`SELECT * FROM ${TABLE} WHERE id = ${esc(id)}`);
  return rows.length > 0 ? safeRow(mapRow(rows[0])) : null;
}

export function revokeKey(id) {
  if (!getKey(id)) return false;
  q(`UPDATE ${TABLE} SET enabled = 0 WHERE id = ${esc(id)}`);
  logger.info(` API key direvoke: id=${id}`);
  return true;
}

export function enableKey(id) {
  if (!getKey(id)) return false;
  q(`UPDATE ${TABLE} SET enabled = 1 WHERE id = ${esc(id)}`);
  return true;
}

export function deleteKey(id) {
  if (!getKey(id)) return false;
  q(`DELETE FROM ${TABLE} WHERE id = ${esc(id)}`);
  logger.info(` API key dihapus: id=${id}`);
  return true;
}

export function updateKey(id, updates) {
  if (!getKey(id)) return false;
  // FIX Bug 3: tambahkan 'enabled' ke allowed agar PUT /api/admin/users/[id]
  // bisa toggle enable/disable key. esc() sudah menangani boolean → 0/1 dengan benar.
  const allowed = ['label', 'maxStorage', 'rateLimit', 'role', 'enabled'];
  const sets    = [];
  for (const k of allowed) {
    if (updates[k] !== undefined) sets.push(`${k} = ${esc(updates[k])}`);
  }
  if (sets.length === 0) return true;
  q(`UPDATE ${TABLE} SET ${sets.join(', ')} WHERE id = ${esc(id)}`);
  return true;
}

/** @returns {string} rawKey baru — tampilkan hanya sekali! */
export function rotateKey(id) {
  if (!getKey(id)) return null;
  const rawKey  = generateRawKey();
  const keyHash = hashKey(rawKey);
  q(`UPDATE ${TABLE} SET keyHash = ${esc(keyHash)}, lastUsed = NULL WHERE id = ${esc(id)}`);
  logger.info(` API key dirotasi: id=${id}`);
  return rawKey;
}

/**
 * Set custom API key value (hanya untuk plan premium/max).
 * Validasi format dilakukan di level route, bukan di sini.
 * @returns {boolean}
 */
export function setCustomKey(id, customValue) {
  if (!getKey(id)) return false;
  if (!customValue || typeof customValue !== 'string') return false;

  // FIX: Selaraskan min-length dengan validasi di route keys/[id]/[action]/route.js.
  // Sebelumnya service menolak di 8 karakter, route menolak di 10 — inconsistency
  // yang memungkinkan bypass route validation jika service dipanggil langsung.
  if (customValue.length < 10) {
    throw Object.assign(
      new Error('Custom key harus minimal 10 karakter.'),
      { status: 400 }
    );
  }

  // FIX Bug 2: Selaraskan regex dengan validasi di route keys/[id]/[action]/route.js.
  // Route mengizinkan titik (.) dalam custom key, tapi service sebelumnya tidak —
  // menyebabkan key seperti "my.api.key" lolos validasi route lalu ditolak service
  // dengan pesan error yang membingungkan.
  if (!/^[a-zA-Z0-9_\-\.]+$/.test(customValue)) {
    throw Object.assign(
      new Error('Custom key hanya boleh menggunakan huruf, angka, underscore, dash, dan titik.'),
      { status: 400 }
    );
  }

  const keyHash = hashKey(customValue);

  // BUG-SEC FIX: Cek apakah keyHash sudah digunakan key lain.
  // Tanpa ini, dua user bisa set custom key yang sama — verifyKey() mengembalikan
  // rows[0] (user pertama) sehingga user kedua bisa login sebagai user pertama.
  const existing = qSelect(`SELECT id FROM ${TABLE} WHERE keyHash = ${esc(keyHash)}`);
  if (existing.length > 0 && existing[0].id !== id) {
    throw Object.assign(
      new Error('Custom key sudah digunakan oleh pengguna lain. Pilih nilai yang berbeda.'),
      { status: 409 }
    );
  }

  q(`UPDATE ${TABLE} SET keyHash = ${esc(keyHash)}, lastUsed = NULL WHERE id = ${esc(id)}`);
  logger.info(` API key di-custom: id=${id}`);
  return true;
}
