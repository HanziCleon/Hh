import crypto from 'crypto';
import { q, esc, qSelect, ensureTable, ensureIndex, withTransaction } from '../lib/dongtube.js'; // FIX-8: q() untuk mutasi, qSelect() hanya untuk SELECT
import { logger }    from '../utils/logger.js';
import { createKey, deleteKey } from './KeyManager.js';
import { listFiles, deleteRecord } from './DatabaseService.js';
import { deleteFile }  from './StorageService.js';
import { kvListAll, kvDelete } from './KVService.js';

const TABLE = 'users';

function generateUserId() {
  return `dtdb_user_${crypto.randomBytes(8).toString('hex')}`;
}

function mapRow(row) {
  if (!row) return null;
  return {
    id:               row.id,
    googleId:         row.googleId,
    email:            row.email,
    name:             row.name,
    picture:          row.picture || null,
    keyId:            row.keyId,
    plan:             row.plan || 'free',
    // FIX: field plan yang sebelumnya tidak di-map → expiry selalu null
    planExpiry:       row.planExpiry       || null,
    planActivatedAt:  row.planActivatedAt  || null,
    planGrantedBy:    row.planGrantedBy    || null,
    createdAt:        row.createdAt,
    lastLogin:        row.lastLogin,
  };
}

function safeRow(u) {
  if (!u) return null;
  const { googleId, ...safe } = u;
  return safe;
}

export async function initUserService() {
  ensureTable(TABLE);
  ensureIndex(TABLE, 'googleId');
  ensureIndex(TABLE, 'email');
  ensureIndex(TABLE, 'keyId');
  logger.info(`UserService: tabel '${TABLE}' siap`);
}

/** @returns {{ user, apiKey, keyId, isNew }} — apiKey hanya ada saat user baru */
export async function findOrCreateUser({ googleId, email, name, picture }) {
  const rows = qSelect(`SELECT * FROM ${TABLE} WHERE googleId = ${esc(googleId)}`);

  if (rows.length > 0) {
    const user = mapRow(rows[0]);
    const now  = new Date().toISOString();
    q(`
      UPDATE ${TABLE}
      SET name = ${esc(name)}, picture = ${esc(picture)}, lastLogin = ${esc(now)}
      WHERE id = ${esc(user.id)}
    `);
    return { user: safeRow({ ...user, name, picture, lastLogin: now }), apiKey: null, isNew: false };
  }

  const id  = generateUserId();
  const now = new Date().toISOString();

  // FIX BUG #1: Bungkus createKey() + INSERT users dalam withTransaction agar atomic.
  // Sebelumnya: jika INSERT users gagal setelah createKey() berhasil, akan ada orphan
  // api_key di tabel api_keys yang tidak pernah bisa diklaim oleh siapapun.
  // withTransaction() meng-handle kedua store (db + users) sekaligus — rollback otomatis
  // jika salah satu operasi melempar exception.
  let keyRecord, rawKey;
  const user = withTransaction(() => {
    const created = createKey({
      label:      email,
      role:       'user',
      userId:     id,   // FIX: tulis userId ke api_keys agar backup filter k.userId bekerja
      maxStorage: parseInt(process.env.FREE_STORAGE_BYTES) || 10485760,
      rateLimit:  parseInt(process.env.FREE_RATE_LIMIT)    || 100,
    });
    keyRecord = created.record;
    rawKey    = created.rawKey;

    q(`
      INSERT INTO ${TABLE}
        (id, googleId, email, name, picture, keyId, plan, planExpiry, createdAt, lastLogin)
      VALUES
        (${esc(id)}, ${esc(googleId)}, ${esc(email)}, ${esc(name)},
         ${esc(picture)}, ${esc(keyRecord.id)}, 'free', NULL, ${esc(now)}, ${esc(now)})
    `);

    return {
      id, googleId, email, name, picture: picture || null,
      keyId: keyRecord.id, plan: 'free',
      planExpiry: null, planActivatedAt: null, planGrantedBy: null,
      createdAt: now, lastLogin: now,
    };
  });

  logger.info(`User baru: ${email} (id=${id})`);
  return { user: safeRow(user), apiKey: rawKey, keyId: keyRecord.id, isNew: true };
}

export function getUserById(id) {
  const rows = qSelect(`SELECT * FROM ${TABLE} WHERE id = ${esc(id)}`);
  return rows.length > 0 ? safeRow(mapRow(rows[0])) : null;
}

export function getUserByKeyId(keyId) {
  const rows = qSelect(`SELECT * FROM ${TABLE} WHERE keyId = ${esc(keyId)}`);
  return rows.length > 0 ? safeRow(mapRow(rows[0])) : null;
}

export function listUsers() {
  return qSelect(`SELECT * FROM ${TABLE}`).map(r => safeRow(mapRow(r)));
}

/** Cascade delete: files → KV data → API key → user record */
export function deleteUser(id) {
  const rows = qSelect(`SELECT * FROM ${TABLE} WHERE id = ${esc(id)}`);
  if (rows.length === 0) return false;
  const u = mapRow(rows[0]);

  if (u.keyId) {
    try {
      // BUG FIX (Putaran 4): Gunakan noLimit:true agar SEMUA file user dihapus.
      // limit:10000 masih bisa terpotong jika user punya >10000 file.
      const { items } = listFiles({ apiKeyId: u.keyId, noLimit: true });
      for (const file of items) {
        try { deleteFile(file.category, file.storedName); } catch (_) {}
        deleteRecord(file.id);
      }
      logger.info(`Deleted ${items.length} file(s) untuk user ${u.email}`);
    } catch (err) {
      logger.error(`Gagal hapus file user ${u.email}: ${err.message}`);
    }

    try {
      const kvEntries = kvListAll(`u:${u.keyId}/`);
      for (const entry of kvEntries) {
        try { kvDelete(entry.key); } catch (_) {}
      }
      logger.info(`Deleted ${kvEntries.length} KV entry(ies) untuk user ${u.email}`);
    } catch (err) {
      logger.error(`Gagal hapus KV user ${u.email}: ${err.message}`);
    }

    deleteKey(u.keyId);
  }

  q(`DELETE FROM ${TABLE} WHERE id = ${esc(id)}`);

  // BUG-M1 FIX: Hapus subscription records agar pollAllPendingOrders() tidak
  // terus memanggil Pakasir API untuk order milik user yang sudah dihapus.
  // Tandai expired (bukan DELETE) agar audit trail tetap ada.
  try {
    q(`UPDATE subscriptions SET status = 'expired' WHERE userId = ${esc(id)}`);
  } catch (_) {}

  logger.info(`User dihapus: ${u.email} (id=${id})`);
  return true;
}

export function userCount() {
  // FIX #7: Hindari SELECT * hanya untuk .length — cukup SELECT id (lebih ringan).
  // Catatan: JsonDB belum mendukung COUNT(*), jadi kita ambil kolom minimal.
  return qSelect(`SELECT id FROM ${TABLE}`).length;
}
