/**
 * SubscriptionService — Kelola order upgrade plan DongtubeDB
 *
 * Payment via Pakasir QRIS (sama seperti V7/Dongtube)
 * Flow:
 *   1. User klik upgrade
 *   2. createOrder() → buat order + generate QRIS
 *   3. User bayar via QRIS
 *   4. pollOrder() atau webhook → konfirmasi pembayaran
 *   5. setPlan() → aktifkan plan
 */

// FIX-9: https/http diganti dengan fetch() bawaan — tidak perlu import manual
import crypto from 'crypto';
import { q, qSelect, esc, ensureTable } from '../lib/dongtube.js';
import { getPlan, setPlan, invalidatePlansCache } from './PlanService.js';

// ─── Config ───────────────────────────────────────────────────────────────────

// FIX BUG-PAK: Jangan cache PAK_SLUG/PAK_APIKEY di module level.
// Admin bisa update via /api/admin/settings (disimpan ke admin-settings.json).
// Jika di-cache saat modul load, perubahan tidak efektif sampai server restart.
// Gunakan getter dinamis yang baca env + file override setiap kali dibutuhkan.
import fs   from 'fs';
import path from 'path';

function _getPakConfig() {
  const DATA_DIR      = process.env.DATA_DIR || './data';
  const SETTINGS_PATH = path.join(DATA_DIR, 'admin-settings.json');
  let overrides = {};
  try { overrides = JSON.parse(fs.readFileSync(SETTINGS_PATH, 'utf-8')); } catch {}
  return {
    slug:   overrides.pakasirSlug  || process.env.PAKASIR_SLUG   || '',
    apiKey: process.env.PAKASIR_APIKEY || '', // tetap dari env (field ini dienkripsi di file)
    ttl:    (overrides.orderTtlMin !== undefined
              ? Number(overrides.orderTtlMin)
              : parseInt(process.env.ORDER_TTL_MIN || '30')
            ) * 60 * 1000,
  };
}

// Baca ORDER_TTL sekali saat startup untuk interval checks (bukan kritis)
const ORDER_TTL  = parseInt(process.env.ORDER_TTL_MIN || '30') * 60 * 1000;

// FIX HMR: Mutex di global scope agar tidak reset saat Next.js hot-reload di development.
// Race condition double-order sangat kritis — dua QRIS bisa ter-generate untuk 1 user.
if (!global.__dtdb_order_locks) global.__dtdb_order_locks = new Map();
const _orderLocks = global.__dtdb_order_locks;

async function withOrderLock(userId, fn) {
  while (_orderLocks.get(userId)) await _orderLocks.get(userId);
  let resolve;
  const lock = new Promise(r => { resolve = r; });
  _orderLocks.set(userId, lock);
  try { return await fn(); }
  finally { _orderLocks.delete(userId); resolve(); }
}

// ─── Schema Init ──────────────────────────────────────────────────────────────

export function initSubscriptionService() {
  ensureTable('subscriptions');
  // subscriptions: {
  //   id, userId, userEmail, userName,
  //   plan, amount, orderId,
  //   status (pending|paid|failed|expired),
  //   qrisString, payUrl,
  //   paidAt, expiresAt (order TTL), createdAt
  //   activatedFor (ISO date)
  // }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

// FIX: Ganti Math.random() dengan crypto.randomBytes() (CSPRNG).
// orderId dipakai sebagai identifikasi transaksi pembayaran — jika bisa ditebak,
// penyerang bisa mengklaim pembayaran orang lain.
function _genOrderId() {
  const ts  = Date.now().toString(36).toUpperCase();
  const rnd = crypto.randomBytes(4).toString('hex').toUpperCase();
  return `DTDB-${ts}-${rnd}`;
}

// FIX-9: Ganti _httpPost/_httpGet custom dengan fetch() bawaan Node.js/Next.js
// fetch() sudah handle redirect 301/302 secara otomatis, lebih ringkas dan reliable.
async function _httpPost(url, data) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  try {
    const res = await fetch(url, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
      body:    JSON.stringify(data),
      signal:  controller.signal,
    });
    const text = await res.text();
    try { return JSON.parse(text); } catch { return text; }
  } finally {
    clearTimeout(timer);
  }
}

async function _httpGet(url) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);
  try {
    const res = await fetch(url, {
      method:  'GET',
      headers: { 'Cache-Control': 'no-store', 'Pragma': 'no-cache' },
      signal:  controller.signal,
    });
    const text = await res.text();
    try { return JSON.parse(text); } catch { return text; }
  } finally {
    clearTimeout(timer);
  }
}

// ─── Pakasir Integration ─────────────────────────────────────────────────────

async function _pakasirCreate(orderId, amount) {
  const { slug: PAK_SLUG, apiKey: PAK_APIKEY } = _getPakConfig();
  if (!PAK_SLUG || !PAK_APIKEY) throw new Error('Pakasir belum dikonfigurasi. Set PAKASIR_SLUG dan PAKASIR_APIKEY di .env');

  const data = await _httpPost('https://app.pakasir.com/api/transactioncreate/qris', {
    project:  PAK_SLUG,
    order_id: orderId,
    amount,
    api_key:  PAK_APIKEY,
  });

  if (!data || (!data.payment && !data.data)) {
    throw new Error((data && data.message) || 'Pakasir: response kosong');
  }

  const pay = data.payment || data.data || data;

  const qrisString =
    pay.payment_number || pay.qr_string  || pay.qris_string  ||
    pay.qr             || pay.emv        || pay.qr_code       ||
    pay.qrcode         || pay.qris       || pay.emv_qr        ||
    pay.emv_code       || pay.nmid_qr   || pay.acquirer_data || '';

  const fee = pay.fee || pay.admin_fee || pay.biaya_admin || pay.service_fee || 0;

  if (!qrisString) {
    throw new Error(
      `Pakasir tidak mengembalikan QRIS string. Response: ${JSON.stringify(pay).slice(0, 300)}`
    );
  }

  return { qrisString, fee, raw: pay };
}

async function _pakasirCheck(orderId, amount) {
  const { slug: PAK_SLUG, apiKey: PAK_APIKEY } = _getPakConfig();
  if (!PAK_SLUG || !PAK_APIKEY) throw new Error('Pakasir belum dikonfigurasi.');

  // FIX Bug #7: Ganti Authorization Bearer dengan api_key di query param,
  // konsisten dengan _pakasirCreate dan _pakasirCancel yang terbukti jalan.
  // Bearer format tidak didokumentasikan di Pakasir API.
  const url = `https://app.pakasir.com/api/transactiondetail?project=${encodeURIComponent(PAK_SLUG)}&order_id=${encodeURIComponent(orderId)}&amount=${amount}&api_key=${encodeURIComponent(PAK_APIKEY)}`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);
  let data;
  try {
    const res = await fetch(url, {
      method:  'GET',
      headers: {
        'Cache-Control': 'no-store',
        'Pragma':        'no-cache',
      },
      signal:  controller.signal,
    });
    const text = await res.text();
    try { data = JSON.parse(text); } catch { data = text; }
  } finally {
    clearTimeout(timer);
  }

  // FIX: Docs resmi Pakasir: response Transaction Detail dibungkus {"transaction": {...}}
  // Normalisasi ke flat object agar parsing status lebih mudah
  if (data && data.transaction && typeof data.transaction === 'object') {
    return data.transaction;
  }
  return data;
}

async function _pakasirCancel(orderId, amount) {
  const { slug: PAK_SLUG, apiKey: PAK_APIKEY } = _getPakConfig();
  if (!PAK_SLUG || !PAK_APIKEY) return;
  try {
    await _httpPost('https://app.pakasir.com/api/transactioncancel', {
      project:  PAK_SLUG,
      order_id: orderId,
      amount,
      api_key:  PAK_APIKEY,
    });
  } catch (e) {
    console.error('[Sub] cancel error:', e.message);
  }
}

// ─── Order Management ─────────────────────────────────────────────────────────

/**
 * Buat order baru untuk upgrade plan.
 * Kalau user sudah punya order pending yang belum expired, kembalikan itu.
 */
export async function createOrder(user, planId) {
  // FIX #5: Wrap seluruh fungsi dalam mutex per userId agar dua request bersamaan
  // tidak bisa membuat duplikat order.
  return withOrderLock(user.id, () => _createOrderLocked(user, planId));
}

async function _createOrderLocked(user, planId) {
  // Selalu flush cache sebelum buat order — pastikan harga yang dipakai adalah harga terkini
  // dari admin config, bukan cache 30 detik yang mungkin sudah stale.
  invalidatePlansCache();
  const plan = getPlan(planId);
  if (!plan || !plan.id) throw new Error(`Plan '${planId}' tidak valid`);
  if (plan.price === 0) throw new Error('Plan FREE tidak perlu pembayaran');

  // Cek apakah sudah ada order pending yang belum expired
  const existing = qSelect(
    `SELECT * FROM subscriptions WHERE userId = ${esc(user.id)} AND status = 'pending'`
  );

  for (const old of existing || []) {
    const stillValid = old.expiresAt && new Date(old.expiresAt) > new Date();
    if (stillValid && old.plan === planId) {
      // Return existing order yang masih valid dan sama plannya
      return {
        orderId:    old.orderId,
        plan:       old.plan,
        amount:     old.amount,
        qrisString: old.qrisString,
        expiresAt:  old.expiresAt,
        status:     old.status,
        isExisting: true,
      };
    }
    // FIX #5: Expire semua pending order lama — baik yang TTL-nya habis maupun
    // yang masih valid tapi untuk plan berbeda. Mencegah user akumulasi banyak
    // QRIS aktif sekaligus jika berkali-kali ganti pilihan plan.
    q(`UPDATE subscriptions SET status = 'expired' WHERE id = ${esc(old.id)}`);
    await _pakasirCancel(old.orderId, old.amount).catch(() => {});
  }

  const orderId    = _genOrderId();
  const amount     = plan.price;
  const now        = new Date();
  const expiresAt  = new Date(now.getTime() + ORDER_TTL).toISOString();
  const id         = `sub_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;

  // Buat QRIS via Pakasir
  const { qrisString, fee } = await _pakasirCreate(orderId, amount);

  // Simpan order ke DB
  q(`INSERT INTO subscriptions (id, userId, userEmail, userName, plan, amount, fee, orderId, status, qrisString, expiresAt, createdAt)
     VALUES (
       ${esc(id)}, ${esc(user.id)}, ${esc(user.email)}, ${esc(user.name)},
       ${esc(planId)}, ${esc(amount)}, ${esc(fee)}, ${esc(orderId)},
       'pending', ${esc(qrisString)}, ${esc(expiresAt)}, ${esc(now.toISOString())}
     )`);

  return {
    orderId,
    plan:      planId,
    planName:  plan.name,
    amount,
    fee,
    qrisString,
    expiresAt,
    status:    'pending',
    isExisting: false,
  };
} // end _createOrderLocked

/**
 * Cek status pembayaran order.
 * Kalau sudah bayar → aktifkan plan.
 */
export async function checkOrder(orderId, userId) {
  const rows = qSelect(
    `SELECT * FROM subscriptions WHERE orderId = ${esc(orderId)}`
  );
  const order = rows?.[0];

  if (!order) return { found: false };
  if (order.userId !== userId) return { found: false }; // Bukan punya dia

  // Sudah paid/failed/expired → langsung return
  if (order.status !== 'pending') {
    return { found: true, status: order.status, plan: order.plan, order };
  }

  // Cek apakah order TTL sudah expired
  if (order.expiresAt && new Date(order.expiresAt) < new Date()) {
    q(`UPDATE subscriptions SET status = 'expired' WHERE orderId = ${esc(orderId)}`);
    await _pakasirCancel(orderId, order.amount).catch(() => {});
    return { found: true, status: 'expired', plan: order.plan, order };
  }

  // Poll Pakasir
  let pakResponse;
  try {
    pakResponse = await _pakasirCheck(orderId, order.amount);
  } catch (e) {
    console.error('[Sub] checkOrder poll error:', e.message);
    return { found: true, status: 'pending', plan: order.plan, order };
  }

  // Debug log — hanya aktif jika DEBUG=true
  if (process.env.DEBUG === 'true') {
    console.log(`[Sub] Pakasir response for ${orderId}:`, JSON.stringify(pakResponse).slice(0, 300));
  }

  // ── Deteksi status dari SEMUA kemungkinan format response Pakasir ──────────
  // Kumpulkan semua string yang ada di response untuk dicek
  const _raw = JSON.stringify(pakResponse || '').toLowerCase();

  // FIX: Docs resmi Pakasir — status field adalah "completed".
  // Response Transaction Detail API: {"transaction": {"status": "completed", ...}}
  // Setelah _pakasirCheck dinormalisasi, kita tinggal baca .status langsung.
  const _statusStr = (
    pakResponse?.status                  ||  // field utama per docs Pakasir
    pakResponse?.payment_status          ||  // alias umum payment gateway lain
    pakResponse?.transaction_status      ||
    pakResponse?.message                 ||
    ''
  ).toString().toLowerCase();

  const isPaid =
    // "completed" adalah status resmi Pakasir per docs, sisanya alias kompatibel
    ['completed', 'paid', 'success', 'settlement', 'berhasil']
      .some(s => _statusStr.includes(s)) ||
    // Fallback: cek seluruh body hanya jika status field kosong
    (_statusStr === '' && ['completed', 'settlement', 'success', 'paid'].some(s => _raw.includes(s)));

  const isFailed =
    ['failed', 'failure', 'cancel', 'denied', 'expired', 'gagal']
      .some(s => _statusStr.includes(s));

  if (isPaid) {
    // FIX BUG 1: JsonDB q() selalu return null untuk UPDATE — jangan andalkan return value-nya.
    // Lakukan UPDATE dulu, lalu re-fetch untuk cek apakah berhasil (status berubah ke 'paid').
    q(
      `UPDATE subscriptions SET status = 'paid', paidAt = ${esc(new Date().toISOString())}
       WHERE orderId = ${esc(orderId)} AND status = 'pending'`
    );

    // Re-fetch: kalau status bukan 'paid' → sudah diproses proses lain (webhook/polling)
    const fresh = qSelect(`SELECT * FROM subscriptions WHERE orderId = ${esc(orderId)}`);
    if (fresh?.[0]?.status !== 'paid') {
      return { found: true, status: fresh?.[0]?.status || 'paid', plan: order.plan, order };
    }

    // Aktifkan plan
    const planResult = setPlan(userId, order.plan, 30, `payment:${orderId}`);
    if (process.env.DEBUG === 'true') {
      console.log(`[Sub] ✅ Plan ${order.plan} aktif untuk user via poll: ${orderId}`);
    }

    return {
      found:   true,
      status:  'paid',
      plan:    order.plan,
      order,
      planResult,
    };
  }

  if (isFailed) {
    q(`UPDATE subscriptions SET status = 'failed' WHERE orderId = ${esc(orderId)}`);
    return { found: true, status: 'failed', plan: order.plan, order };
  }

  return { found: true, status: 'pending', plan: order.plan, order };
}

/**
 * Webhook dari Pakasir (payment callback)
 */
export async function handleWebhook(payload, opts = {}) {
  // FIX: Pakasir webhook body per docs resmi:
  // { amount, order_id, project, status: "completed", payment_method, completed_at }
  const orderId = payload.order_id || payload.orderId || payload.reference;
  if (!orderId) return { ok: false, msg: 'order_id tidak ada' };

  const rows = qSelect(`SELECT * FROM subscriptions WHERE orderId = ${esc(orderId)}`);
  const order = rows?.[0];
  if (!order) return { ok: false, msg: 'Order tidak ditemukan' };
  if (order.status !== 'pending') return { ok: true, msg: 'Already processed' };

  // Validasi amount sesuai rekomendasi docs Pakasir:
  // "pastikan amount dan order_id sesuai dengan transaksi di sistem Anda"
  const webhookAmount = Number(payload.amount || 0);
  if (webhookAmount && webhookAmount !== order.amount) {
    console.warn(`[Sub] ⚠️ Amount mismatch webhook: ${webhookAmount} vs DB: ${order.amount} (${orderId})`);
    return { ok: false, msg: 'Amount tidak sesuai' };
  }

  // FIX status: Pakasir pakai "completed" (bukan "paid"/"success")
  const statusRaw = (
    payload.status || payload.payment_status || ''
  ).toString().toLowerCase();

  const isPaidWebhook = ['completed', 'paid', 'success', 'settlement', 'berhasil']
    .some(s => statusRaw.includes(s));

  if (!isPaidWebhook) {
    return { ok: true, msg: 'Not paid yet', status: statusRaw };
  }

  // FIX: Cross-verify ke Transaction Detail API Pakasir sebelum aktifkan plan
  // Ini adalah langkah keamanan yang direkomendasikan resmi oleh Pakasir docs
  if (opts.crossVerify) {
    try {
      const verified = await _pakasirCheck(orderId, order.amount);
      const verifiedStatus = (verified?.status || '').toLowerCase();
      const isConfirmed = ['completed', 'paid', 'success', 'settlement'].some(s => verifiedStatus.includes(s));

      if (!isConfirmed) {
        console.warn(`[Sub] ⚠️ Cross-verify gagal untuk ${orderId}: status=${verifiedStatus}`);
        return { ok: false, msg: `Pembayaran belum terkonfirmasi (status: ${verifiedStatus})` };
      }
      if (process.env.DEBUG === 'true') {
        console.log(`[Sub] ✅ Cross-verify sukses untuk ${orderId}: status=${verifiedStatus}`);
      }
    } catch (e) {
      console.error(`[Sub] Cross-verify error untuk ${orderId}:`, e.message);
      // Jika API Pakasir down, tolak sementara daripada aktifkan plan secara blind
      return { ok: false, msg: 'Gagal verifikasi ke Pakasir API. Coba lagi.' };
    }
  }

  const now = new Date().toISOString();
  // BUG-FIX: Tambahkan AND status = 'pending' agar UPDATE idempoten.
  // Jika polling sudah memproses order ini lebih dulu, UPDATE tidak mengubah apapun.
  // Re-fetch setelah UPDATE untuk verifikasi sebelum memanggil setPlan() —
  // mencegah double-activation jika webhook dan polling berjalan hampir bersamaan.
  q(`UPDATE subscriptions SET status = 'paid', paidAt = ${esc(now)} WHERE orderId = ${esc(orderId)} AND status = 'pending'`);

  // Re-fetch: jika status bukan 'paid' → sudah diproses proses lain, skip setPlan
  const freshCheck = qSelect(`SELECT * FROM subscriptions WHERE orderId = ${esc(orderId)}`);
  if (freshCheck?.[0]?.status !== 'paid') {
    return { ok: true, msg: 'Already processed by another handler', status: freshCheck?.[0]?.status };
  }

  const planResult = setPlan(order.userId, order.plan, 30, `webhook:${orderId}`);

  if (process.env.DEBUG === 'true') {
    console.log(`[Sub] ✅ Plan ${order.plan} aktif untuk user ${order.userEmail} via webhook: ${orderId}`);
  }
  return { ok: true, msg: 'Plan activated', planResult };
}

/**
 * Ambil history subscription user
 */
export function getUserSubscriptions(userId, limit = 10) {
  const rows = qSelect(
    `SELECT * FROM subscriptions WHERE userId = ${esc(userId)}`
  );
  if (!rows) return [];
  return rows
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, limit)
    .map(r => ({
      orderId:   r.orderId,
      plan:      r.plan,
      amount:    r.amount,
      status:    r.status,
      paidAt:    r.paidAt,
      expiresAt: r.expiresAt,
      createdAt: r.createdAt,
    }));
}

/**
 * Admin: ambil semua subscription (semua user)
 */
export function getAllSubscriptions(limit = 100) {
  const rows = qSelect(`SELECT * FROM subscriptions`);
  if (!rows) return [];
  return rows
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, limit);
}

/**
 * Polling aktif — cek semua order pending ke Pakasir Transaction Detail API.
 *
 * Dipanggil oleh cron di init.js setiap PAYMENT_POLL_INTERVAL_MS milidetik.
 * Tidak butuh webhook, tidak butuh konfigurasi apapun di dashboard Pakasir.
 *
 * Flow:
 *  1. Ambil semua order dengan status 'pending' dari DB
 *  2. Skip yang sudah expired (TTL habis)
 *  3. Panggil Pakasir Transaction Detail API per order
 *  4. Jika status "completed" → aktifkan plan user
 *  5. Jika status gagal/cancel → tandai failed
 */
export async function pollAllPendingOrders() {
  const rows = qSelect(`SELECT * FROM subscriptions WHERE status = 'pending'`);
  if (!rows || rows.length === 0) return { checked: 0, activated: 0 };

  const now      = new Date();
  let checked    = 0;
  let activated  = 0;

  for (const order of rows) {
    // Skip order yang TTL-nya sudah lewat — biarkan expirePendingOrders() yang handle
    if (order.expiresAt && new Date(order.expiresAt) < now) continue;

    checked++;

    try {
      const data = await _pakasirCheck(order.orderId, order.amount);

      // Setelah _pakasirCheck, response sudah dinormalisasi ke flat object
      // per docs Pakasir: {"transaction": {"status": "completed", ...}}
      const statusRaw = (
        data?.status ||
        data?.payment_status ||
        ''
      ).toString().toLowerCase();

      const isPaid = ['completed', 'paid', 'success', 'settlement', 'berhasil']
        .some(s => statusRaw.includes(s));

      const isFailed = ['failed', 'failure', 'cancel', 'denied', 'expired', 'gagal']
        .some(s => statusRaw.includes(s));

      if (isPaid) {
        const paidAt = data?.completed_at || now.toISOString();
        // FIX BUG 2: JsonDB q() selalu return null untuk UPDATE — jangan andalkan return value-nya.
        // Lakukan UPDATE dulu, lalu re-fetch untuk cek apakah status berubah ke 'paid'.
        q(
          `UPDATE subscriptions SET status = 'paid', paidAt = ${esc(paidAt)}
           WHERE orderId = ${esc(order.orderId)} AND status = 'pending'`
        );
        const freshRow = qSelect(`SELECT * FROM subscriptions WHERE orderId = ${esc(order.orderId)}`);
        if (freshRow?.[0]?.status === 'paid') {
          // BUG-M1 FIX: Skip setPlan jika user sudah dihapus — cegah UPDATE yang
          // silently fail dan request Pakasir sia-sia di polling berikutnya.
          const userStillExists = qSelect(`SELECT id FROM users WHERE id = ${esc(order.userId)}`)?.[0];
          if (!userStillExists) {
            q(`UPDATE subscriptions SET status = 'expired' WHERE orderId = ${esc(order.orderId)}`);
            continue;
          }
          setPlan(order.userId, order.plan, 30, `poll:${order.orderId}`);
          if (process.env.DEBUG === 'true') {
            console.log(`[Sub] ✅ Polling: plan ${order.plan} aktif untuk ${order.userEmail} (${order.orderId})`);
          }
          activated++;
        }
      } else if (isFailed) {
        q(`UPDATE subscriptions SET status = 'failed' WHERE orderId = ${esc(order.orderId)}`);
        if (process.env.DEBUG === 'true') {
          console.log(`[Sub] ❌ Polling: order ${order.orderId} failed (status: ${statusRaw})`);
        }
      }
    } catch (e) {
      // Gagal cek satu order → skip, coba lagi di interval berikutnya
      console.error(`[Sub] Polling error untuk ${order.orderId}: ${e.message}`);
    }
  }

  return { checked, activated };
}


/**
 * Cron: expire pending orders yang sudah lewat TTL
 */
export function expirePendingOrders() {
  const now = new Date().toISOString();
  const rows = qSelect(
    `SELECT * FROM subscriptions WHERE status = 'pending'`
  );
  if (!rows) return 0;

  let count = 0;
  for (const row of rows) {
    if (row.expiresAt && row.expiresAt < now) {
      q(`UPDATE subscriptions SET status = 'expired' WHERE orderId = ${esc(row.orderId)}`);
      count++;
    }
  }
  return count;
}

/**
 * Admin: konfirmasi manual order (bypass Pakasir check)
 * Digunakan ketika polling tidak berhasil tapi user sudah bayar
 */
export function adminConfirmOrder(orderId, adminId = 'admin') {
  const rows = qSelect(`SELECT * FROM subscriptions WHERE orderId = ${esc(orderId)}`);
  const order = rows?.[0];
  if (!order) return { ok: false, msg: 'Order tidak ditemukan' };
  if (order.status === 'paid') return { ok: true, msg: 'Sudah paid sebelumnya' };

  const now = new Date().toISOString();
  q(`UPDATE subscriptions SET status = 'paid', paidAt = ${esc(now)} WHERE orderId = ${esc(orderId)}`);

  // BUG-FIX: Cek apakah user masih ada sebelum setPlan() — konsisten dengan pollAllPendingOrders
  const userStillExists = qSelect(`SELECT id FROM users WHERE id = ${esc(order.userId)}`)?.[0];
  if (!userStillExists) {
    q(`UPDATE subscriptions SET status = 'expired' WHERE orderId = ${esc(orderId)}`);
    console.warn(`[Sub] Admin ${adminId} konfirmasi order ${orderId} tapi user ${order.userId} sudah dihapus — order diexpire`);
    return { ok: false, msg: 'User sudah dihapus, order diexpire', order };
  }

  const planResult = setPlan(order.userId, order.plan, 30, `admin-confirm:${adminId}`);
  // Admin action selalu dicatat — ini audit trail, bukan debug log
  console.info(`[Sub] Admin ${adminId} konfirmasi manual order ${orderId}`);
  return { ok: true, msg: 'Plan diaktifkan', planResult, order };
}

/**
 * Ambil semua subscriptions dengan filter status
 */
export function getSubscriptionsByStatus(status, limit = 100) {
  const rows = qSelect(
    status === 'all'
      ? `SELECT * FROM subscriptions`
      : `SELECT * FROM subscriptions WHERE status = ${esc(status)}`
  );
  if (!rows) return [];
  return rows
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, limit);
}
