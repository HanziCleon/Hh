/**
 * PlanService — Definisi & enforcement subscription plan DongtubeDB
 *
 * Plans didefinisikan secara default di PLANS_DEFAULT, tapi bisa
 * di-override admin lewat plans-config.json (via /api/admin/plans).
 *
 * Urutan prioritas:
 *   plans-config.json (admin UI) > PLANS_DEFAULT (hardcoded fallback)
 */

import fs   from 'fs';
import path from 'path';
import { q, qSelect, esc, ensureTable } from '../lib/dongtube.js';
import { updateKey } from './KeyManager.js';

// ─── Helper: format bytes → label yang terbaca manusia ────────────────────────
function _formatBytes(b) {
  b = Number(b) || 0;
  if (b >= 1073741824) return `${(b / 1073741824).toFixed(1).replace(/\.0$/, '')} GB`;
  if (b >= 1048576)    return `${(b / 1048576).toFixed(1).replace(/\.0$/, '')} MB`;
  if (b >= 1024)       return `${(b / 1024).toFixed(1).replace(/\.0$/, '')} KB`;
  return `${b} B`;
}

// ─── Default Plans (fallback jika plans-config.json belum ada) ───────────────

// FIX BUG 1: storageBytes dibaca dari env, storageLabel dihitung otomatis
// Sebelumnya storageLabel hardcoded ('500 MB', '1 GB') sehingga tidak berubah
// meski env var sudah diganti.
const _FREE_BYTES    = parseInt(process.env.FREE_STORAGE_BYTES    || '10485760');
const _PREMIUM_BYTES = parseInt(process.env.PREMIUM_STORAGE_BYTES || '524288000');
const _MAX_BYTES     = parseInt(process.env.MAX_STORAGE_BYTES     || '1073741824');

const PLANS_DEFAULT = {
  free: {
    id:           'free',
    name:         'FREE',
    storageBytes: _FREE_BYTES,
    storageLabel: _formatBytes(_FREE_BYTES),   // ← dihitung dari env, bukan hardcoded
    price:        0,
    priceLabel:   'Gratis',
    color:        '#6b7280',
    rateLimit:    parseInt(process.env.FREE_RATE_LIMIT    || '100'),
    customApiKey: false,
    features: [
      `${_formatBytes(_FREE_BYTES)} storage`,
      'KV Store + File Upload',
      'API Key otomatis (random)',
      `Rate limit: ${parseInt(process.env.FREE_RATE_LIMIT || '100')} req/menit`,
    ],
  },
  premium: {
    id:           'premium',
    name:         'PREMIUM',
    storageBytes: _PREMIUM_BYTES,
    storageLabel: _formatBytes(_PREMIUM_BYTES), // ← dihitung dari env
    price:        10000,
    priceLabel:   'Rp 10.000 / bulan',
    color:        '#a855f7',
    rateLimit:    parseInt(process.env.PREMIUM_RATE_LIMIT || '1000'),
    customApiKey: true,
    features: [
      `${_formatBytes(_PREMIUM_BYTES)} storage`,
      'KV Store + File Upload',
      'Custom API Key',
      `Rate limit: ${parseInt(process.env.PREMIUM_RATE_LIMIT || '1000').toLocaleString('id-ID')} req/menit`,
      'Priority support',
    ],
  },
  max: {
    id:           'max',
    name:         'MAX',
    storageBytes: _MAX_BYTES,
    storageLabel: _formatBytes(_MAX_BYTES),     // ← dihitung dari env
    price:        15000,
    priceLabel:   'Rp 15.000 / bulan',
    color:        '#f59e0b',
    rateLimit:    parseInt(process.env.MAX_RATE_LIMIT     || '5000'),
    customApiKey: true,
    features: [
      `${_formatBytes(_MAX_BYTES)} storage`,
      'KV Store + File Upload',
      'Custom API Key',
      `Rate limit: ${parseInt(process.env.MAX_RATE_LIMIT || '5000').toLocaleString('id-ID')} req/menit`,
      'Priority support',
      'Advanced stats',
    ],
  },
};

// ─── Plans Config Cache ───────────────────────────────────────────────────────

const DATA_DIR       = process.env.DATA_DIR || './data';
const PLANS_CFG_PATH = path.join(DATA_DIR, 'plans-config.json');

let _plansCache    = null;   // Map: planId → planObject
let _plansCacheAt  = 0;      // timestamp cache terakhir diisi
const CACHE_TTL_MS = 30_000; // refresh cache tiap 30 detik

/**
 * Baca plans dari plans-config.json (admin UI).
 * Kalau file belum ada atau parse error → fallback ke PLANS_DEFAULT.
 * Cache 30 detik untuk efisiensi — tidak perlu baca disk setiap request.
 */
function _loadPlansConfig() {
  const now = Date.now();
  if (_plansCache && (now - _plansCacheAt) < CACHE_TTL_MS) return _plansCache;

  let merged = { ...PLANS_DEFAULT };

  try {
    const raw   = fs.readFileSync(PLANS_CFG_PATH, 'utf-8');
    const cfgArr = JSON.parse(raw); // array of plan objects

    if (Array.isArray(cfgArr)) {
      for (const cfg of cfgArr) {
        if (!cfg.id) continue;
        const def = PLANS_DEFAULT[cfg.id] || {};
        // Merge: cfg fields override default, tapi tetap inherit fields yang tidak ada di cfg
        const mergedBytes = Number(cfg.storageBytes ?? def.storageBytes ?? 0);
        merged[cfg.id] = {
          ...def,
          ...cfg,
          // Pastikan storageBytes selalu number
          storageBytes: mergedBytes,
          // FIX BUG 1: storageLabel dihitung otomatis jika tidak di-set manual di config
          storageLabel: cfg.storageLabel || _formatBytes(mergedBytes),
          rateLimit:    Number(cfg.rateLimit    ?? def.rateLimit    ?? 0),
          price:        Number(cfg.price        ?? def.price        ?? 0),
        };
      }
    }
  } catch {
    // File belum ada atau JSON rusak — gunakan PLANS_DEFAULT saja
  }

  _plansCache   = merged;
  _plansCacheAt = now;
  return merged;
}

/** Invalidasi cache secara manual (dipanggil setelah admin update plans) */
export function invalidatePlansCache() {
  _plansCache   = null;
  _plansCacheAt = 0;
}

// ─── Public API ───────────────────────────────────────────────────────────────

/**
 * @deprecated Gunakan getPlan() atau getAllPlans() — PLANS ini mengikuti konfigurasi
 * aktif (plans-config.json) bukan hardcoded default, sehingga perubahan admin terefleksi.
 * Tetap diekspor untuk kompatibilitas kode lama, tapi nilainya kini adalah Proxy
 * yang membaca _loadPlansConfig() setiap akses sehingga selalu up-to-date.
 */
export const PLANS = new Proxy(
  {},
  {
    get(_, key) {
      return _loadPlansConfig()[key];
    },
    ownKeys() {
      return Object.keys(_loadPlansConfig());
    },
    has(_, key) {
      return key in _loadPlansConfig();
    },
    getOwnPropertyDescriptor(_, key) {
      const plans = _loadPlansConfig();
      if (key in plans) return { value: plans[key], writable: false, enumerable: true, configurable: true };
      return undefined;
    },
  }
);

export function getPlan(planId) {
  const plans = _loadPlansConfig();
  return plans[planId] || plans['free'] || PLANS_DEFAULT.free;
}

export function getPlanStorage(planId) {
  return getPlan(planId).storageBytes;
}

export function getAllPlans() {
  return Object.values(_loadPlansConfig());
}

// ─── Schema Init ──────────────────────────────────────────────────────────────

export function initPlanService() {
  ensureTable('plan_overrides');
  // plan_overrides: { userId, plan, expiresAt, grantedBy, grantedAt }
}

// ─── Plan Check ───────────────────────────────────────────────────────────────

/**
 * Ambil plan aktif user.
 * Priority: plan_override (manual admin) > plan dari record user
 * Kalau plan sudah expired, otomatis fallback ke free.
 */
export function getActivePlan(user) {
  if (!user || !user.id) return 'free';

  // Cek override manual dari admin
  const overrides = qSelect(
    `SELECT * FROM plan_overrides WHERE userId = ${esc(user.id)}`
  );
  const override = overrides?.[0];
  if (override) {
    if (!override.expiresAt || new Date(override.expiresAt) > new Date()) {
      return override.plan;
    }
    // Override sudah expired, hapus
    q(`DELETE FROM plan_overrides WHERE userId = ${esc(user.id)}`);
  }

  // Cek plan dari user record
  const plan   = user.plan || 'free';
  const expiry = user.planExpiry;

  if (plan !== 'free' && expiry && new Date(expiry) < new Date()) {
    // Plan expired — downgrade ke free (lazy update)
    q(`UPDATE users SET plan = 'free', planExpiry = NULL WHERE id = ${esc(user.id)}`);
    // FIX BUG-9: Reset maxStorage & rateLimit di API key saat plan expired,
    // agar user tidak bisa terus upload melebihi kuota free.
    try {
      const freePlan  = _loadPlansConfig()['free'];
      const keyRows   = qSelect(`SELECT keyId FROM users WHERE id = ${esc(user.id)}`);
      const keyId     = keyRows?.[0]?.keyId;
      if (keyId && freePlan) {
        updateKey(keyId, { maxStorage: freePlan.storageBytes, rateLimit: freePlan.rateLimit });
      }
    } catch (_) {}
    return 'free';
  }

  return plan;
}

/**
 * Set plan user (dari payment atau admin manual)
 */
export function setPlan(userId, planId, durationDays = 30, grantedBy = 'system') {
  const plans = _loadPlansConfig();
  if (!plans[planId]) throw new Error(`Plan '${planId}' tidak valid.`);

  const now = new Date();
  let expiresAt = null;

  if (planId !== 'free') {
    const expDate = new Date(now);
    expDate.setDate(expDate.getDate() + durationDays);
    expiresAt = expDate.toISOString();
  }

  q(`UPDATE users
     SET plan = ${esc(planId)},
         planExpiry = ${esc(expiresAt)},
         planActivatedAt = ${esc(now.toISOString())},
         planGrantedBy = ${esc(grantedBy)}
     WHERE id = ${esc(userId)}`);

  // Hapus override kalau ada
  q(`DELETE FROM plan_overrides WHERE userId = ${esc(userId)}`);

  // FIX BUG 2: Update maxStorage dan rateLimit pada API key user.
  // Sebelumnya hanya tabel 'users' yang diupdate, tapi upload route membaca
  // keyRecord.maxStorage dari tabel 'api_keys' — sehingga kuota tetap limit FREE
  // meski user sudah upgrade plan.
  const plan = plans[planId];
  const userRows = qSelect(`SELECT keyId FROM users WHERE id = ${esc(userId)}`);
  const keyId = userRows?.[0]?.keyId;
  if (keyId) {
    updateKey(keyId, {
      maxStorage: plan.storageBytes,
      rateLimit:  plan.rateLimit,
    });
  }

  return { plan: planId, expiresAt, activatedAt: now.toISOString() };
}

/**
 * Admin manual override plan (tanpa payment, bisa set expiry custom)
 */
export function adminSetPlan(userId, planId, expiresAt = null, adminId = 'admin') {
  const plans = _loadPlansConfig();
  if (!plans[planId]) throw new Error(`Plan '${planId}' tidak valid.`);

  const now = new Date().toISOString();

  // Hapus override lama dulu
  q(`DELETE FROM plan_overrides WHERE userId = ${esc(userId)}`);

  if (planId === 'free') {
    q(`UPDATE users SET plan = 'free', planExpiry = NULL, planActivatedAt = ${esc(now)},
       planGrantedBy = ${esc('admin:' + adminId)} WHERE id = ${esc(userId)}`);
  } else {
    // Insert override
    q(`INSERT INTO plan_overrides (userId, plan, expiresAt, grantedBy, grantedAt)
       VALUES (${esc(userId)}, ${esc(planId)}, ${esc(expiresAt)}, ${esc('admin:' + adminId)}, ${esc(now)})`);

    // Juga update user record supaya sinkron
    q(`UPDATE users SET plan = ${esc(planId)}, planExpiry = ${esc(expiresAt)},
       planActivatedAt = ${esc(now)}, planGrantedBy = ${esc('admin:' + adminId)}
       WHERE id = ${esc(userId)}`);
  }

  // FIX BUG 2: Update maxStorage dan rateLimit pada API key user (sama seperti setPlan)
  const plan = plans[planId];
  const userRows = qSelect(`SELECT keyId FROM users WHERE id = ${esc(userId)}`);
  const keyId = userRows?.[0]?.keyId;
  if (keyId) {
    updateKey(keyId, {
      maxStorage: plan.storageBytes,
      rateLimit:  plan.rateLimit,
    });
  }

  return { plan: planId, expiresAt };
}

/**
 * Cek apakah user punya paid plan aktif.
 */
export function isPlanActive(user) {
  const plan = getActivePlan(user);
  return plan !== 'free';
}

/**
 * Hitung sisa hari plan sebelum expired
 */
export function getPlanDaysLeft(user) {
  const expiry = user.planExpiry;
  if (!expiry) return null;
  const diff = new Date(expiry) - new Date();
  return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
}

// ─── Storage Enforcement ─────────────────────────────────────────────────────

/**
 * Cek apakah user masih bisa upload (belum melebihi storage limit plan).
 * Membaca dari plans-config.json (bukan PLANS hardcoded).
 */
export function checkStorageQuota(user, currentUsedBytes, addBytes = 0) {
  const planId = getActivePlan(user);
  const limit  = getPlanStorage(planId); // ← baca dari config dinamis
  const after  = currentUsedBytes + addBytes;

  return {
    allowed:   after <= limit,
    used:      currentUsedBytes,
    limit,
    after,
    remaining: Math.max(0, limit - currentUsedBytes),
    percent:   Math.min(100, Math.round((currentUsedBytes / limit) * 100)),
    plan:      planId,
  };
}
