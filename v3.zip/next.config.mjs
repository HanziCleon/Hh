/** @type {import('next').NextConfig} */
const nextConfig = {
  // Next.js 15: top-level serverExternalPackages
  serverExternalPackages: [
    'winston',
    'file-type',
    'busboy',
  ],

  // NOTE: serverActions.bodySizeLimit dihapus — tidak dikenali di Next.js 15.5+.
  // Upload file besar tetap aman karena /api/upload menggunakan streaming busboy
  // dan tidak melewati Server Actions body parser sama sekali.

  webpack(config) {
    config.module = config.module || {};
    config.module.exprContextCritical = false;
    return config;
  },

  async headers() {
    return [
      // ── Cache-Control untuk semua API route ──────────────────────────────
      // CORS ditangani oleh middleware.js agar tidak ada duplikasi header.
      {
        source: '/api/:path*',
        headers: [
          { key: 'Cache-Control',     value: 'no-store, no-cache, must-revalidate, proxy-revalidate' },
          { key: 'Pragma',            value: 'no-cache' },
          { key: 'Expires',           value: '0' },
          { key: 'Surrogate-Control', value: 'no-store' },
        ],
      },
      // ── File serving: override cache + tambah range support ───────────────
      {
        source: '/api/files/:path*',
        headers: [
          { key: 'Accept-Ranges',  value: 'bytes' },
          { key: 'Cache-Control',  value: '' },
          { key: 'Pragma',         value: '' },
          { key: 'Expires',        value: '' },
          { key: 'Surrogate-Control', value: '' },
        ],
      },
      // ── Security headers untuk halaman UI ────────────────────────────────
      {
        source: '/((?!api/|embed/).*)',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'X-Frame-Options',        value: 'DENY' },
        ],
      },
    ];
  },
};

export default nextConfig;
